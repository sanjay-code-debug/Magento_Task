<?php

namespace Shopmonk\Common\Setup;

use Magento\Eav\Setup\EavSetupFactory;
use Magento\Framework\App\Filesystem\DirectoryList;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\ModuleDataSetupInterface;
use Magento\Framework\Setup\UpgradeDataInterface;

/**
 * Class UpgradeData
 * @package Shopmonk\Common\Setup
 */
class UpgradeData implements UpgradeDataInterface
{

    /**
     *
     */
    CONST CATALOG_ENTITY_ID = 4;
    /**
     *
     */
    CONST PRODUCT_ATTRIBUTES_FILE = 'catalog-product-attributes.csv';
    /**
     * @var \Magento\Framework\Filesystem
     */
    protected $_filesystem;
    /**
     * @var \Magento\Framework\File\Csv
     */
    protected $csvProcessor;
    /**
     * @var EavSetupFactory
     */
    private $eavSetupFactory;
    /**
     * @var \Psr\Log\LoggerInterface
     */
    private $logger;

    /**
     * UpgradeData constructor.
     * @param EavSetupFactory               $eavSetupFactory
     * @param \Psr\Log\LoggerInterface      $loggerInterface
     * @param \Magento\Framework\Filesystem $filesystem
     * @param \Magento\Framework\File\Csv   $csvProcessor
     */
    public function __construct(
        EavSetupFactory $eavSetupFactory,
        \Psr\Log\LoggerInterface $loggerInterface,
        \Magento\Framework\Filesystem $filesystem,
        \Magento\Framework\File\Csv $csvProcessor
    )
    {
        $this->eavSetupFactory = $eavSetupFactory;
        $this->logger = $loggerInterface;
        $this->_filesystem = $filesystem;
        $this->csvProcessor = $csvProcessor;
    }

    /**
     * @param ModuleDataSetupInterface $setup
     * @param ModuleContextInterface   $context
     */
    public function upgrade(ModuleDataSetupInterface $setup, ModuleContextInterface $context)
    {
        try {
            $setup->startSetup();

            /*Removing all attributes bcoz of issues related to frontend*/
            if (version_compare($context->getVersion(), '1.0.4') < 0) {
                /*Change above version and update the Attributes csv file for addding new attributes*/
                $this->_removeCatalogAttributes($setup);
            }

            if (version_compare($context->getVersion(), '1.0.3') < 0) {
                /*Change above version and update the Attributes csv file for addding new attributes*/
                $this->_createCatalogAttributes($setup);
            }

            /*Dont change this below version*/
            if (version_compare($context->getVersion(), '1.0.2') < 0) {
                $this->_removeSwatchSelectAttributes($setup); //This is for only this version - 1.0.2
                $this->_createCatalogAttributes($setup);
            }
            $setup->endSetup();
        } catch (\Exception $e) {
            //throw new Exception($e->getMessage());
            $this->logger->info('+++++Shomponk Attributes Update log : ERROR ' . $e->getMessage());
        }
    }

    /**
     * @param $setup
     * @throws \Exception
     */
    private function _removeCatalogAttributes($setup)
    {
        $eavSetup = $this->eavSetupFactory->create(['setup' => $setup]);
        $csv = $this->getCsvFile();
        if ($csv) {
            $eavSetup = $this->eavSetupFactory->create(['setup' => $setup]);
            foreach ($csv as $csvData) {
                $code = $csvData[0];
                if (in_array($csvData[2], ['text', 'textarea']) && $eavSetup->getAttribute(self::CATALOG_ENTITY_ID, $code)) {
                    $eavSetup->removeAttribute(self::CATALOG_ENTITY_ID, $code);
                    $this->logger->info('+++++Shomponk Attributes Update log : Attribute with code ' . $code . ' - was removed successfully');
                }
            }
        }
    }

    /**
     * @return array|bool
     * @throws \Exception
     */
    public function getCsvFile()
    {
        $csvData = false;
        $path = $this->_filesystem->getDirectoryRead(DirectoryList::APP)->getAbsolutePath();
        $file = $path . 'code/Shopmonk/Common/Files/' . self::PRODUCT_ATTRIBUTES_FILE;
        if (file_exists($file)) {
            $importProductRawData = $this->csvProcessor->getData($file);
            if (is_array($importProductRawData)) {
                $headers = $importProductRawData[0];
                unset($importProductRawData[0]);
                if (!count($importProductRawData)) {
                    return $csvData;
                }
                $csvData = [];
                foreach ($importProductRawData as $rowIndex => $dataRow) {
                    $csvData[] = $dataRow;
                }
            }
        }
        return $csvData;
    }

    /**
     * @param $setup
     */
    /**
     * @param $setup
     * @throws \Exception
     */
    /**
     * @param $setup
     * @throws \Exception
     */
    protected function _createCatalogAttributes($setup)
    {
        $eavSetup = $this->eavSetupFactory->create(['setup' => $setup]);
        $csv = $this->getCsvFile();
        if ($csv) {
            foreach ($csv as $csvData) {
                if (in_array($csvData[2], ["swatch_text", "swatch_visual"])) {
                    continue;
                }
                $code = $csvData[0];
                $group = $csvData[1];
                $input = $csvData[2];
                $label = $csvData[3];
                $scope = $csvData[4];
                $type = $csvData[5];
                $usedInFilter = $csvData[6];
                $defaultValue = isset($csvData[7]) ? $csvData[7] : NULL;
                $searchable = isset($csvData[8]) ? $csvData[8] : NULL;
                $visible = isset($csvData[9]) && !empty($csvData[9]) ? true : false;
                if (!$attrExists = $eavSetup->getAttribute(self::CATALOG_ENTITY_ID, $code)) {
                    /*Create Attribute*/
                    $eavSetup->addAttribute(
                        \Magento\Catalog\Model\Product::ENTITY,
                        $code,
                        [
                            'group' => $group,
                            'type' => $type,
                            'backend' => '',
                            'frontend' => '',
                            'label' => $label,
                            'input' => $input,
                            'note' => $label,
                            'class' => '',
                            //'source' => 'MyModule\MyAttribute\Model\Config\Source\Options',
                            'global' => $scope,
                            'visible' => $visible,
                            'required' => false,
                            'user_defined' => true,
                            'default' => $defaultValue,
                            'searchable' => $searchable,
                            'filterable' => $usedInFilter,
                            'comparable' => false,
                            'visible_on_front' => true,
                            'used_in_product_listing' => true,
                            'unique' => false
                        ]
                    );
                    $this->logger->info('+++++Shomponk Attributes Update log : Attribute with code ' . $code . ' - added successfully');
                } else {
                    $this->logger->info('+++++Shomponk Attributes Update log : Attribute with code ' . $code . ' - already exists');
                    //$this->logger->info(print_r($attrExists, true));
                }
            }
        }
    }

    /**
     * @param $setup
     */
    /**
     * @param $setup
     */
    /**
     * @param $setup
     */
    protected function _removeSwatchSelectAttributes($setup)
    {
        $removeAttributes = ["size_text_swatch", "ram_text_swatch", "color_text_swatch", "storage_text_swatch"];
        $eavSetup = $this->eavSetupFactory->create(['setup' => $setup]);
        foreach ($removeAttributes as $code) {
            if ($eavSetup->getAttribute(self::CATALOG_ENTITY_ID, $code)) {
                $eavSetup->removeAttribute(self::CATALOG_ENTITY_ID, $code);
                $this->logger->info('+++++Shomponk Attributes Update log : Attribute with code ' . $code . ' - was removed successfully');
            }
        }
    }

}