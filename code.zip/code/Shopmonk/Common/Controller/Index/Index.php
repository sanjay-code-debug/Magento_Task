<?php

namespace Shopmonk\Common\Controller\Index;

use Magento\Framework\App\Filesystem\DirectoryList;

/**
 * Class Index
 * @package Shopmonk\Common\Controller\Index
 */
class Index extends \Magento\Framework\App\Action\Action
{

    /**
     *
     */
    CONST PRODUCT_ATTRIBUTES_FILE = 'catalog-product-attributes.csv';
    /**
     * @var \Magento\Framework\View\Result\PageFactory
     */
    protected $_pageFactory;
    /**
     * @var \Magento\Framework\Filesystem
     */
    protected $_filesystem;

    /**
     * Index constructor.
     * @param \Magento\Framework\App\Action\Context      $context
     * @param \Magento\Framework\View\Result\PageFactory $pageFactory
     * @param \Magento\Framework\Filesystem              $filesystem
     * @param \Magento\Framework\File\Csv                $csvProcessor
     */
    public function __construct(
        \Magento\Framework\App\Action\Context $context,
        \Magento\Framework\View\Result\PageFactory $pageFactory,
        \Magento\Framework\Filesystem $filesystem,
        \Magento\Framework\File\Csv $csvProcessor
    )
    {
        $this->_pageFactory = $pageFactory;
        $this->_filesystem = $filesystem;
        $this->csvProcessor = $csvProcessor;
        return parent::__construct($context);
    }

    /**
     * @return \Magento\Framework\App\ResponseInterface|\Magento\Framework\Controller\Result\Redirect|\Magento\Framework\Controller\ResultInterface|\Magento\Framework\View\Result\Page
     * @throws \Exception
     */
    public function execute()
    {
        $resultRedirect = $this->resultRedirectFactory->create();
        $resultRedirect->setPath('/');
        return $resultRedirect;
        die;
        $csvData = $this->getCsvFile();
        if ($csvData) {
            \Zend_Debug::dump($csvData);
        }
        var_dump(__CLASS__);
        return $this->_pageFactory->create();
    }

    /**
     * @return array|bool
     * @throws \Exception
     */
    public function getCsvFile()
    {
        $csvData = false;
        $path = $this->_filesystem->getDirectoryRead(DirectoryList::APP)->getAbsolutePath();
        $file = $path . 'code/Shopmonk/Common/Files/' . self::PRODUCT_ATTRIBUTES_FILE;
        if (file_exists($file)) {
            $importProductRawData = $this->csvProcessor->getData($file);
            if (is_array($importProductRawData)) {
                $headers = $importProductRawData[0];
                unset($importProductRawData[0]);
                if (!count($importProductRawData)) {
                    return $csvData;
                }
                $csvData = [];
                foreach ($importProductRawData as $rowIndex => $dataRow) {
                    $csvData[] = $dataRow;
                }
            }
        }
        return $csvData;
    }
}
