<?php
/**
 * Created by salman.
 * Date: 28/2/18
 * Time: 7:17 PM
 * Filename: Data.php
 */

namespace Shopmonk\Common\Helper;


use Magento\Framework\App\Helper\AbstractHelper;
use Magento\Framework\App\Helper\Context;

/**
 * Class Data
 * @package Shopmonk\Common\Helper
 */
class Data extends AbstractHelper
{
    /**
     * @var \Magento\Framework\App\Config\ScopeConfigInterface
     */
    protected $scope;

    /**
     * Data constructor.
     * @param \Magento\Framework\App\Config\ScopeConfigInterface $scope
     * @param Context                                            $context
     */
    public function __construct(
        \Magento\Framework\App\Config\ScopeConfigInterface $scope,
        Context $context)
    {
        $this->scope = $scope;
        parent::__construct($context);
    }

    /**
     * @param $method
     * @return bool
     */
    public function isPaymentActive($method)
    {
        $methodList = $this->scopeConfig->getValue('payment', \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
        return (@$methodList[$method]['active'] == true) ? true : false;
    }

}