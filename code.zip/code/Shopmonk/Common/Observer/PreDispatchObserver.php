<?php

namespace Shopmonk\Common\Observer;

use Magento\Framework\Event\ObserverInterface;

/**
 * Class PostDispatchObserver
 */
class PreDispatchObserver implements ObserverInterface
{
    /**
     *
     */
    const PAYMENT_METHOD_NONCE = 'payment_method_nonce';
    /**
     *
     */
    const DEVICE_DATA = 'device_data';

    /**
     * @var array
     */
    protected $additionalInformationList = [
        self::PAYMENT_METHOD_NONCE,
        self::DEVICE_DATA
    ];

    /**
     * @var ObjectManagerInterface
     */
    protected $_objectManager;

    /**
     * @var \Magento\Framework\App\ActionFlag
     */
    protected $_actionFlag;

    /**
     * @var \Magento\Framework\Message\ManagerInterface
     */
    protected $messageManager;

    /**
     * @var \Magento\Framework\App\Response\RedirectInterface
     */
    protected $redirect;

    /**
     * @var \Psr\Log\LoggerInterface
     */
    private $logger;

    /**
     * @param \Psr\Log\LoggerInterface                          $logger
     * @param \Magento\Framework\ObjectManagerInterface         $objectManager
     * @param \Magento\Framework\App\ActionFlag                 $actionFlag
     * @param \Magento\Framework\Message\ManagerInterface       $messageManager
     * @param \Magento\Framework\App\Response\RedirectInterface $redirect
     */
    public function __construct(
        \Psr\Log\LoggerInterface $logger,
        \Magento\Framework\ObjectManagerInterface $objectManager,
        \Magento\Framework\App\ActionFlag $actionFlag,
        \Magento\Framework\Message\ManagerInterface $messageManager,
        \Magento\Framework\App\Response\RedirectInterface $redirect
    )
    {
        $this->logger = $logger;
        $this->_objectManager = $objectManager;
        $this->_actionFlag = $actionFlag;
        $this->messageManager = $messageManager;
        $this->redirect = $redirect;
    }

    /**
     * @param \Magento\Framework\Event\Observer $observer
     * @return $this
     */
    public function execute(\Magento\Framework\Event\Observer $observer)
    {
        /** @var \Magento\Framework\App\Action\Action $controller */
        //$controller = $observer->getControllerAction();
        //$this->messageManager->addError(__('Incorrect CAPTCHA'));
        //$this->_actionFlag->set('', \Magento\Framework\App\Action\Action::FLAG_NO_DISPATCH, true);
        //$this->redirect->redirect($controller->getResponse(), '*/*/forgotpassword');
        // $this->testPsrLogger();
        //$this->messageManager->addError(__(__CLASS__));
        return $this;
    }


    public function testPsrLogger()
    {
        try {
            $this->logger->debug('debug');
            $this->logger->alert('alert');
            $this->logger->emergency('emergency');
            $this->logger->error('error');
            $this->logger->info('info');
            $this->logger->notice('notice');
            $this->logger->warning('warning');
            throw new \Exception('your error message');
        } catch (\Exception $e) {
            $this->logger->critical('Error message', ['exception' => $e]);
        }
    }
}
