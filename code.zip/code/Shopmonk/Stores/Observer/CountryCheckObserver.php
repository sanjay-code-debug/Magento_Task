<?php
namespace Shopmonk\Stores\Observer;
use Magento\Framework\Controller\ResultFactory;
use Magento\Framework\Event\Observer;
use Magento\Framework\Event\ObserverInterface;
use Magento\Store\Model\StoreManagerInterface;
use Psr\Log\LoggerInterface;
use Shopmonk\Stores\Helper\Business\Data as StoreHelper;

class CountryCheckObserver implements ObserverInterface
{
    /**
     * @var ResultFactory
     */
    protected $_resultFactory;
    /**
     * @var \Magento\Framework\UrlInterface
     */
    protected $url;
    /**
     * @var \Magento\Framework\App\Response\Http
     */
    protected $http;
    /**
     * @var StoreManagerInterface
     */
    private $storeManager;
    /**
     * @var LoggerInterface
     */
    private $logger;
    /**
     * @var StoreHelper
     */
    private $storeHelper;


    /**
     * @param ResultFactory $resultFactory
     * @param \Magento\Framework\UrlInterface $url
     * @param \Magento\Framework\App\Response\Http $http
     * @param StoreManagerInterface $storeManager
     * @param LoggerInterface $logger
     * @param StoreHelper $storeHelper
     */
    public function __construct(
        ResultFactory $resultFactory,
        \Magento\Framework\UrlInterface $url,
        \Magento\Framework\App\Response\Http $http,
        StoreManagerInterface $storeManager,
        LoggerInterface $logger,
        StoreHelper $storeHelper
    )
    {
        $this->_resultFactory = $resultFactory;
        $this->url = $url;
        $this->http = $http;
        $this->storeManager = $storeManager;
        $this->logger = $logger;
        $this->storeHelper = $storeHelper;
    }

    /**
     * @param Observer $observer
     */
    public function execute(Observer $observer)
    {
        $redirectionStatus = $this->storeHelper->getBusinessSiteRedirectionStatus();
        $allowedIPFlag = false;
        if($redirectionStatus){
            $allowedIPs = trim($this->storeHelper->getAllowedIPs());
            $explodedIPAddress = explode(',',$allowedIPs);
            if(isset($_SERVER['HTTP_X_REAL_IP'])){
                $allowedIPFlag = in_array($_SERVER['HTTP_X_REAL_IP'],$explodedIPAddress);
            }
            elseif (isset($_SERVER['REMOTE_ADDR'])){
                $allowedIPFlag = in_array($_SERVER['REMOTE_ADDR'],$explodedIPAddress);
            }
        }
        if($redirectionStatus && !$allowedIPFlag){
            $usUrl = $this->storeHelper->getStoreBaseUrlbyWebsiteCode(StoreHelper::BUSINESS_US_WEBSITE);
            $newPageUrl = $usUrl;
            $countryCodes = ['SG','US','UK','HK','AE','GB','MY'];
            $euroCountryCodes = ['AT','BE','BG','HR','CY','CZ','DK','EE','FI','FR','DE','GR','HU','IE','IT','LV','LT','LU','MT','NL','PL','PT','RO','SK','SI','ES','SE','GB'];
            $storeCode = $this->getStoreCode();
            if(in_array($storeCode,StoreHelper::ALL_BUSINESS_WEBSITES)){
                $continentCode = $this->storeHelper->getContinentCode();
                $countryCode = $this->storeHelper->getCountryCodeFromServer();
                if($continentCode == "EU" && $countryCode != "UK" && $countryCode != "GB"){
                    $euUrl = $this->storeHelper->getStoreBaseUrlbyWebsiteCode(StoreHelper::BUSINESS_EU_WEBSITE);
                    if($storeCode == StoreHelper::BUSINESS_EU_WEBSITE){
                        return;
                    }
                    else{
                        $newPageUrl = $euUrl;
                    }
                }
                else{
                    if(in_array($countryCode,$countryCodes) || in_array($countryCode,$euroCountryCodes)){
                        if($countryCode == "SG"){
                            $sgUrl = $this->storeHelper->getStoreBaseUrlbyWebsiteCode(StoreHelper::BUSINESS_SG_WEBSITE);
                            if($storeCode == StoreHelper::BUSINESS_SG_WEBSITE){
                                return;
                            }
                            else{
                                $newPageUrl = $sgUrl;
                            }
                        }
                        elseif($countryCode == "US"){
                            if($storeCode == StoreHelper::BUSINESS_US_WEBSITE){
                                return;
                            }
                            else{
                                $newPageUrl = $usUrl;
                            }
                        }
                        elseif($countryCode == "UK" || $countryCode == "GB"){
                            $ukUrl = $this->storeHelper->getStoreBaseUrlbyWebsiteCode(StoreHelper::BUSINESS_UK_WEBSITE);
                            if($storeCode == StoreHelper::BUSINESS_UK_WEBSITE){
                                return;
                            }
                            else{
                                $newPageUrl = $ukUrl;
                            }
                        }
                        elseif($countryCode == "HK"){
                            $hkUrl = $this->storeHelper->getStoreBaseUrlbyWebsiteCode(StoreHelper::BUSINESS_HK_WEBSITE);
                            if($storeCode == StoreHelper::BUSINESS_HK_WEBSITE){
                                return;
                            }
                            else{
                                $newPageUrl = $hkUrl;
                            }
                        }
                        elseif($countryCode == "AE"){
                            $aeUrl = $this->storeHelper->getStoreBaseUrlbyWebsiteCode(StoreHelper::BUSINESS_AE_WEBSITE);
                            if($storeCode == StoreHelper::BUSINESS_AE_WEBSITE){
                                return;
                            }
                            else{
                                $newPageUrl = $aeUrl;
                            }
                        }
                        elseif($countryCode == "MY"){
                            $myrUrl = $this->storeHelper->getStoreBaseUrlbyWebsiteCode(StoreHelper::BUSINESS_MYR_WEBSITE);
                            if($storeCode == StoreHelper::BUSINESS_MYR_WEBSITE){
                                return;
                            }
                            else{
                                $newPageUrl = $myrUrl;
                            }
                        }
                        elseif(in_array($countryCode,$euroCountryCodes)){
                            $euUrl = $this->storeHelper->getStoreBaseUrlbyWebsiteCode(StoreHelper::BUSINESS_EU_WEBSITE);
                            if($storeCode == StoreHelper::BUSINESS_EU_WEBSITE){
                                return;
                            }
                            else{
                                $newPageUrl = $euUrl;
                            }
                        }
                        else{
                            if($storeCode == StoreHelper::BUSINESS_US_WEBSITE){
                                return;
                            }
                            else{
                                $newPageUrl = $usUrl;
                            }
                        }
                    }
                    else{
                        if($storeCode == StoreHelper::BUSINESS_US_WEBSITE){
                            return;
                        }
                        else{
                            $newPageUrl = $usUrl;
                        }
                    }
                }
            }
            else{
                return;
            }
            /**
             * Redirect to business site
             */
            $this->http->setRedirect($newPageUrl);
        }
        else{
            return;
        }
    }

    /**
     * @return string
     */
    public function getStoreCode(){
        return $this->storeManager->getStore()->getCode();
    }
}