<?php

namespace Shopmonk\Stores\Observer;

use Magento\Customer\Model\Session;
use Magento\Framework\Event\ObserverInterface;

/**
 * Class AfterOrder
 * @package Shopmonk\Stores\Observer
 */
class AfterOrder implements ObserverInterface
{
    /**
     * @var Session
     */
    protected $customerSession;

    /**
     * AfterOrder constructor.
     * @param Session $session
     */
    public function __construct(
        Session $session
    )
    {
        $this->customerSession = $session;
    }

    /**
     * Set payment fee to order
     *
     * @param \Magento\Framework\Event\Observer $observer
     * @return $this
     */
    public function execute(\Magento\Framework\Event\Observer $observer)
    {
        if ($this->customerSession->isLoggedIn()) {
            $customer = $this->customerSession->getCustomer();
            $order = $observer->getOrder();
            $order->setData('abn', $customer->getData('abn'));
            $order->setData('business_name', $customer->getData('business_name'));
        }
        return $this;
    }
}
