<?php
/**
 * Created by salman.
 * Date: 14/3/18
 * Time: 3:17 PM
 * Filename: Data.php
 */

namespace Shopmonk\Stores\Helper\Business;


use Magento\Framework\App\Helper\AbstractHelper;
use Magento\Framework\App\Helper\Context;
use Magento\Store\Model\StoreManager;
use Magento\Directory\Model\CurrencyFactory;
/**
 * Class Data
 * @package Shopmonk\Stores\Helper\Business
 */
class Data extends AbstractHelper
{
    /**
     *
     */
    CONST COOKIE_NAME = 'business_country_ip_code';
    /**
     *
     */
    CONST COOKIE_COUNTRY_CHECK = 'country_code_check';
    /**
     *
     */
    CONST BUSINESS_WEBSITE = 'business';
    /**
     *
     */
    CONST BUSINESS_AE_WEBSITE = 'business_aed';
    /**
     *
     */
    CONST BUSINESS_HK_WEBSITE = 'business_hkd';
    /**
     *
     */
    CONST BUSINESS_EU_WEBSITE = 'business_eur';
    /**
     *
     */
    CONST BUSINESS_UK_WEBSITE = 'business_gbp';
    /**
     *
     */
    CONST BUSINESS_US_WEBSITE = 'business_usd';
    /**
     *
     */
    CONST BUSINESS_IND_WEBSITE = 'business_inr';
    /**
     *
     */
    CONST BUSINESS_AU_WEBSITE = 'business_aud';
    /**
     *
     */
    CONST BUSINESS_SG_WEBSITE = 'business_sgd';
    /**
     *
     */
    CONST BUSINESS_MYR_WEBSITE = 'business_myr';
    /**
     *
     */
    CONST BUSINESS_WEBSITES = ['business', 'business_au'];
    /**
     *
     */
    CONST GLOBAL_BUSINESS_WEBSITES = ['business_eur','business_usd','business_gbp','business_sgd','business_hkd','business_aed','business_myr'];
    /**
     *
     */
    CONST ALL_BUSINESS_WEBSITES = ['business','business_inr','business_aud','business_eur','business_usd','business_gbp','business_sgd','business_hkd','business_aed','business_myr'];
    /**
     *
     */
    CONST BUSINESS_WEBSITES_WITH_AU = ['business','business_au','business_inr','business_aud','business_eur','business_usd','business_gbp','business_sgd','business_hkd','business_aed','business_myr'];
    /**
     *
     */
    CONST BUSINESS_LOGIN_TITLE = 'Business Login';
    /**
     *
     */
    CONST BUSINESS_LOGIN_CONVERT = 'Convert to Business Account';
    /**
     *
     */
    CONST BUSINESS_REGISTER_TITLE = 'Create New Business Account';
    /**
     *
     */
    CONST BUSINESS_GROUP = 'Business';
    /**
     *
     */
    CONST CEBIT_GROUP = 'Cebit';
    /**
     * @var \Magento\Framework\App\Config\ScopeConfigInterface
     */
    protected $scope;
    /**
     * @var $_scopeConfigInterface
     */
    protected $_scopeConfig;
    /**
     * @var \Magento\Framework\Stdlib\CookieManagerInterface
     */
    public $_cookieManger;
    /**
     * @var \Magento\Framework\Stdlib\Cookie\CookieMetadataFactory
     */
    public $_cookieMetadataFactory;
    /**
     * @var \Magento\Framework\Session\SessionManagerInterface
     */
    public $_sessionManager;
    /**
     * @var \Magento\Framework\HTTP\PhpEnvironment\RemoteAddress
     */
    public $_remoteAddress;
    /**
     * @var StoreManager
     */
    private $storeManager;
    /**
     * @var CurrencyFactory
     */
    protected $currencycode;
    /**
     * @var \Magento\Framework\App\Request\Http
     */
    protected $request;

    /**
     * Data constructor.
     * @param \Magento\Framework\App\Config\ScopeConfigInterface $scope
     * @param Context $context
     * @param \Magento\Framework\Stdlib\CookieManagerInterface $cookieManager
     * @param \Magento\Framework\Stdlib\Cookie\CookieMetadataFactory $cookieMetadataFactory
     * @param \Magento\Framework\Session\SessionManagerInterface $sessionManager
     * @param \Magento\Framework\HTTP\PhpEnvironment\RemoteAddress $remoteAddress
     * @param StoreManager $storeManager
     */
    public function __construct(
        \Magento\Framework\App\Config\ScopeConfigInterface $scope,
        Context $context,
        \Magento\Framework\Stdlib\CookieManagerInterface $cookieManager,
        \Magento\Framework\Stdlib\Cookie\CookieMetadataFactory $cookieMetadataFactory,
        \Magento\Framework\Session\SessionManagerInterface $sessionManager,
        \Magento\Framework\HTTP\PhpEnvironment\RemoteAddress $remoteAddress,
        StoreManager $storeManager,
        CurrencyFactory $currencycode,
        \Magento\Framework\App\Request\Http $request
    )
    {
        $this->scope = $scope;
        parent::__construct($context);
        $this->_scopeConfig = $context->getScopeConfig();
        $this->_cookieManger = $cookieManager;
        $this->_cookieMetadataFactory = $cookieMetadataFactory;
        $this->_sessionManager = $sessionManager;
        $this->_remoteAddress = $remoteAddress;
        $this->storeManager = $storeManager;
        $this->currencycode = $currencycode;
        $this->request = $request;
    }

    /**
     * This function will return base url for business site
     * @param null
     * @return boolean
     */
    public function getBusinessSiteBaseUrl()
    {
        return $this->_scopeConfig->getValue('feedback/business/base_url', \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
    }

    /**
     * This function will return base url by using website code
     * @param null
     * @return boolean
     */
    public function getStoreBaseUrlbyWebsiteCode($websiteCode)
    {
        $store = $this->getStoreUsingStoreCode($websiteCode);
        return $this->getStoreBaseUrl($store);
    }

    public function getStoreUsingStoreCode($storecode){
        $stores = $this->storeManager->getStores(true, false);
        foreach($stores as $store) {
            if ($store->getCode() === $storecode) {
                return $store;
            }
        }
    }

    /**
     * @param null
     * @return boolean
     */
    public function getCebitRegUrl()
    {
        return $this->_scopeConfig->getValue('feedback/business/cebit_reg_url', \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
    }

    /**
     * @param null
     * @return string
     */
    public function getGradedLink1()
    {
        return $this->_scopeConfig->getValue('feedback/account_link/graded_link1', \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
    }

    /**
     * @param null
     * @return string
     */
    public function getGradedLink2()
    {
        return $this->_scopeConfig->getValue('feedback/account_link/graded_link2', \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
    }
    /**
     * @param null
     * @return string
     */
    public function getGradedLink3()
    {
        return $this->_scopeConfig->getValue('feedback/account_link/graded_link3', \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
    }
    /**
     * @param null
     * @return string
     */
    public function getGradedLink4()
    {
        return $this->_scopeConfig->getValue('feedback/account_link/graded_link4', \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
    }
    /**
     * @param null
     * @return string
     */
    public function getGradedLink5()
    {
        return $this->_scopeConfig->getValue('feedback/account_link/graded_link5', \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
    }
    /**
     * @param null
     * @return boolean
     */
    public function getCebitMobileImageUrl()
    {
        return $this->_scopeConfig->getValue('feedback/business/cebit_pagebanner_mobile', \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
    }

    /**
     * @param null
     * @return boolean
     */
    public function getCebitDesktopImageUrl()
    {
        return $this->_scopeConfig->getValue('feedback/business/cebit_pagebanner_desktop', \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
    }

    /**
     * This function will return redirection status for business site
     * @param null
     * @return boolean
     */
    public function getBusinessSiteRedirectionStatus()
    {
        return $this->_scopeConfig->getValue('feedback/business/redirection_status', \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
    }

    /**
     * This function will return allowed ip for business site
     * @param null
     * @return boolean
     */
    public function getAllowedIPs()
    {
        return $this->_scopeConfig->getValue('feedback/business/redirection_ip_address', \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
    }
    /**
     * This function will return redirection status for business site
     * @param null
     * @return boolean
     */
    public function getCurrencySwitcherStatus()
    {
        return $this->_scopeConfig->getValue('feedback/business/currency_switcher', \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
    }

    /**
     * @param $customerIp
     * @return null|string
     * @throws \Magento\Framework\Exception\InputException
     * @throws \Magento\Framework\Stdlib\Cookie\CookieSizeLimitReachedException
     * @throws \Magento\Framework\Stdlib\Cookie\FailureToSendException
     */
    public function getUserIpCountryCode($customerIp)
    {
        $countryCode = $this->_cookieManger->getCookie(self::COOKIE_NAME, null);
        try {
            if (!$countryCode) {
                //$customerIp = $this->_remoteAddress->getRemoteAddress();
                $countryCode = $this->getCode($customerIp);
                $this->setCookie($countryCode);
            }
        } catch (\Exception $e) {
            $this->setCookie('NULL');
        }
        return $countryCode;
    }

    public function getCode($ip)
    {
        if ($ip == '127.0.0.1')
            return "IN";
        try{
            $ipData = json_decode(file_get_contents("http://www.geoplugin.net/json.gp?ip=" . $ip));
            $countryCode = $ipData->geoplugin_countryCode;
            return $countryCode;
        }
        catch (\Exception $e){
            return "US";
        }
    }

    public function getContinentCode()
    {
        try{
            if(isset($_SERVER['HTTP_X_REAL_IP'])){
                $ipData = json_decode(file_get_contents("http://www.geoplugin.net/json.gp?ip=" . $_SERVER['HTTP_X_REAL_IP']));
                $continentCode = $ipData->geoplugin_continentCode;
                return $continentCode;
            }
            elseif (isset($_SERVER['REMOTE_ADDR'])){
                $ip = $this->_remoteAddress->getRemoteAddress();
                if ($ip == '127.0.0.1')
                {
                    return "IN";
                }
                else{
                    $ipData = json_decode(file_get_contents("http://www.geoplugin.net/json.gp?ip=" . $ip));
                    $continentCode = $ipData->geoplugin_continentCode;
                    return $continentCode;
                }
            }
        }
        catch (\Exception $e){
            return "US";
        }
    }

    public function getCountryCodeFromServer()
    {
        if(isset($_SERVER['COUNTRY_CODE'])){
            return $_SERVER['COUNTRY_CODE'];
        }
        else{
            if ($_SERVER['REMOTE_ADDR'] == '127.0.0.1' && !isset($_SERVER['HTTP_X_REAL_IP'])){
                return "IN";
            }
            $ip = (isset($_SERVER['HTTP_X_REAL_IP'])) ? $_SERVER['HTTP_X_REAL_IP'] : $_SERVER['REMOTE_ADDR'];
            return $this->getUserIpCountryCode($ip);
        }
    }

    /**
     * @param $countryCode
     * @throws \Magento\Framework\Exception\InputException
     * @throws \Magento\Framework\Stdlib\Cookie\CookieSizeLimitReachedException
     * @throws \Magento\Framework\Stdlib\Cookie\FailureToSendException
     */
    public function setCookie($countryCode)
    {
        $cookieMeta = $this->_cookieMetadataFactory->createPublicCookieMetadata()
            ->setDuration(604800)//7 days (86400 * 30)
            ->setPath($this->_sessionManager->getCookiePath())
            ->setDomain($this->_sessionManager->getCookieDomain())
            ->setHttpOnly(false);
        $this->_cookieManger->setPublicCookie(
            self::COOKIE_NAME,
            $countryCode,
            $cookieMeta
        );
    }

    public function getWebsiteCode(){
        return $this->storeManager->getWebsite()->getCode();
    }

    public function getStoreCode(){
        return $this->storeManager->getStore()->getCode();
    }

    public function getStoreBaseUrl($store){
        return $this->_scopeConfig->getValue('web/secure/base_url', \Magento\Store\Model\ScopeInterface::SCOPE_STORE,$store);
    }

    /**
     * @param $store
     * @return boolean
     */
    public function getCurrencySwitcherStatusStoreView($store)
    {
        return $this->_scopeConfig->getValue('feedback/business/currency_switcher_store', \Magento\Store\Model\ScopeInterface::SCOPE_STORE,$store);
    }

    /**
     * @param $store
     * @return string
     */
    public function getCurrencyCode($store)
    {
        return $this->_scopeConfig->getValue('feedback/business/currency_code', \Magento\Store\Model\ScopeInterface::SCOPE_STORE,$store);
    }

    /**
     * @param $storeCode
     * @return string
     */
    public function getCurrencyCodeUsingStoreCode($storeCode)
    {
        $store = $this->getStoreUsingStoreCode($storeCode);
        $currentCurrency = $this->storeManager->getStore($store->getId())->getCurrentCurrencyCode();
        $currency = $this->currencycode->create()->load($currentCurrency);
        return $currency->getCode();
    }

    /**
     * @param $storeCode
     * @return bool
     */
    public function getCurrencySwitcherStatusUsingStoreCode($storeCode){
        $store = $this->getStoreUsingStoreCode($storeCode);
        return $this->getCurrencySwitcherStatusStoreView($store);
    }

    /**
     * @param $storeCode
     * @return string
     */
    public function getCurrencyCodeFromConfigUsingStoreCode($storeCode){
        $store = $this->getStoreUsingStoreCode($storeCode);
        return $this->getCurrencyCode($store);
    }

    public function getFullActionName(){
        $actionName = $this->request->getFullActionName();
        return $actionName;
    }

    public function getStoreMediaBaseUrl(){
        return $this->storeManager->getStore()->getBaseUrl(\Magento\Framework\UrlInterface::URL_TYPE_MEDIA);
    }
}