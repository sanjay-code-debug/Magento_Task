##Stores
**Shopmonk_Stores** module is used add stores and websites data using setup/upgrade scripts.