<?php

namespace Codilar\CountryIp\Helper;

use GeoIp2\Database\Reader;
use Magento\Framework\App\Filesystem\DirectoryList;

/**
 * Class Data
 * @package Codilar\CountryIp\Helper
 */
class Data extends \Magento\Framework\App\Helper\AbstractHelper
{

    /**
     *
     */
    CONST COOKIE_NAME = 'country_ip_code';
    /**
     *
     */
    CONST DB_FILE = 'MAXMIND-COUNTRY-DB.mmdb';
    /**
     * @var \Magento\Framework\Stdlib\CookieManagerInterface
     */
    public $_cookieManger;
    /**
     * @var \Magento\Framework\Stdlib\Cookie\CookieMetadataFactory
     */
    public $_cookieMetadataFactory;
    /**
     * @var \Magento\Framework\Session\SessionManagerInterface
     */
    public $_sessionManager;
    /**
     * @var \Magento\Framework\HTTP\PhpEnvironment\RemoteAddress
     */
    public $_remoteAddress;
    /**
     * @var \Magento\Framework\Filesystem
     */
    protected $_filesystem;

    /**
     * Data constructor.
     * @param \Magento\Framework\App\Helper\Context                  $context
     * @param \Magento\Framework\Stdlib\CookieManagerInterface       $cookieManager
     * @param \Magento\Framework\Stdlib\Cookie\CookieMetadataFactory $cookieMetadataFactory
     * @param \Magento\Framework\Session\SessionManagerInterface     $sessionManager
     * @param \Magento\Framework\HTTP\PhpEnvironment\RemoteAddress   $remoteAddress
     * @param \Magento\Framework\Filesystem                          $filesystem
     */
    public function __construct(
        \Magento\Framework\App\Helper\Context $context,
        \Magento\Framework\Stdlib\CookieManagerInterface $cookieManager,
        \Magento\Framework\Stdlib\Cookie\CookieMetadataFactory $cookieMetadataFactory,
        \Magento\Framework\Session\SessionManagerInterface $sessionManager,
        \Magento\Framework\HTTP\PhpEnvironment\RemoteAddress $remoteAddress,
        \Magento\Framework\Filesystem $filesystem
    )
    {
        $this->_cookieManger = $cookieManager;
        $this->_cookieMetadataFactory = $cookieMetadataFactory;
        $this->_sessionManager = $sessionManager;
        $this->_remoteAddress = $remoteAddress;
        $this->_filesystem = $filesystem;
        parent::__construct($context);
    }

    /**
     * @return null|string|void
     * @throws \Magento\Framework\Exception\InputException
     * @throws \Magento\Framework\Stdlib\Cookie\CookieSizeLimitReachedException
     * @throws \Magento\Framework\Stdlib\Cookie\FailureToSendException
     */
    public function getUserIpCountryCode()
    {
        $countryCode = $this->_cookieManger->getCookie(self::COOKIE_NAME, null);
        if (!$this->isEnabled()) {
            return;
        }
        try {
              $customerIp = (isset($_SERVER['HTTP_X_REAL_IP'])) ? $_SERVER['HTTP_X_REAL_IP'] : $_SERVER['REMOTE_ADDR'];
              $countryCode = $this->getCode($customerIp);
              $this->setCookie($countryCode);
        } catch (\Exception $e) {
            $this->setCookie('NULL');
        }
        return $countryCode;
    }

    /**
     * @return mixed
     */
    public function isEnabled()
    {
        return $this->scopeConfig->getValue(
            'country_ip/general/enabled',
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE
        );
    }

    /**
     * @param $ip
     * @return null|string
     * @throws \GeoIp2\Exception\AddressNotFoundException
     * @throws \MaxMind\Db\Reader\InvalidDatabaseException
     */
    public function getCode($ip)
    {
        if ($ip == '::1' || $ip == '127.0.0.1')
            return "IN";
        $reader = new Reader($this->getPathofGeoipDbFile());
        $record = $reader->country($ip);
        return $record->country->isoCode;
    }

    public function getClientIp() {
        $ipaddress = '';
        if (getenv('HTTP_CLIENT_IP'))
            $ipaddress = getenv('HTTP_CLIENT_IP');
        else if(getenv('HTTP_X_FORWARDED_FOR'))
            $ipaddress = getenv('HTTP_X_FORWARDED_FOR');
        else if(getenv('HTTP_X_FORWARDED'))
            $ipaddress = getenv('HTTP_X_FORWARDED');
        else if(getenv('HTTP_FORWARDED_FOR'))
            $ipaddress = getenv('HTTP_FORWARDED_FOR');
        else if(getenv('HTTP_FORWARDED'))
           $ipaddress = getenv('HTTP_FORWARDED');
        else if(getenv('REMOTE_ADDR'))
            $ipaddress = getenv('REMOTE_ADDR');
        else
            $ipaddress = 'UNKNOWN';
        return $ipaddress;
    }

    /**
     * @return string
     */
    public function getPathofGeoipDbFile()
    {
        $path = $this->_filesystem->getDirectoryRead(DirectoryList::APP)->getAbsolutePath();
        $modulePath = $path . 'code/Codilar/CountryIp/Files/' . self::DB_FILE;
        return $modulePath;
    }

    /**
     * @param $countryCode
     * @throws \Magento\Framework\Exception\InputException
     * @throws \Magento\Framework\Stdlib\Cookie\CookieSizeLimitReachedException
     * @throws \Magento\Framework\Stdlib\Cookie\FailureToSendException
     */
    public function setCookie($countryCode)
    {
        $cookieMeta = $this->_cookieMetadataFactory->createPublicCookieMetadata()
            ->setDuration(2592000)//30 days (86400 * 30)
            ->setPath($this->_sessionManager->getCookiePath())
            ->setDomain($this->_sessionManager->getCookieDomain())
            ->setHttpOnly(false);
        $this->_cookieManger->setPublicCookie(
            self::COOKIE_NAME,
            $countryCode,
            $cookieMeta
        );
    }
}