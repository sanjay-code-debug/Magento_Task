<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */

namespace Codilar\Customer\Block\Form;

use Shopmonk\Stores\Helper\Business\Data;

/**
 * Customer register form block
 *
 * @api
 * @SuppressWarnings(PHPMD.CouplingBetweenObjects)
 * @since 100.0.2
 */
class Register extends \Magento\Customer\Block\Form\Register
{
    protected function _prepareLayout()
    {
        if (in_array($this->_storeManager->getWebsite()->getCode(), Data::BUSINESS_WEBSITES_WITH_AU)) {
            $this->pageConfig->getTitle()->set(__(Data::BUSINESS_REGISTER_TITLE));
        } else {
            $this->pageConfig->getTitle()->set(__('Login / Signup'));
        }
        return parent::_prepareLayout();
    }
}
