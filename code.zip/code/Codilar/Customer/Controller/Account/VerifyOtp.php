<?php
/**
 *
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */

namespace Codilar\Customer\Controller\Account;

use Codilar\Customer\Helper\Data as CustomerHelper;
use Codilar\Customer\Model\OtpLogger;
use Magento\Framework\App\Action\Action;
use Magento\Framework\App\Action\Context;
use Magento\Framework\Data\Form\FormKey\Validator;
use Magento\Framework\UrlInterface;

/**
 * Class VerifyOtp
 * @package Codilar\Customer\Controller\Account
 */
class VerifyOtp extends Action
{
    /**
     * @var Validator
     */
    protected $_formKeyValidator;
    /**
     * @var CustomerHelper
     */
    protected $_customerHelper;
    /**
     * @var OtpLogger
     */
    protected $_otpLogger;
    /**
     * @var UrlInterface
     */
    protected $url;

    /**
     * VerifyOtp constructor.
     * @param Validator      $formKeyValidator
     * @param CustomerHelper $customerHelper
     * @param OtpLogger      $otpLogger
     * @param UrlInterface   $url
     * @param Context        $context
     */
    public function __construct(
        Validator $formKeyValidator,
        CustomerHelper $customerHelper,
        OtpLogger $otpLogger,
        UrlInterface $url,
        \Magento\Framework\App\Action\Context $context)
    {
        $this->_formKeyValidator = $formKeyValidator;
        $this->_customerHelper = $customerHelper;
        $this->_otpLogger = $otpLogger;
        $this->url = $url;
        return parent::__construct($context);
    }

    /**
     * @return \Magento\Framework\App\ResponseInterface|\Magento\Framework\Controller\ResultInterface|void
     */
    public function execute()
    {
        if (!$this->_formKeyValidator->validate($this->getRequest())) {
            $result['status'] = "0";
            $result['error'] = "Form key is not valid nor expired";
        }

        $mobileNumber = $this->getRequest()->getParam("mobile_number");
        $id = $this->getRequest()->getParam("id");
        $countryCode = $this->getRequest()->getParam("country_code");
        $otp = $this->getRequest()->getParam("otp");
        $mobileNumber = $countryCode.$mobileNumber;

        $status = $this->_otpLogger->validateOtp($id, $otp, $mobileNumber);
       if ($status) {
            $otpData = $this->_otpLogger->getOtpData($id, $mobileNumber);
            $token = $otpData->getRpToken();
            $result['status'] = "1";
            $result['token'] = $token;
            $result['url'] = $this->url->getUrl("customer/account/createpassword/");
        } else {
            $result['status'] = "0";
            $result['error'] = 'OTP is invalid or expired, please try again';
        }
        $this->getResponse()->representJson(
            $this->_objectManager->get('Magento\Framework\Json\Helper\Data')
                ->jsonEncode($result)
        );
    }
}
