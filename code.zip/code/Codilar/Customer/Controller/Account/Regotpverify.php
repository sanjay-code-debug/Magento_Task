<?php

namespace Codilar\Customer\Controller\Account;

use Codilar\Customer\Helper\Data as CustomerHelper;
use Magento\Customer\Model\CustomerFactory;
use Magento\Framework\App\Action\Context;
use Codilar\Customer\Model\OtpLogger as OtpLogger;
use Codilar\SmsModule\Helper\Data as SmsHelper;
use Magento\Framework\Controller\ResultFactory;

class Regotpverify extends \Magento\Framework\App\Action\Action
{
    /**
     * @var CustomerFactory
     */
    protected $_customerFactory;
    /**
     * @var CustomerHelper
     */
    protected $_customerHelper;
    /**
     * @var SmsHelper
     */
    protected $_smsHelper;
    /**
     * @var \Codilar\Customer\Model\OtpLogger
     */
    protected $_otpLogger;

    protected $_urlModel;
    
    protected $_sessionFactory;

    public function __construct(
        Context $context,
        CustomerFactory $customerFactory,
        CustomerHelper $customerHelper,
        SmsHelper $smsHelper,
        \Magento\Framework\UrlFactory $urlFactory,
        \Magento\Customer\Model\SessionFactory $sessionFactory,    
        OtpLogger $otpLogger
    )
    {
        $this->_customerFactory = $customerFactory;
        $this->_customerHelper = $customerHelper;
        $this->_smsHelper = $smsHelper;
        $this->_otpLogger = $otpLogger;
        $this->_sessionFactory = $sessionFactory;
        $this->_urlModel = $urlFactory->create();
        parent::__construct($context);
    }

    public function execute()
    {
        $resultJson = $this->resultFactory->create(ResultFactory::TYPE_JSON);
        $data['error']=0;
        
        if (array_key_exists("mobile_number", $this->getRequest()->getParams()) ||
            array_key_exists("email", $this->getRequest()->getParams())) {
            $mobile = $this->getRequest()->getParam("mobile_number");
            $email = $this->getRequest()->getParam("email");
            $otp = $this->getRequest()->getParam("otp");
            $country_code = $this->getRequest()->getParam("country_code");
            $mobile_number = str_replace($country_code,"",$mobile);
            $this->getRequest()->setPostValue('mobile_number',$mobile_number);
            $emailValue = $this->getRequest()->getParam("email");
            $customerid = 0;
            $websiteId = $this->_customerHelper->getWebsiteId();
            if ($this->_customerHelper->getAccountSharingOptions()) {
                $customerid = $this->_customerFactory->create()->getCollection()
                    ->addFieldToFilter("website_id", $websiteId)
                    ->addFieldToFilter('mobile_number', $mobile_number)
                    ->getFirstItem()->getId();
            } else {
                $customerid = $this->_customerFactory->create()->getCollection()
                    ->addFieldToFilter('mobile_number', $mobile_number)
                    ->getFirstItem()->getId();
            }
            if($email){
                if ($this->_customerHelper->getAccountSharingOptions()) {
                    $customerid = $this->_customerFactory->create()->getCollection()
                        ->addFieldToFilter("website_id", $websiteId)
                        ->addFieldToFilter('email', $email)
                        ->getFirstItem()->getId();
                } else {
                    $customerid = $this->_customerFactory->create()->getCollection()
                        ->addFieldToFilter('email', $email)
                        ->getFirstItem()->getId();
                }
            }
            if($mobile_number){
                $status = $this->_otpLogger->validateOtp($customerid, $otp, $country_code.$mobile_number);
            } else {
                $status = $this->_otpLogger->validateOtp($customerid, $otp, $email);
            }
            
            if (!$status) {
                $data['error'] = 1;
                $data['message'] = 'OTP is invalid or expired, please try again';
                $resultJson->setData($data);
            } elseif($customerid && $status) {
                $customer = $this->_customerFactory->create()->load($customerid);
                $sessionManager = $this->_sessionFactory->create();
                $sessionManager->setCustomerAsLoggedIn($customer);
                $data['error'] = 0;
                $data['login'] = 1;
                $data['message'] = 'OTP Verified Successfully';
                $data['url'] = $this->_urlModel->getUrl('/');
                $resultJson->setData($data);
            } else {
                $data['error'] = 0;
                $data['login'] = 0;
                $data['message'] = 'OTP Verified Successfully';
                $resultJson->setData($data);
            }
            
            return $resultJson;
        }
        $data['error'] = 1;
        $data['message'] = 'Invalid Mobile Number Or Email';
        $resultJson->setData($data);
        
        return $resultJson;
    }
}
