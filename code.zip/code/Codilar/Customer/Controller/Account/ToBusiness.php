<?php
/**
 *
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */

namespace Codilar\Customer\Controller\Account;

use Codilar\Customer\Helper\Data as CustomerHelper;
use Magento\Framework\App\Action\Context;
use Magento\Framework\Data\Form\FormKey\Validator;
use Magento\Framework\UrlFactory;
use Magento\Framework\UrlInterface;
use Magento\Customer\Model\Account\Redirect as AccountRedirect;

/**
 * Class VerifyOtp
 * @package Codilar\Customer\Controller\Account
 */
class ToBusiness extends \Magento\Framework\App\Action\Action
{
    /**
     * @var Validator
     */
    protected $_formKeyValidator;
    /**
     * @var CustomerHelper
     */
    protected $_customerHelper;
    /**
     * @var UrlInterface
     */
    protected $url;
    /**
     * @var UrlInterface
     */
    protected $urlModel;
    /**
     * @var \Magento\Customer\Model\Session
     */
    protected $session;
    /**
     * @var \Magento\Customer\Api\GroupRepositoryInterface
     */
    protected $groupRepo;
    /**
     * @var \Magento\Customer\Model\GroupFactory
     */
    protected $groupFactory;
    /**
     * @var \Magento\Customer\Api\CustomerRepositoryInterface
     */
    protected $customerRepoInterface;
    /**
     * @var AccountRedirect
     */
    protected $accountRedirect;

    /**
     * VerifyOtp constructor.
     * @param Validator $formKeyValidator
     * @param CustomerHelper $customerHelper
     * @param UrlInterface $url
     * @param UrlFactory $urlFactory
     * @param \Magento\Customer\Model\Session $session
     * @param \Magento\Customer\Api\GroupRepositoryInterface $groupRepository
     * @param \Magento\Customer\Model\GroupFactory $groupFactory
     * @param \Magento\Customer\Api\CustomerRepositoryInterface $customerRepositoryInterface
     * @param AccountRedirect $accountRedirect
     * @param Context $context
     */
    public function __construct(
        Validator $formKeyValidator,
        CustomerHelper $customerHelper,
        UrlInterface $url,
        UrlFactory $urlFactory,
        \Magento\Customer\Model\Session $session,
        \Magento\Customer\Api\GroupRepositoryInterface $groupRepository,
        \Magento\Customer\Model\GroupFactory $groupFactory,
        \Magento\Customer\Api\CustomerRepositoryInterface $customerRepositoryInterface,
        AccountRedirect $accountRedirect,
        \Magento\Framework\App\Action\Context $context)
    {
        $this->_formKeyValidator = $formKeyValidator;
        $this->_customerHelper = $customerHelper;
        $this->url = $url;
        $this->groupRepo = $groupRepository;
        $this->groupFactory = $groupFactory;
        $this->session = $session;
        $this->customerRepoInterface = $customerRepositoryInterface;
        $this->accountRedirect = $accountRedirect;
        $this->urlModel = $urlFactory->create();
        return parent::__construct($context);
    }

    /**
     * @return \Magento\Framework\App\ResponseInterface|\Magento\Framework\Controller\ResultInterface|void
     */
    public function execute()
    {
        $email = $this->getRequest()->getParam('email');
        $abn = $this->getRequest()->getParam('abn');
        $businessName = $this->getRequest()->getParam('business_name');
        $resultRedirect = $this->resultRedirectFactory->create();
        try {
            if (isset($email)
                && $this->session->isLoggedIn()
                && $this->session->getCustomer()->getEmail() == $email
                && $this->groupRepo->getById($this->session->getCustomer()->getGroupId())->getCode() != \Shopmonk\Stores\Helper\Business\Data::BUSINESS_GROUP
            ) {
                $message = 'Your personal account has been converted to business account successfully';
                $businessGroupId = $this->groupFactory->create()->load(\Shopmonk\Stores\Helper\Business\Data::BUSINESS_GROUP, 'customer_group_code')->getId();
                $this->session->getCustomer()->setGroupId($businessGroupId)->save();
                $this->messageManager->addSuccess($message);
            }
            $customer = $this->customerRepoInterface->getById($this->session->getCustomer()->getId());
            if (isset($abn)) {
                $customer->setCustomAttribute('abn', $abn);
                $this->customerRepoInterface->save($customer);
            }
            if (isset($businessName)) {
                $customer->setCustomAttribute('business_name', $businessName);
                $this->customerRepoInterface->save($customer);
            }
        } catch (\Exception $e) {
            $this->messageManager->addError($e->getMessage());
        }
        return $this->accountRedirect->getRedirect();
        $redirectUrl = $this->accountRedirect->getRedirectCookie();
        $defaultUrl = $this->urlModel->getUrl('customer/account/edit', ['_secure' => true]);
        $resultRedirect->setUrl($this->_redirect->success($defaultUrl));
        return $resultRedirect;
    }
}
