<?php
/**
 *
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */

namespace Codilar\Customer\Controller\Account;

use Codilar\Customer\Helper\Data as CustomerHelper;
use Magento\Customer\Api\AccountManagementInterface;
use Magento\Customer\Api\CustomerRepositoryInterface;
use Magento\Customer\Model\AccountManagement;
use Magento\Customer\Model\CustomerFactory;
use Magento\Customer\Model\Session;
use Magento\Framework\App\Action\Context;
use Magento\Framework\Escaper;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\Exception\SecurityViolationException;
use Magento\Framework\UrlInterface;
use Codilar\Customer\Block\ResetOtp as ResetOtp;

/**
 * ForgotPasswordPost controller
 * @SuppressWarnings(PHPMD.CouplingBetweenObjects)
 */
class ForgotPasswordPost extends \Magento\Customer\Controller\Account\ForgotPasswordPost
{
    /**
     * @var \Magento\Customer\Api\AccountManagementInterface
     */
    protected $customerAccountManagement;

    /**
     * @var \Magento\Framework\Escaper
     */
    protected $escaper;

    /**
     * @var Session
     */
    protected $session;
    /**
     * @var CustomerRepositoryInterface
     */
    protected $customerRepository;
    /**
     * @var CustomerFactory
     */
    protected $_customerFactory;
    /**
     * @var CustomerHelper
     */
    protected $_customerHelper;
    /**
     * @var UrlInterface
     */
    protected $urlInterface;

        /**
     * @var resetOtp
     */
    protected $resetOtp;

    /**
     * ForgotPasswordPost constructor.
     * @param Context                     $context
     * @param Session                     $customerSession
     * @param AccountManagementInterface  $customerAccountManagement
     * @param Escaper                     $escaper
     * @param CustomerRepositoryInterface $customerRepository
     * @param CustomerFactory             $customerFactory
     * @param CustomerHelper              $customerHelper
     * @param UrlInterface                $urlInterface
     */
    public function __construct(
        Context $context,
        Session $customerSession,
        AccountManagementInterface $customerAccountManagement,
        Escaper $escaper,
        CustomerRepositoryInterface $customerRepository,
        CustomerFactory $customerFactory,
        CustomerHelper $customerHelper,
        UrlInterface $urlInterface,
        ResetOtp $resetOtp
    )
    {
        $this->customerRepository = $customerRepository;
        $this->_customerFactory = $customerFactory;
        $this->_customerHelper = $customerHelper;
        $this->urlInterface = $urlInterface;
        $this->_resetOtp = $resetOtp;
        parent::__construct($context, $customerSession, $customerAccountManagement, $escaper);
    }

    /**
     * Forgot customer password action
     *
     * @return \Magento\Framework\Controller\Result\Redirect
     */
    public function execute()
    {
        /** @var \Magento\Framework\Controller\Result\Redirect $resultRedirect */
        $resultRedirect = $this->resultRedirectFactory->create();
        $email = (string)$this->getRequest()->getPost('email');
        $mobile_number = $this->getRequest()->getPost('mobile_number');
        $isMobileNumber = false;
        if (is_numeric($mobile_number)) {
            $isMobileNumber = true;
            $mobile = $mobile_number;
            $country_code = $this->getRequest()->getParam("country_code");
            $mobileNumber = str_replace($country_code,"",$mobile);
            $email = $this->getEmailFromMobile($mobileNumber);
            if (strlen($mobileNumber)>10) {
                $this->messageManager->addError(
                    __('Please enter only 10 digits mobile number.')
                );
                return $resultRedirect->setPath('*/*/forgotpassword');
            }
            if (!$email) {
                $this->messageManager->addError(
                    __('Your mobile number does not exist.')
                );
                return $resultRedirect->setPath('*/*/forgotpassword');
            }
            $websiteId = $this->_customerHelper->getWebsiteId();
        }

        if ($email) {
            if (!\Zend_Validate::is($email, \Magento\Framework\Validator\EmailAddress::class) && !$isMobileNumber) {
                $this->session->setForgottenEmail($email);
                $this->messageManager->addErrorMessage(__('Please correct the email address.'));
                return $resultRedirect->setPath('*/*/forgotpassword');
            }

            try {
                if ($isMobileNumber) {
                    $customerId = $this->getCustomerIdFromMobile($mobileNumber);
                    $mobileNumberOtp = $country_code.$mobileNumber;
                    $this->customerAccountManagement->initiatePasswordResetMobile(
                        $mobileNumberOtp,
                        $email,
                        AccountManagement::EMAIL_RESET,
                        $websiteId
                    );
                } else {
                    $emailExists = $this->_customerFactory->create()->getCollection()
                        ->addFieldToFilter("email", $email)
                        ->getFirstItem()->getEmail();
                    if (!strlen($emailExists) > 0) {
                        $this->messageManager->addError(
                            __('Email doesnt exist in our database.')
                        );
                        return $resultRedirect->setPath('*/*/forgotpassword');
                    }
                    $this->customerAccountManagement->initiatePasswordReset(
                        $email,
                        AccountManagement::EMAIL_RESET
                    );
                }
            } catch (NoSuchEntityException $exception) {
                // Do nothing, we don't want anyone to use this action to determine which email accounts are registered.
            } catch (SecurityViolationException $exception) {
                $this->messageManager->addErrorMessage($exception->getMessage());
                return $resultRedirect->setPath('*/*/forgotpassword');
            } catch (\Exception $exception) {
                $this->messageManager->addExceptionMessage(
                    $exception,
                    __('We\'re unable to send the password reset email.')
                );
                return $resultRedirect->setPath('*/*/forgotpassword');
            }
            if ($isMobileNumber) {
                $customerId = $this->getCustomerIdFromMobile($mobileNumber);
                $resetUrl = $this->urlInterface
                    ->getUrl('codilar_customer/account/resetotp/',
                        array('mobilenumber' => $mobileNumber, 'id' => $customerId,'country_code' => $country_code,)
                    );
                return $resultRedirect->setUrl($resetUrl);
            }
            $this->messageManager->addSuccessMessage($this->getSuccessMessage($email));
            return $resultRedirect->setPath('*/*/');
        } else {
            $this->messageManager->addErrorMessage(__('Please enter your Email or Mobile Number'));
            return $resultRedirect->setPath('*/*/forgotpassword');
        }
    }

    /**
     * @param $mobileNumber
     * @return mixed
     */
    public function getEmailFromMobile($mobileNumber)
    {
        /** @var \Magento\Framework\Controller\Result\Redirect $resultRedirect */
        $resultRedirect = $this->resultRedirectFactory->create();
        $websiteId = $this->_customerHelper->getWebsiteId();
        if ($this->_customerHelper->getAccountSharingOptions()) {
            $email = $this->_customerFactory->create()->getCollection()
                ->addFieldToFilter("website_id", $websiteId)
                ->addFieldToFilter('mobile_number', $mobileNumber)
                ->getFirstItem()
                ->getEmail();
        } else {
            $email = $this->_customerFactory->create()->getCollection()
                ->addFieldToFilter('mobile_number', $mobileNumber)
                ->getFirstItem()
                ->getEmail();
        }

        return $email;
    }

    /**
     * @param $mobileNumber
     * @return mixed
     */
    public function getCustomerIdFromMobile($mobileNumber)
    {
        $websiteId = $this->_customerHelper->getWebsiteId();
        if ($this->_customerHelper->getAccountSharingOptions()) {
            $customerId = $this->_customerFactory->create()->getCollection()
                ->addFieldToFilter("website_id", $websiteId)
                ->addFieldToFilter('mobile_number', $mobileNumber)
                ->getFirstItem()
                ->getEntityId();
        } else {
            $customerId = $this->_customerFactory->create()->getCollection()
                ->addFieldToFilter('mobile_number', $mobileNumber)
                ->getFirstItem()
                ->getEntityId();
        }

        return $customerId;
    }

    /**
     * Retrieve success message
     *
     * @param string $email
     * @return \Magento\Framework\Phrase
     */
    protected function getSuccessMessage($email)
    {
        return __(
            'A link to reset your password has been sent to %1.',
            $this->escaper->escapeHtml($email)
        );
    }

}
