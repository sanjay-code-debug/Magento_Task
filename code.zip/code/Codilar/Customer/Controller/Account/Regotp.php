<?php

namespace Codilar\Customer\Controller\Account;

use Codilar\Customer\Helper\Data as CustomerHelper;
use Magento\Customer\Model\CustomerFactory;
use Magento\Framework\App\Action\Context;
use Codilar\Customer\Model\OtpLogger as OtpLogger;
use Codilar\SmsModule\Helper\Data as SmsHelper;
use Magento\Framework\Controller\ResultFactory;

class Regotp extends \Magento\Framework\App\Action\Action
{
    /**
     * @var CustomerFactory
     */
    protected $_customerFactory;
    /**
     * @var CustomerHelper
     */
    protected $_customerHelper;
    /**
     * @var SmsHelper
     */
    protected $_smsHelper;
    /**
     * @var helper
     */
    protected $helper;
    /**
     * @var _scopeConfig
     */
    protected $_scopeConfig;
    /**
     * @var \Codilar\Customer\Model\OtpLogger
     */
    protected $_otpLogger;

    protected $_coreSession;

    public function __construct(
        Context $context,
        CustomerFactory $customerFactory,
        CustomerHelper $customerHelper,
        SmsHelper $smsHelper,
        \Magento\Framework\Session\SessionManagerInterface $coreSession,
        \Codilar\Customer\Helper\Data $helper,
        \Magento\Framework\App\Config\ScopeConfigInterface $_scopeConfig,
        OtpLogger $otpLogger
    )
    {
        $this->_customerFactory = $customerFactory;
        $this->_customerHelper = $customerHelper;
        $this->_smsHelper = $smsHelper;
        $this->helper = $helper;
        $this->_scopeConfig = $_scopeConfig;
        $this->_otpLogger = $otpLogger;
        $this->_coreSession = $coreSession;
        parent::__construct($context);
    }

    public function execute()
    {
        $resultJson = $this->resultFactory->create(ResultFactory::TYPE_JSON);
        $data['error']=0;
        
        $mobile_number = $this->getRequest()->getPost('mobile_number');
        $email = $this->getRequest()->getPost('email');
        $isMobileNumber = false;
        $id =0;
        if (is_numeric($mobile_number)) {
            $isMobileNumber = true;
            $mobile = $mobile_number;
            $country_code = $this->getRequest()->getParam("country_code");
            $mobileNumber = str_replace($country_code,"",$mobile);
            $id = $this->getEmailFromMobile($mobileNumber);
            if (strlen($mobileNumber)>10) {
                $data['error'] = 1;
                $data['message'] ='Please Enter Valid Mobile Number';
                $resultJson->setData($data);
                return $resultJson;
            }
            /*if ($email) {
                $data['error'] = 1;
                $data['message'] = 'Your mobile number is already exist.';
                $resultJson->setData($data);
                return $resultJson;
            }*/
            $websiteId = $this->_customerHelper->getWebsiteId();
        }
            try {
                    $newPasswordToken = $this->_customerHelper->getUniqueHash();
                    $otp = mt_rand(100000, 999999);
                    $current_timeout = time();
                if ($isMobileNumber) {
                    //$customerId = $this->getCustomerIdFromMobile($mobileNumber);
                    $mobileNumberOtp = $country_code.$mobileNumber;
                    $this->_otpLogger->setCustomerOtp($id, $otp, $mobileNumberOtp, $newPasswordToken,$current_timeout);
                    $this->_smsHelper->sendMessage($mobileNumberOtp, "register", $otp);
                    $data['message'] = 'OTP Sent Successfully';
                }
                if($email){
                    $id = $this->getIdFromEmail($email);
                    $this->_otpLogger->setCustomerOtp($id, $otp, $email, $newPasswordToken,$current_timeout);
                    $otptemplateid = $this->_scopeConfig->getValue('smsmodule/sms/register_email_template', \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
                    $this->helper->sendMail($otptemplateid,$email,$otp);
                    $data['message'] = 'OTP Sent Successfully';
                }
            } catch (\Exception $ex) {
                $data['error'] = 1;
                $data['message'] = $ex->getMessage();
                $resultJson->setData($data);
                return $resultJson;
            }
            
            $resultJson->setData($data);
            return $resultJson;
    }

    /**
     * @param $mobileNumber
     * @return mixed
     */
    public function getEmailFromMobile($mobileNumber)
    {
        $websiteId = $this->_customerHelper->getWebsiteId();
        if ($this->_customerHelper->getAccountSharingOptions()) {
            $email = $this->_customerFactory->create()->getCollection()
                ->addFieldToFilter("website_id", $websiteId)
                ->addFieldToFilter('mobile_number', $mobileNumber)
                ->getFirstItem()
                ->getId();
        } else {
            $email = $this->_customerFactory->create()->getCollection()
                ->addFieldToFilter('mobile_number', $mobileNumber)
                ->getFirstItem()
                ->getId();
        }

        return $email;
    }
    /**
     * @param $email
     * @return mixed
     */
    public function getIdFromEmail($email)
    {
        $websiteId = $this->_customerHelper->getWebsiteId();
        if ($this->_customerHelper->getAccountSharingOptions()) {
            $id = $this->_customerFactory->create()->getCollection()
                ->addFieldToFilter("website_id", $websiteId)
                ->addFieldToFilter('email', $email)
                ->getFirstItem()
                ->getId();
        } else {
            $id = $this->_customerFactory->create()->getCollection()
                ->addFieldToFilter('email', $email)
                ->getFirstItem()
                ->getId();
        }
        return $id;
    }

}
