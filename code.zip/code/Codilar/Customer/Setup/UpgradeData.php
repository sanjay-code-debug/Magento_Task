<?php

namespace Codilar\Customer\Setup;

use Magento\Eav\Model\Config;
use Magento\Eav\Setup\EavSetupFactory;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\ModuleDataSetupInterface;
use Magento\Framework\Setup\UpgradeDataInterface;
use Magento\Variable\Model\VariableFactory;

/**
 * Class UpgradeData
 * @package Codilar\Customer\Setup
 */
class UpgradeData implements UpgradeDataInterface
{
    /**
     * @var EavSetupFactory
     */
    private $eavSetupFactory;
    /**
     * @var VariableFactory
     */
    private $varFactory;

    /**
     * UpgradeData constructor.
     * @param EavSetupFactory $eavSetupFactory
     * @param Config          $eavConfig
     * @param VariableFactory $varFactory
     */
    public function __construct(
        EavSetupFactory $eavSetupFactory,
        Config $eavConfig,
        VariableFactory $varFactory
    )
    {
        $this->eavSetupFactory = $eavSetupFactory;
        $this->eavConfig = $eavConfig;
        $this->varFactory = $varFactory;
    }

    /**
     * @param ModuleDataSetupInterface $setup
     * @param ModuleContextInterface   $context
     * @throws \Exception
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function upgrade(ModuleDataSetupInterface $setup, ModuleContextInterface $context)
    {
        $installer = $setup;

        if (version_compare($context->getVersion(), '1.0.1', '<')) {
            // To create country code attribute
            $eavSetup = $this->eavSetupFactory->create(['setup' => $setup]);
            $eavSetup->addAttribute(
                \Magento\Customer\Model\Customer::ENTITY,
                'country_code',
                [
                    'type' => 'varchar',
                    'label' => 'Country Code',
                    'input' => 'text',
                    'source' => 'Magento\Eav\Model\Entity\Attribute\Source\Boolean',
                    'required' => false,
                    'default' => null,
                    'sort_order' => 110,
                    'system' => false,
                    'position' => 110
                ]
            );
            $countryCodeAttribute = $this->eavConfig->getAttribute(\Magento\Customer\Model\Customer::ENTITY, 'country_code');
            $countryCodeAttribute->addData([
                'used_in_forms' => ['adminhtml_customer', 'customer_account_create', 'customer_account_edit'],
                'is_used_in_grid' => 1,
                'is_visible_in_grid' => 1,
                'is_searchable_in_grid' => 1,
                'is_filterable_in_grid' => 1
            ]);
            $countryCodeAttribute->save();
        }

        if (version_compare($context->getVersion(), '1.0.3', '<')) {
            // To create country code attribute
            $eavSetup = $this->eavSetupFactory->create(['setup' => $setup]);
            $eavSetup->addAttribute(
                \Magento\Customer\Model\Customer::ENTITY,
                'region',
                [
                    'type' => 'varchar',
                    'label' => 'Region',
                    'input' => 'text',
                    'source' => 'Magento\Eav\Model\Entity\Attribute\Source\Boolean',
                    'required' => false,
                    'default' => null,
                    'sort_order' => 120,
                    'system' => false,
                    'position' => 120
                ]
            );
            $regionAttribute = $this->eavConfig->getAttribute(\Magento\Customer\Model\Customer::ENTITY, 'region');
            $regionAttribute->addData([
                'used_in_forms' => ['adminhtml_customer', 'customer_account_create', 'customer_account_edit']
            ]);
            $regionAttribute->save();
        }
        
        if (version_compare($context->getVersion(), '1.0.6', '<')) {
            // To create country code attribute
            $eavSetup = $this->eavSetupFactory->create(['setup' => $setup]);
            $eavSetup->removeAttribute(
                \Magento\Customer\Model\Customer::ENTITY,
                'pincode'
            );
            $eavSetup->addAttribute(
                \Magento\Customer\Model\Customer::ENTITY,
                'pincode',
                [
                    'type' => 'varchar',
                    'label' => 'Pincode',
                    'input' => 'text',
                    'source' => 'Magento\Eav\Model\Entity\Attribute\Source\Boolean',
                    'required' => false,
                    'default' => 0,
                    'sort_order' => 125,
                    'system' => false,
                    'position' => 125
                ]
            );
            $pincodeAttribute = $this->eavConfig->getAttribute(\Magento\Customer\Model\Customer::ENTITY, 'pincode');
            $pincodeAttribute->addData([
                'used_in_forms' => ['adminhtml_customer', 'customer_account_create', 'customer_account_edit']
            ]);
            $pincodeAttribute->save();
        }
        if (version_compare($context->getVersion(), '1.0.9', '<')) {
            // To create country code attribute
            $eavSetup = $this->eavSetupFactory->create(['setup' => $setup]);
            $eavSetup->removeAttribute(
                \Magento\Customer\Model\Customer::ENTITY,
                'gst_number'
            );
            $eavSetup->addAttribute( 
                \Magento\Customer\Model\Customer::ENTITY,
                'gst_number',
                [
                    'type' => 'varchar',
                    'label' => 'GST Number',
                    'input' => 'text',
                    'source' => 'Magento\Eav\Model\Entity\Attribute\Source\Boolean',
                    'required' => false,
                    'default' => 0,
                    'sort_order' => 125,
                    'system' => false,
                    'position' => 125
                ]
            );
            $gstAttribute = $this->eavConfig->getAttribute(\Magento\Customer\Model\Customer::ENTITY, 'gst_number');
            $gstAttribute->addData([
                'used_in_forms' => ['adminhtml_customer', 'customer_account_create', 'customer_account_edit']
            ]);
            $gstAttribute->save();
        }
        if (version_compare($context->getVersion(), '1.1.0', '<')) {
            // To create country code attribute
            $eavSetup = $this->eavSetupFactory->create(['setup' => $setup]);
            $eavSetup->removeAttribute(
                \Magento\Customer\Model\Customer::ENTITY,
                'is_gst_registered'
            );
            $eavSetup->addAttribute( 
                \Magento\Customer\Model\Customer::ENTITY,
                'is_gst_registered',
                [
                    'type' => 'varchar',
                    'label' => 'Is GST registered',
                    'input' => 'text',
                    'source' => 'Magento\Eav\Model\Entity\Attribute\Source\Boolean',
                    'required' => false,
                    'default' => 0,
                    'sort_order' => 125,
                    'system' => false,
                    'position' => 125
                ]
            );
            $eavSetup->removeAttribute(
                \Magento\Customer\Model\Customer::ENTITY,
                'is_agree_terms_condition'
            );
            $eavSetup->addAttribute( 
                \Magento\Customer\Model\Customer::ENTITY,
                'is_agree_terms_condition',
                [
                    'type' => 'varchar',
                    'label' => 'Is agree terms',
                    'input' => 'text',
                    'source' => 'Magento\Eav\Model\Entity\Attribute\Source\Boolean',
                    'required' => false,
                    'default' => 1,
                    'sort_order' => 125,
                    'system' => false,
                    'position' => 125
                ]
            );
            
            $termsAttribute = $this->eavConfig->getAttribute(\Magento\Customer\Model\Customer::ENTITY, 'is_agree_terms_condition');
            $termsAttribute->addData([
                'used_in_forms' => ['adminhtml_customer', 'customer_account_create']
            ]);
            $termsAttribute->save();

            $gst_registerAttribute = $this->eavConfig->getAttribute(\Magento\Customer\Model\Customer::ENTITY, 'is_gst_registered');
            $gst_registerAttribute->addData([
                'used_in_forms' => ['adminhtml_customer', 'customer_account_create','customer_account_edit']
            ]);

            $gst_registerAttribute->save();
        }
        if (version_compare($context->getVersion(), '1.1.2', '<')) {
            // To create base country attribute
            $eavSetup = $this->eavSetupFactory->create(['setup' => $setup]);
            $eavSetup->removeAttribute(
                \Magento\Customer\Model\Customer::ENTITY,
                'base_country'
            );
            $eavSetup->addAttribute(
                \Magento\Customer\Model\Customer::ENTITY,
                'base_country',
                [
                    'type' => 'varchar',
                    'label' => 'Base Country',
                    'input' => 'text',
                    'source' => '',
                    'required' => false,
                    'visible' => true,
                    'sort_order' => 135,
                    'system' => false,
                    'position' => 135
                ]
            );
            $pincodeAttribute = $this->eavConfig->getAttribute(\Magento\Customer\Model\Customer::ENTITY, 'base_country');
            $pincodeAttribute->addData([
                'used_in_forms' => ['adminhtml_customer', 'customer_account_create', 'customer_account_edit']
            ]);
            $pincodeAttribute->save();
        }
        $installer->endSetup();
    }
}