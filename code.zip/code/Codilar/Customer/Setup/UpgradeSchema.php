<?php
 
namespace Codilar\Customer\Setup;

use Magento\Framework\DB\Ddl\Table;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\SchemaSetupInterface;
use Magento\Framework\Setup\UpgradeSchemaInterface;

/**
 * Class UpgradeSchema
 * @package Codilar\Customer\Setup
 */
class UpgradeSchema implements UpgradeSchemaInterface
{
    /**
     * 
     * @param SchemaSetupInterface $setup
     * @param ModuleContextInterface $context
     */
    public function upgrade(
        SchemaSetupInterface $setup,
        ModuleContextInterface $context
    )
    {
        $installer = $setup;

        $installer->startSetup();
        if (version_compare($context->getVersion(), '1.1.3', '<')) {
            $tableName = $setup->getTable('codilar_otp');
            $installer->getConnection()->addColumn(
                $installer->getTable($tableName),
                'email',
                [
                    'type' => Table::TYPE_TEXT,
                    'comment' => 'Email'
                ]
            );
        }
        $installer->endSetup();
    }
}