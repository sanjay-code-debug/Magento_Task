<?php

namespace Codilar\Customer\Model;

use Magento\Customer\Api\CustomerRepositoryInterface;
use Magento\Framework\Encryption\EncryptorInterface as Encryptor;
use Magento\Framework\Model\Context;
use Magento\Framework\Registry;

/**
 * Class OtpLogger
 * @package Codilar\Customer\Model
 */
class OtpLogger extends \Magento\Framework\Model\AbstractModel
{
    /**
     * @var \Codilar\Customer\Model\Otp
     */
    protected $_otpLogger;
    /**
     * @var Encryptor
     */
    protected $encryptor;
    /**
     * @var CustomerRepositoryInterface
     */
    private $customerRepository;

    /**
     * OtpLogger constructor.
     * @param Context                     $context
     * @param Registry                    $registry
     * @param Encryptor                   $encryptor
     * @param \Codilar\Customer\Model\Otp $otpLogger
     * @param CustomerRepositoryInterface $customerRepository
     */
    public function __construct(
        Context $context,
        Registry $registry,
        Encryptor $encryptor,
        Otp $otpLogger,
        CustomerRepositoryInterface $customerRepository
    )
    {
        $this->encryptor = $encryptor;
        $this->_otpLogger = $otpLogger;
        $this->customerRepository = $customerRepository;
        parent::__construct($context, $registry);
    }

    /**
     * @param $customerId
     * @param $otp
     * @param $mobileNumber
     * @param $token
     * @return bool
     */
    public function setCustomerOtp($customerId, $otp, $mobileNumber, $token,$current_timeout)
    {
        if(!$customerId){
            $customerId = null;
        }

        $loggerId = $this->_otpLogger->getCollection()
            ->addFieldToFilter("customer_id", $customerId)
            ->getFirstItem()
            ->getId();
        $logData['id'] = null;
        $otpEncrypted = $otp;
        $email = null;
        if (!is_numeric($mobileNumber)) {
            $email = $mobileNumber;
            $mobileNumber = null;
        }
        if ($loggerId) {
            $logData = [
                "id" => $loggerId,
                "customer_id" => $customerId,
                "mobile_number" => $mobileNumber,
                "otp" => $otpEncrypted,
                "rp_token" => $token,
                "timeout" => $current_timeout,
                "email" => $email
            ];
        } else {
            $logData = [
                "customer_id" => $customerId,
                "mobile_number" => $mobileNumber,
                "otp" => $otpEncrypted,
                "rp_token" => $token,
                "timeout" => $current_timeout,
                "email" => $email
            ];
        }
        $model = $this->_otpLogger;
        $model->setData($logData);
        try {
            $model->getResource()->save($model);
            return true;
        } catch (\Exception $e) {
            return false;
        }
    }

    /**
     * @param $customerId
     * @param $otp
     * @param $mobileNumber
     * @return bool
     */
    public function validateOtp($customerId, $otp, $mobileNumber)
    {

        $email = null;
        if (!is_numeric($mobileNumber)) {
            $otp_data = $this->_otpLogger->getCollection()
                ->addFieldToFilter("email", $mobileNumber)
                ->getLastItem();
        } else {
            $otp_data = $this->_otpLogger->getCollection()
                ->addFieldToFilter("mobile_number", $mobileNumber)
                ->getLastItem();
        }
        $mins = 5;
            $timeout = $otp_data->getTimeout();
            $new_time = $timeout + $mins * 60;
            if ($new_time < time()) {
                return false;
            }
            $otpData = $otp_data->getOtp();

        if ($otpData) {
            if ($otp == $otpData) {
                return true;
            }
        }
        \Magento\Framework\App\ObjectManager::getInstance()
    ->get(\Psr\Log\LoggerInterface::class)->debug(json_encode($otpData).$customerId.$mobileNumber.$otp);
        return false;
    }

    /**
     * @param $customerId
     * @param $mobileNumber
     * @return bool|\Magento\Framework\DataObject
     */
    public function getOtpData($customerId, $mobileNumber)
    {
        $otpData = $this->_otpLogger->getCollection()
            ->addFieldToFilter("customer_id", $customerId)
            ->addFieldToFilter("mobile_number", $mobileNumber)
            ->getFirstItem();
        if ($otpData) {
            return $otpData;
        }
        return false;
    }

}