<?php

namespace Codilar\Customer\Model\ResourceModel\Otp;
/**
 * Class Collection
 * @package Codilar\Customer\Model\ResourceModel\Otp
 */
class Collection extends \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection
{
    protected function _construct()
    {
        $this->_init('Codilar\Customer\Model\Otp', 'Codilar\Customer\Model\ResourceModel\Otp');
    }
}
