<?php

namespace Codilar\Customer\Model\ResourceModel\PasswordLogger;

use Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection;

/**
 * Class Collection
 * @package Codilar\Customer\Model\ResourceModel\PasswordLogger
 */
class Collection extends AbstractCollection
{
    /**
     * Define model & resource model
     */
    protected $_idFieldName = 'log_id';

    protected function _construct()
    {
        $this->_init(
            'Codilar\Customer\Model\PasswordLogger',
            'Codilar\Customer\Model\ResourceModel\PasswordLogger'
        );
    }
}