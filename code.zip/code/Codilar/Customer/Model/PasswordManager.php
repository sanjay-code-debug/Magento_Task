<?php

namespace Codilar\Customer\Model;

use Magento\Customer\Api\CustomerRepositoryInterface;
use Magento\Framework\Encryption\EncryptorInterface as Encryptor;
use Magento\Framework\Exception\InvalidEmailOrPasswordException;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\Model\Context;
use Magento\Framework\Stdlib\DateTime\TimezoneInterface;

/**
 * Class PasswordManager
 * @package Codilar\Customer\Model
 */
class PasswordManager extends \Magento\Framework\Model\AbstractModel
{
    /**
     * @var \Codilar\Customer\Model\PasswordLogger
     */
    protected $_passwordLogger;
    /**
     * @var Encryptor
     */
    protected $encryptor;
    /**
     * @var TimezoneInterface
     */
    protected $_timezoneInterface;
    /**
     * @var CustomerRepositoryInterface
     */
    private $customerRepository;

    /**
     * PasswordManager constructor.
     * @param Context                                $context
     * @param \Magento\Framework\Registry            $registry
     * @param Encryptor                              $encryptor
     * @param \Codilar\Customer\Model\PasswordLogger $passwordLogger
     * @param TimezoneInterface                      $timezoneInterface
     * @param CustomerRepositoryInterface            $customerRepository
     */
    public function __construct(
        Context $context,
        \Magento\Framework\Registry $registry,
        Encryptor $encryptor,
        PasswordLogger $passwordLogger,
        TimezoneInterface $timezoneInterface,
        CustomerRepositoryInterface $customerRepository
    )
    {
        $this->encryptor = $encryptor;
        $this->_passwordLogger = $passwordLogger;
        $this->customerRepository = $customerRepository;
        $this->_timezoneInterface = $timezoneInterface;
        parent::__construct($context, $registry);
    }

    /**
     * @param $customerId
     * @param $password
     * @return bool
     */
    public function setPassword($customerId, $password)
    {
        $encryptedPassword = $this->encryptor->getHash($password, true);
        $data = [
            "customer_id" => $customerId,
            "password_hash" => $encryptedPassword
        ];
        $model = $this->_passwordLogger;
        $model->setData($data);
        try {
            $model->getResource()->save($model);
            return true;
        } catch (\Exception $e) {
            return false;
        }
    }

    /**
     * @param $email
     * @param $password
     * @return bool
     * @throws InvalidEmailOrPasswordException
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function setPasswordWithEmail($email, $password)
    {
        try {
            $customer = $this->customerRepository->get($email);
            $customerId = $customer->getId();
        } catch (NoSuchEntityException $e) {
            throw new InvalidEmailOrPasswordException(__('Invalid login or password.'));
        }
        $encryptedPassword = $this->encryptor->getHash($password, true);
        $data = [
            "customer_id" => $customerId,
            "password_hash" => $encryptedPassword
        ];
        $model = $this->_passwordLogger;
        $model->setData($data);
        try {
            $model->getResource()->save($model);
            return true;
        } catch (\Exception $e) {
            return false;
        }
    }

    /**
     * @param bool $customerId
     * @param bool $email
     * @param      $password
     * @return bool
     * @throws NoSuchEntityException
     * @throws \Exception
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function validatePassword($customerId = false, $email = false, $password)
    {
        if ($customerId || $email) {
            if (!$customerId && $email) {
                $customerId = $this->customerRepository->get($email)->getId();
            }
            $storeTime = $this->getStoreTime();
            $oneYearDate = date("Y-m-d H:i:s", strtotime('-1 years', strtotime($storeTime)));
            $lastFivepasswords = $this->_passwordLogger->getCollection()
                ->addFieldToFilter("customer_id", $customerId)
                ->setOrder("created_at", "desc")
                ->setPageSize(5);
            $lastOneYearPasswords = $this->_passwordLogger->getCollection()
                ->addFieldToFilter("customer_id", $customerId)
                ->addFieldToFilter('created_at', ['from' => $oneYearDate, 'to' => $storeTime]);
            foreach ($lastFivepasswords as $hash) {
                if ($this->encryptor->isValidHash($password, $hash->getPasswordHash())) {
                    return false;
                }
            }
            foreach ($lastOneYearPasswords as $hash) {
                if ($this->encryptor->isValidHash($password, $hash->getPasswordHash())) {
                    return false;
                }
            }
            return true;
        } else {
            return false;
        }
    }

    /**
     * Returns current store time according to timezone
     *
     * @return string
     */
    public function getStoreTime()
    {
        $today = $this->_timezoneInterface->date()->format('Y-m-d H:i:s');
        return $today;
    }
}