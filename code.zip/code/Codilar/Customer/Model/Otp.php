<?php

namespace Codilar\Customer\Model;
/**
 * Class Otp
 * @package Codilar\Customer\Model
 */
class Otp extends \Magento\Framework\Model\AbstractModel
{
    /**
     *
     */
    const CACHE_TAG = 'codilar_otp';

    /**
     * @return array
     */
    public function getIdentities()
    {
        return [self::CACHE_TAG . '_' . $this->getId()];
    }

    protected function _construct()
    {
        $this->_init('Codilar\Customer\Model\ResourceModel\Otp');
    }
}
