<?php

namespace Codilar\Customer\Model\Resolver;

use Codilar\Customer\Model\ResourceModel\Otp\Collection;

use Magento\Framework\GraphQl\Config\Element\Field;
use Magento\Framework\GraphQl\Query\ResolverInterface;
use Magento\Framework\GraphQl\Schema\Type\ResolveInfo;


class OtpTokenValue implements ResolverInterface {

    /**
     * @var Collection
     */
    private  $otpCollection;

    /**
     * @param Collection $otpCollection
     */
    public function __construct(Collection $otpCollection)
    {
        $this->otpCollection = $otpCollection;
    }

    /**
     * @param Field $field
     * @param \Magento\Framework\GraphQl\Query\Resolver\ContextInterface $context
     * @param ResolveInfo $info
     * @param array|null $value
     * @param array|null $args
     * @return array
     */
    public function resolve(Field $field, $context, ResolveInfo $info, array $value = null, array $args = null){

             global  $ar;
             $ar = array();

                $mobile = filter_var($args['mobile'], FILTER_SANITIZE_NUMBER_INT);

                $r = $this->otpCollection->addFieldToFilter('mobile_number',$mobile);

                foreach ($r as $f=>$value)
                {
                      $otp = $value['otp'];
                      $tok = $value['rp_token'];

                     $ar[]=['otp_code'=>$otp, 'token'=>$tok];
                }

        return $ar;
    }
}
