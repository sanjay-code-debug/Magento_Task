<?php

namespace Codilar\Customer\Helper;

use Codilar\Customer\Model\PasswordLogger;
use Magento\Customer\Api\CustomerRepositoryInterface;
use Magento\Customer\Model\Account\Redirect as AccountRedirect;
use Magento\Customer\Model\Context as CustomerContext;
use Magento\Customer\Model\CustomerFactory;
use Magento\Customer\Model\CustomerRegistry;
use Magento\Customer\Model\Data\CustomerSecureFactory;
use Magento\Framework\App\Helper\Context;
use Magento\Framework\Data\Form\FormKey;
use Magento\Framework\Data\Form\FormKey\Validator;
use Magento\Framework\Encryption\EncryptorInterface as Encryptor;
use Magento\Framework\Math\Random;
use Magento\Framework\View\Element\Html\Link;
use Magento\Store\Model\StoreManagerInterface;
use Psr\Log\LoggerInterface;
use Magento\Customer\Model\Session as CustomerSession;


/**
 * Class Data
 * @package Codilar\Customer\Helper
 */
class Data extends \Magento\Framework\App\Helper\AbstractHelper
{
    /**
     * @var $_scopeConfigInterface
     */
    protected $_scopeConfig;
    /**
     * @var LoggerInterface
     */
    protected $_logger;
    /**
     * @var StoreManagerInterface
     */
    protected $_storeManager;
    /**
     * @var FormKey
     */
    protected $_formKey;
    /**
     * @var Encryptor
     */
    protected $encryptor;
    /**
     * @var \Codilar\Customer\Model\PasswordLogger
     */
    protected $_passwordLogger;
    /**
     * @var CustomerRepositoryInterface
     */
    protected $customerRepository;
    /**
     * @var CustomerFactory
     */
    protected $_customerFactory;
    /**
     * @var \Magento\Framework\Data\Helper\PostHelper
     */
    protected $_postDataHelper;
    /**
     * @var \Magento\Customer\Model\Url
     */
    protected $_customerUrl;
    /**
     * @var \Magento\Framework\App\Http\Context
     */
    protected $httpContext;
    /**
     * @var Link
     */
    protected $link;
    /**
     * @var Validator
     */
    private $formKeyValidator;
    /**
     * @var AccountRedirect
     */
    private $accountRedirect;
    /**
     * @var Random
     */
    private $mathRandom;
    /**
     * @var CustomerRegistry
     */
    private $customerRegistry;
    /**
     * @var CustomerSecureFactory
     */
    private $customerSecureFactory;
    /**
     * @var _transportbuilder
     */
    protected $_transportbuilder;

    protected $_customersession;

    /**
     * Data constructor.
     * @param Context                                   $context
     * @param StoreManagerInterface                     $storeManager
     * @param Validator|null                            $formKeyValidator
     * @param FormKey                                   $formKey
     * @param LoggerInterface                           $loggerInterface
     * @param Encryptor                                 $encryptor
     * @param PasswordLogger                            $passwordLogger
     * @param CustomerRepositoryInterface               $customerRepository
     * @param AccountRedirect                           $accountRedirect
     * @param CustomerRegistry                          $customerRegistry
     * @param CustomerSecureFactory                     $customerSecureFactory
     * @param CustomerFactory                           $customerFactory
     * @param Random                                    $mathRandom
     * @param \Magento\Framework\App\Http\Context       $httpContext
     * @param \Magento\Customer\Model\Url               $customerUrl
     * @param \Magento\Framework\Data\Helper\PostHelper $postDataHelper
     * @param Link                                      $link
     */
    public function __construct(
        Context $context,
        StoreManagerInterface $storeManager,
        Validator $formKeyValidator = null,
        FormKey $formKey,
        LoggerInterface $loggerInterface,
        Encryptor $encryptor,
        PasswordLogger $passwordLogger,
        CustomerRepositoryInterface $customerRepository,
        AccountRedirect $accountRedirect,
        CustomerRegistry $customerRegistry,
        CustomerSecureFactory $customerSecureFactory,
        CustomerFactory $customerFactory,
        Random $mathRandom,
        \Magento\Framework\App\Http\Context $httpContext,
        \Magento\Customer\Model\Url $customerUrl,
        \Magento\Framework\Data\Helper\PostHelper $postDataHelper,
        Link $link,
        \Magento\Framework\Mail\Template\TransportBuilder $_transportbuilder,
        CustomerSession $_customersession
    )
    {
        $this->_scopeConfig = $context->getScopeConfig();
        $this->_storeManager = $storeManager;
        $this->_logger = $loggerInterface;
        $this->formKeyValidator = $formKeyValidator;
        $this->_formKey = $formKey;
        $this->accountRedirect = $accountRedirect;
        $this->encryptor = $encryptor;
        $this->_passwordLogger = $passwordLogger;
        $this->customerRepository = $customerRepository;
        $this->mathRandom = $mathRandom;
        $this->customerRegistry = $customerRegistry;
        $this->customerSecureFactory = $customerSecureFactory;
        $this->_customerFactory = $customerFactory;
        $this->httpContext = $httpContext;
        $this->_customerUrl = $customerUrl;
        $this->_postDataHelper = $postDataHelper;
        $this->link = $link;
        $this->_customersession = $_customersession;
        $this->_transportbuilder = $_transportbuilder;
        parent::__construct($context);
    }

     /**
     * @return mixed
     */
    public function getCustomerName()
    {
        return $this->_customersession->getCustomer()->getName();
    }
    /**
     * @return mixed
     */
    public function getAccountSharingOptions()
    {
        return $this->_scopeConfig->getValue('customer/account_share/scope', \Magento\Store\Model\ScopeInterface::SCOPE_WEBSITE);
    }

    /**
     * @param \Magento\Framework\App\RequestInterface $request
     * @return bool
     */
    public function formKeyValidator(\Magento\Framework\App\RequestInterface $request)
    {
        $formKey = $request->getParam('form_key', null);
        if (!$formKey || $formKey !== $this->_formKey->getFormKey()) {
            return false;
        }
        return true;
    }

    /**
     * @return bool|int
     */
    public function getWebsiteId()
    {
        try {
            return $this->_storeManager->getWebsite()->getId();
        } catch (\Exception $e) {
            return false;
        }
    }

    /**
     * @return string
     */
    public function getWebsiteCode()
    {
        try {
            return $this->_storeManager->getWebsite()->getCode();
        } catch (\Exception $e) {
            return "default";
        }
    }

    /**
     * @return \Magento\Framework\Controller\Result\Forward|\Magento\Framework\Controller\Result\Redirect
     */
    public function getRedirect()
    {
        return $this->accountRedirect->getRedirect();
    }

    /**
     * @return null|string
     */
    public function getRedirectCookie()
    {
        $cookie = $this->accountRedirect->getRedirectCookie();
        return $cookie;
    }

    /**
     * @param $email
     * @param $websiteId
     * @return \Magento\Customer\Api\Data\CustomerInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     */
    public function getCustomerByEmail($email, $websiteId)
    {
        $customer = $this->customerRepository->get($email, $websiteId);
        return $customer;
    }

    /**
     * @param $customerId
     * @return \Magento\Customer\Api\Data\CustomerInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     */
    public function getCustomerById($customerId)
    {
        $customer = $this->customerRepository->getById($customerId);
        return $customer;
    }

    /**
     * @return string
     */
    public function getUniqueHash()
    {
        $hash = $this->mathRandom->getUniqueHash();
        return $hash;
    }

    /**
     * @param $customerId
     * @return \Magento\Customer\Model\Data\CustomerSecure
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     */
    public function retrieveSecureData($customerId)
    {
        return $this->customerRegistry->retrieveSecureData($customerId);
    }

    /**
     * @param $customer
     * @return bool
     * @throws \Magento\Framework\Exception\InputException
     * @throws \Magento\Framework\Exception\LocalizedException
     * @throws \Magento\Framework\Exception\State\InputMismatchException
     */
    public function saveCustomer($customer)
    {
        $this->customerRepository->save($customer);
        return true;
    }

    /**
     * @param $path
     * @return mixed
     */
    public function getScopeConfigValue($path)
    {
        return $this->_scopeConfig->getValue($path, \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
    }

    /**
     * @param $customer
     * @return \Magento\Customer\Model\Customer
     */
    public function updateCustomerData($customer)
    {
        $customerModel = $this->_customerFactory->create()->updateData($customer);
        return $customerModel;
    }

    /**
     * @return string
     */
    public function getPostParams()
    {
        return $this->_postDataHelper->getPostData($this->getHref());
    }

    /**
     * @return string
     */
    public function getHref()
    {
        return $this->isLoggedIn()
            ? $this->_customerUrl->getLogoutUrl()
            : $this->_customerUrl->getLoginUrl();
    }

    /**
     * Is logged in
     *
     * @return bool
     */
    public function isLoggedIn()
    {
        return $this->httpContext->getValue(CustomerContext::CONTEXT_AUTH);
    }

    /**
     * @return string
     */
    public function getLinkAttributes()
    {
        return $this->link->getLinkAttributes();
    }

    public function getMinQty()
    {
        return $this->_scopeConfig->getValue('feedback/min_cart_qty_config/min_cart_qty', \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
    }

    public function sendMail($template,$receiver,$data){

        try {
            $storeid = $this->_storeManager->getStore()->getId();
            $templateId = $template;
            $customer_email = $receiver;

            $senderName = $this->_scopeConfig->getValue("trans_email/ident_general/name", \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
            $senderEmail = $this->_scopeConfig->getValue("trans_email/ident_general/email", \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
            $sender = [
                'name' => $senderName,
                'email' => $senderEmail,
            ];
            $vars = [
                'data' => $data
            ];
            if ($templateId && $senderEmail) {
                $transport = $this->_transportbuilder
                    ->setTemplateIdentifier($templateId)
                    ->setTemplateOptions(['area' => \Magento\Framework\App\Area::AREA_FRONTEND, 'store' => $storeid])
                    ->setTemplateVars($vars)
                    ->setFrom($sender)
                    ->addTo($customer_email, "Rehandel")
                    ->getTransport();
                $transport->sendMessage();
            }
        }
        catch (\Exception $e){
            $this->_logger->debug($e->getMessage());
        }
    }
}
