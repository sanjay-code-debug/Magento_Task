<?php
/**
 * Created by salman.
 * Date: 20/3/18
 * Time: 6:30 PM
 * Filename: ProductSaveTrigger.php
 */

namespace Codilar\Common\Console;

use Magento\Catalog\Model\ResourceModel\Product\CollectionFactory;
use Symfony\Component\Console\Command\Command;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Input\InputOption;
use Symfony\Component\Console\Output\OutputInterface;

/**
 * Class ProductSaveTrigger
 * @package Codilar\Common\Console
 */
class ProductSaveTrigger extends Command
{
    /**
     *
     */
    CONST PRODUCT_TYPE = 'type';
    /**
     * @var array
     */
    public $productType = ['configurable', 'simple', 'grouped', 'bundled', 'virtual', 'downloadable'];
    /**
     * @var CollectionFactory
     */
    protected $_productCollection;
    /**
     * @var \Magento\Framework\App\State
     */
    protected $appState;

    /**
     * ProductSaveTrigger constructor.
     * @param CollectionFactory            $collectionFactory
     * @param \Magento\Framework\App\State $appState
     */
    public function __construct(
        CollectionFactory $collectionFactory,
        \Magento\Framework\App\State $appState
    )
    {
        $this->_productCollection = $collectionFactory;
        $this->appState = $appState;
        parent::__construct();
    }

    /**
     * @param InputInterface  $input
     * @param OutputInterface $output
     * @return $this|int|null
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    protected function execute(InputInterface $input, OutputInterface $output)
    {
        $this->appState->setAreaCode(\Magento\Framework\App\Area::AREA_GLOBAL);
        if (in_array($input->getOption(self::PRODUCT_TYPE), $this->productType)) {
            $collection = $this->getProductCollection($input->getOption(self::PRODUCT_TYPE));
            if ($total = count($collection)) {
                $i = 1;
                foreach ($collection as $product) {
                    $product->save();
                    $output->writeln("<info>{$product->getSku()} saved..($i/$total) </info>");
                    $i++;
                }
            } else {
                $output->writeln("<error>No Products found</error>");
            }
        } else {
            $output->writeln("<error>Invalid product type.Command Ex : bin/magento codilar:productsave:trigger --type simple</error>");
        }
        return $this;
    }

    /**
     * @param $type
     * @return \Magento\Catalog\Model\ResourceModel\Product\Collection
     */
    private function getProductCollection($type)
    {
        $collection = $this->_productCollection->create()
            ->addAttributeToFilter('type_id', $type)
            ->addAttributeToFilter('status', 1);
        return $collection;
    }

    protected function configure()
    {
        $options = [
            new InputOption(
                self::PRODUCT_TYPE,
                null,
                InputOption::VALUE_REQUIRED,
                'Product Type'
            )
        ];
        $this->setName('codilar:productsave:trigger')
            ->setDescription('Trigger Product Save')
            ->setDefinition($options);
        parent::configure();
    }

}