<?php

namespace Codilar\Common\Console;

use Magento\Catalog\Api\ProductRepositoryInterface;
use Psr\Log\LoggerInterface;
use Symfony\Component\Console\Command\Command;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Input\InputOption;
use Symfony\Component\Console\Output\OutputInterface;

/**
 * Class ProductSaveTriggerCache
 * @package Codilar\Common\Console
 */
class ProductSaveTriggerCache extends Command
{
    /**
     * @var \Magento\Framework\App\State
     */
    protected $appState;
    /**
     * @var LoggerInterface
     */
    private $logger;
    /**
     * @var ProductRepositoryInterface
     */
    private $productRepository;

    /**
     * ProductSaveTriggerCache constructor.
     * @param \Magento\Framework\App\State $appState
     * @param ProductRepositoryInterface $productRepository
     * @param LoggerInterface $logger
     */
    public function __construct(
        \Magento\Framework\App\State $appState,
        ProductRepositoryInterface $productRepository,
        LoggerInterface $logger
    )
    {
        $this->appState = $appState;
        parent::__construct();
        $this->logger = $logger;
        $this->productRepository = $productRepository;
    }

    /**
     * @param InputInterface  $input
     * @param OutputInterface $output
     * @return $this|int|null
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    protected function execute(InputInterface $input, OutputInterface $output)
    {
        set_time_limit(0);
        try{
            $this->appState->setAreaCode(\Magento\Framework\App\Area::AREA_GLOBAL);
            // get skus
            $skus = $input->getOption('skus');
            $productSkus = json_decode(base64_decode($skus));
            if($productSkus){
                foreach ($productSkus as $sku){
                    $product = $this->productRepository->get($sku);
                    $product->save();
                }
            }
            else {
                $output->writeln("<error>Invalid product Skus </error>");
            }
        }
        catch (\Exception $e){
            //$this->logger->debug("Error ".$e->getMessage());
        }
        return $this;
    }

    protected function configure()
    {
        $options = [
            new InputOption(
                "skus",
                null,
                InputOption::VALUE_REQUIRED,
                'Product Skus'
            )
        ];
        $this->setName('codilar:productsave:trigger:cache')
            ->setDescription('Trigger Product Save Cache')
            ->setDefinition($options);
        parent::configure();
    }

}