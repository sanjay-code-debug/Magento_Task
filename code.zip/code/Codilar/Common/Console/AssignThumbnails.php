<?php
/**
 * Created by salman.
 * Date: 16/2/18
 * Time: 5:03 PM
 * Filename: AddTrackIdInItem.php
 */

namespace Codilar\Common\Console;


use Magento\Catalog\Model\Product\Action;
use Magento\Catalog\Model\ResourceModel\Product\CollectionFactory;
use Magento\Framework\App\Filesystem\DirectoryList;
use Magento\Framework\App\ResourceConnection;
use Magento\Store\Model\StoreManager;
use Psr\Log\LoggerInterface;
use Symfony\Component\Console\Command\Command;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;

/**
 * Class AssignThumbnails
 * @package Codilar\Common\Console
 */
class AssignThumbnails extends Command
{
    /**
     * @var LoggerInterface
     */
    protected $logger;
    /**
     * @var \Magento\Catalog\Api\ProductRepositoryInterfaceFactory
     */
    protected $_productRepositoryFactory;
    /**
     * @var
     */
    protected $_storeManager;
    /**
     * @var ResourceConnection
     */
    protected $_resource;
    /**
     * @var CollectionFactory
     */
    protected $_productCollection;
    /**
     * @var \Magento\Framework\App\State
     */
    protected $appState;
    /**
     * @var \Magento\Catalog\Model\Product\Media\Config
     */
    protected $_catalogProductMediaConfig;
    /**
     * @var \Magento\Framework\Filesystem\Directory\WriteInterface
     */
    protected $_mediaDirectory;
    /**
     * @var \Magento\MediaStorage\Helper\File\Storage\Database|null
     */
    protected $_coreFileStorageDatabase = null;
    /**
     * @var Action
     */
    private $action;
    /**
     * @var StoreManager
     */
    private $storeManager;

    /**
     * AssignThumbnails constructor.
     * @param CollectionFactory                                      $collectionFactory
     * @param LoggerInterface                                        $logger
     * @param \Magento\Catalog\Api\ProductRepositoryInterfaceFactory $productRepositoryFactory
     * @param ResourceConnection                                     $resourceConnection
     * @param \Magento\Framework\App\State                           $appState
     * @param \Magento\Framework\Filesystem                          $filesystem
     * @param \Magento\Catalog\Model\Product\Media\Config            $catalogProductMediaConfig
     * @param \Magento\MediaStorage\Helper\File\Storage\Database     $coreFileStorageDatabase
     * @param StoreManager                                           $storeManager
     * @param Action                                                 $action
     * @throws \Magento\Framework\Exception\FileSystemException
     */
    public function __construct(
        CollectionFactory $collectionFactory,
        LoggerInterface $logger,
        \Magento\Catalog\Api\ProductRepositoryInterfaceFactory $productRepositoryFactory,
        ResourceConnection $resourceConnection,
        \Magento\Framework\App\State $appState,
        \Magento\Framework\Filesystem $filesystem,
        \Magento\Catalog\Model\Product\Media\Config $catalogProductMediaConfig,
        \Magento\MediaStorage\Helper\File\Storage\Database $coreFileStorageDatabase,
        StoreManager $storeManager,
        Action $action
    )
    {
        $this->_productCollection = $collectionFactory;
        $this->_productRepositoryFactory = $productRepositoryFactory;
        $this->logger = $logger;
        $this->_resource = $resourceConnection;
        $this->appState = $appState;
        $this->_mediaDirectory = $filesystem->getDirectoryWrite(DirectoryList::MEDIA);
        $this->_catalogProductMediaConfig = $catalogProductMediaConfig;
        $this->_coreFileStorageDatabase = $coreFileStorageDatabase;
        $this->action = $action;
        parent::__construct();
        $this->storeManager = $storeManager;
    }

    /**
     * @param $productId
     * @return void
     */
    public function getImagesUsingSql($productId)
    {
        $connection = $this->_resource->getConnection();
        $select = $connection->select()
            ->from('catalog_product_entity_media_gallery_value', '*')
            ->join(
                'catalog_product_entity_media_gallery',
                'catalog_product_entity_media_gallery_value.value_id=catalog_product_entity_media_gallery.value_id',
                array('image' => 'value')
            )
            ->where('entity_id = ?', $productId);

        $images = $connection->fetchAll($select);
        if (!empty($images) && isset($images[0]['image'])) {
            return $images[0]['image'];
        } else {
            return [];
        }
    }

    /**
     * @param InputInterface  $input
     * @param OutputInterface $output
     * @return $this|int|null
     * @throws \Magento\Framework\Exception\LocalizedException
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     */
    protected function execute(InputInterface $input, OutputInterface $output)
    {
        set_time_limit(0);
        $this->appState->setAreaCode(\Magento\Framework\App\Area::AREA_GLOBAL);
        $storeIds = !empty($this->getAllStoreIds()) ? array_keys($this->getAllStoreIds()) : false;
        if ($storeIds) {
            foreach ($storeIds as $storeId) {
                $store = $this->storeManager->getStore($storeId);
                $count = 0;
                $thumbnailImageCount = 0;
                $imageNotAvailableCount = 0;
                $collection = $this->_productCollection->create()->addStoreFilter($store);
                $collection->addAttributeToSelect(['image', 'thumbnail', 'small_image']);
                $output->writeln("<info>Found " . count($collection) . " in store " . $storeId . "</info>");
                if (count($collection)) {
                    foreach ($collection as $product) {
                        $productRep = $this->_productRepositoryFactory->create()->getById($product->getEntityId(), false, $storeId);
                        $smallImage = $productRep->getData('small_image');
                        $baseImage = $productRep->getData('image');
                        $thumbnail = $productRep->getData('thumbnail');
                        if ($this->IsNullOrEmptyString($smallImage) || $smallImage == "no_selection" || $this->IsNullOrEmptyString($baseImage) || $baseImage == "no_selection" || $this->IsNullOrEmptyString($thumbnail) || $thumbnail == "no_selection") {
                            try {
                                $imagePath = $productRep->getMediaGalleryImages()->getFirstItem()->getFile();
                                if (!empty($imagePath)) {
                                    try {
                                        $output->writeln("<info>Images assigned for product : " . $product->getSku() . "</info>");
                                        $this->action->updateAttributes([0 => $product->getId()], array("image" => $imagePath, "thumbnail" => $imagePath, "small_image" => $imagePath), $storeId);
                                        $count = $count + 1;
                                    } catch (\Exception $e) {
                                        $output->writeln('<error>' . $e->getMessage() . '</error>');
                                    }

                                } else {
                                    $imageNotAvailableCount = $imageNotAvailableCount + 1;
                                }
                            } catch (\Exception $e) {
                                $output->writeln('<error>' . $e->getMessage() . '</error>');
                            }
                        } else {
                            $thumbnailImageCount = $thumbnailImageCount + 1;
                        }
                    }
                }
                $output->writeln("<info>Images assigned for  " . $count . " products in store " . $storeId . "</info>");
                $output->writeln("<info>Images already assigned for  " . $thumbnailImageCount . " products in store " . $storeId . "</info>");
                $output->writeln("<info>Images not found for  " . $imageNotAvailableCount . " products in store " . $storeId . "</info>");
            }
        }
        $output->writeln("<info>Clearing cache image folder</info>");
        $this->clearCache();
        $output->writeln("<info>Finished</info>");
        return $this;
    }

    /**
     * @return array
     */
    public function getAllStoreIds()
    {
        $result = [];

        $sql = $this->_resource->getConnection()->select()
            ->from($this->_resource->getTableName('store'), array('store_id', 'code'))
            ->order('store_id', 'ASC');

        $queryResult = $this->_resource->getConnection()->fetchAll($sql);

        foreach ($queryResult as $row) {
            $result[(int)$row['store_id']] = $row['code'];
        }

        return $result;
    }

    /**
     * @param $variable
     * @return bool
     */
    public function IsNullOrEmptyString($variable)
    {
        return (!isset($variable) || trim($variable) === '');
    }

    public function clearCache()
    {
        $directory = $this->_catalogProductMediaConfig->getBaseMediaPath() . '/cache';
        $this->_mediaDirectory->delete($directory);
        $this->_coreFileStorageDatabase->deleteFolder($this->_mediaDirectory->getAbsolutePath($directory));
    }

    protected function configure()
    {
        $this->setName('codilar:replace:placeholders')
            ->setDescription('Assign Thumbnail images to products');
        parent::configure();
    }
}