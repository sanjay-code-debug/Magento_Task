<?php
/**
 * Created by salman.
 * Date: 30/4/18
 * Time: 11:13 AM
 * Filename: CmsIndexIndex.php
 */

namespace Codilar\Common\Block\Html;


use Codilar\Common\Helper\Logger;
use Magento\Framework\View\Element\Template;

/**
 * Class CmsIndexIndex
 * @package Codilar\Common\Block\Html
 */
class CmsIndexIndex extends \Magento\Framework\View\Element\Template
{
    /**
     * @var Logger
     */
    protected $logger;

    /**
     * CmsIndexIndex constructor.
     * @param Template\Context $context
     * @param array            $data
     * @param Logger           $logger
     */
    public function __construct(Template\Context $context, array $data = [], Logger $logger)
    {
        $this->logger = $logger;
        parent::__construct($context, $data);
    }

    /**
     * @return array
     */
    public function getCacheKeyInfo()
    {
        return parent::getCacheKeyInfo();
    }

    protected function _construct()
    {
        parent::_construct();
    }

}