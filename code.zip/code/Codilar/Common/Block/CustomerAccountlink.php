<?php

namespace Codilar\Common\Block;

/**
 * Class CustomerAccountlink
 * @package Codilar\Common\Block
 */
class CustomerAccountlink extends \Magento\Framework\View\Element\Html\Link
{

    /**
     * CustomerAccountlink constructor.
     * @param \Magento\Framework\View\Element\Template\Context $context
     */
    public function __construct(
        \Magento\Framework\View\Element\Template\Context $context
    )
    {
        parent::__construct($context);
    }

    /**
     * Render block HTML.
     *
     * @return string
     */
    protected function _toHtml()
    {
        if (false != $this->getTemplate()) {
            return parent::_toHtml();
        }
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $customerSession = $objectManager->create('Magento\Customer\Model\Session');
        if ($customerSession->isLoggedIn()) {
            return '<li><a ' . $this->getLinkAttributes() . ' ><i class="fa fa-user" aria-hidden="true"></i>' . $this->escapeHtml($this->getLabel()) . '</a></li>';
        } else {
            return '';
        }
    }
}