<?php

namespace Codilar\Common\Block;
/**
 * Class Common
 * @package Codilar\Common\Block
 */
class Common extends \Magento\Framework\View\Element\Template
{
    /**
     * Common constructor.
     * @param \Magento\Framework\View\Element\Template\Context $context
     */
    public function __construct(\Magento\Framework\View\Element\Template\Context $context)
    {
        parent::__construct($context);
    }

    /**
     * @return string
     */
    public function getCompanyInfo()
    {
        $html = <<<HTML
        <a style="display:none;" href="http://www.codilar.com/">Codilar - Magento eCommerce Development Company</a>
HTML;
        return $html;
    }
}
