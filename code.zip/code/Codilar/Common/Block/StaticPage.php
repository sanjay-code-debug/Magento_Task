<?php

namespace Codilar\Common\Block;

class StaticPage extends \Magento\Cms\Block\Block
{
    /**
     * @var \Magento\Cms\Api\BlockRepositoryInterface
     */
    protected $_blockRepository;
    /**
     * @var \Magento\Framework\App\Request\Http
     */
    protected $request;
    /**
     * @var \Shopmonk\Stores\Helper\Business\Data
     */
    private $storeHelper;

    /**
     * StaticPage constructor.
     * @param \Magento\Framework\View\Element\Context $context
     * @param \Magento\Cms\Model\Template\FilterProvider $filterProvider
     * @param \Magento\Store\Model\StoreManagerInterface $storeManager
     * @param \Magento\Cms\Model\BlockFactory $blockFactory
     * @param \Magento\Cms\Api\BlockRepositoryInterface $blockRepository
     * @param \Magento\Framework\App\Request\Http $request
     * @param \Shopmonk\Stores\Helper\Business\Data $storeHelper
     * @param array $data
     */
    public function __construct(
        \Magento\Framework\View\Element\Context $context,
        \Magento\Cms\Model\Template\FilterProvider $filterProvider,
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        \Magento\Cms\Model\BlockFactory $blockFactory,
        \Magento\Cms\Api\BlockRepositoryInterface $blockRepository,
        \Magento\Framework\App\Request\Http $request,
        \Shopmonk\Stores\Helper\Business\Data $storeHelper,
        array $data = []
    ) {
        parent::__construct($context, $filterProvider, $storeManager, $blockFactory, $data);
        $this->_blockRepository = $blockRepository;
        $this->request = $request;
        $this->storeHelper = $storeHelper;
    }

    /**
     * @return \Magento\Cms\Api\Data\BlockInterface|null
     */
    public function getBlockData(){
        try{
            $blockId = $this->getBlockId();
            if ($blockId) {
                $block = $this->_blockRepository->getById($blockId);
                return $block;
            }
            else{
                return null;
            }
        }
        catch (\Exception $e){
            return null;
        }
    }

    /**
     * @return null|string
     */
    public function getUserIpCountryCode(){
        return $this->storeHelper->getCountryCodeFromServer();
    }

    /**
     * @return string
     */
    public function getFullActionName(){
        $actionName = $this->request->getFullActionName();
        return $actionName;
    }
}