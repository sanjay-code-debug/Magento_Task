<?php

namespace Codilar\Common\Block;

/**
 * Class Toplinks
 * @package Codilar\Common\Block
 */
class Toplinks extends \Magento\Framework\View\Element\Html\Link
{
    /**
     * Render block HTML.
     *
     * @return string
     */
    protected function _toHtml()
    {
        if (false != $this->getTemplate()) {
            return parent::_toHtml();
        }
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $customerSession = $objectManager->create('Magento\Customer\Model\Session');
        if (!($customerSession->isLoggedIn())) {
            return '<li><a ' . $this->getLinkAttributes() . ' ><i class="fa fa-user-plus" aria-hidden="true"></i>' . $this->escapeHtml($this->getLabel()) . '</a></li>';
        } else {
            return '';
        }
    }
}