<?php

namespace Codilar\Common\Observer;

use Magento\Framework\Event\ObserverInterface;
use Magento\Store\Model\StoreManagerInterface;

/**
 * Class AddKycDataToTransport
 * @package Codilar\Common\Observer
 */
class AddKycDataToTransport implements ObserverInterface
{
    /**
     * @var StoreManagerInterface
     */
    private $storeManager;

    /**
     * AddKycDataToTransport constructor.
     * @param StoreManagerInterface $storeManager
     */
    public function __construct(
        StoreManagerInterface $storeManager
    )
    {
        $this->storeManager = $storeManager;
    }

    /**
     * @param \Magento\Framework\Event\Observer $observer
     */
    public function execute(\Magento\Framework\Event\Observer $observer)
    {
        $transport = $observer->getEvent()->getTransport();
        $order = $transport->getOrder();
        if ($order) {
            $orderStoreCode = $this->getStoreCodeByStoreId($order->getStoreId());
            $countryId = $order->getShippingAddress()->getCountryId();
            if ($orderStoreCode == "default" && $countryId == "IN") {
                $transport['kyc'] = true;
            }
        }
    }

    /**
     * @param $storeId
     * @return string
     */
    public function getStoreCodeByStoreId($storeId)
    {
        return $this->storeManager->getStore($storeId)->getCode();
    }
}