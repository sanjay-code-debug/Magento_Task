<?php
namespace Codilar\Common\Observer;
use Magento\Framework\Event\ObserverInterface;
use Magento\Store\Model\StoreManagerInterface;

class PaymentMethodAvailable implements ObserverInterface
{
    /**
     * @var StoreManagerInterface
     */
    private $storeManager;

    public function __construct(
        StoreManagerInterface $storeManager
    )
    {
        $this->storeManager = $storeManager;
    }

    /**
     * @param \Magento\Framework\Event\Observer $observer
     */
    public function execute(\Magento\Framework\Event\Observer $observer)
    {
        $currencyDetails = $this->storeManager->getStore()->getCurrentCurrency();
        $currencyCode = $currencyDetails->getData('currency_code');
        if($observer->getEvent()->getMethodInstance()->getCode()=="banktransfer" && ($currencyCode=="AED" || $currencyCode=="THB" || $currencyCode=="MYR" || $currencyCode=="PHP" )){
            $checkResult = $observer->getEvent()->getResult();
            $checkResult->setData('is_available', false);
        }
    }
}

