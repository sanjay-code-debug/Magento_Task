<?php

namespace Codilar\Common\Observer;

use Magento\Framework\Registry;
use Magento\Sales\Api\OrderRepositoryInterface;
use Magento\Sales\Model\Order\Email\Sender\OrderSender;
use Magento\Sales\Model\Service\OrderService;
use Magento\Store\Model\StoreManagerInterface;
use Psr\Log\LoggerInterface;
use Magento\Sales\Model\ResourceModel\Order as OrderResource;

class SendMail implements \Magento\Framework\Event\ObserverInterface
{
    /** @var \Magento\Framework\Logger\Monolog */
    protected $_logger;
    /**
     * @var StoreManagerInterface
     */
    private $storeManager;
    /**
     * @var OrderRepositoryInterface
     */
    private $orderRepository;
    /**
     * @var OrderService
     */
    private $orderService;
    /**
     * @var OrderSender
     */
    private $orderSender;
    /**
     * @var OrderResource
     */
    private $orderResource;
    /**
     * @var Registry
     */
    private $registry;

    /**
     * OrderStatus constructor.
     * @param LoggerInterface $loggerInterface
     * @param OrderRepositoryInterface $orderRepository
     * @param OrderService $orderService
     * @param StoreManagerInterface $storeManager
     * @param OrderSender $orderSender
     * @param OrderResource $orderResource
     * @param Registry $registry
     */
    public function __construct(
        LoggerInterface $loggerInterface,
        OrderRepositoryInterface $orderRepository,
        OrderService $orderService,
        StoreManagerInterface $storeManager,
        OrderSender $orderSender,
        OrderResource $orderResource,
        Registry $registry
    )
    {
        $this->_logger = $loggerInterface;
        $this->storeManager = $storeManager;
        $this->orderRepository = $orderRepository;
        $this->orderService = $orderService;
        $this->orderSender = $orderSender;
        $this->orderResource = $orderResource;
        $this->registry = $registry;
    }

    public function execute(\Magento\Framework\Event\Observer $observer)
    {
        $order = $observer->getOrder();
        if ($order) {
            $orderStoreCode = $this->getStoreCodeByStoreId($order->getStoreId());
            if ($orderStoreCode == "india" && $order->getStatus() == "pending") {
                try{
                    $this->registry->register('codilar_send_mail', '1');
                    $this->orderSender->send($order);
                }
                catch (\Exception $e){
                }
            }
        }
        return $this;
    }

    /**
     * @param $storeId
     * @return string
     */
    public function getStoreCodeByStoreId($storeId)
    {
        return $this->storeManager->getStore($storeId)->getCode();
    }
}