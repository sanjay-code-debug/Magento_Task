<?php

namespace Codilar\Common\Observer;

use Magento\Framework\Event\Observer;
use Magento\Framework\Event\ObserverInterface;
use Magento\Framework\Exception\StateException;
use Magento\Checkout\Model\Session as CheckoutSession;

/**
 * Class BeforePlaceOrder
 * @package Codilar\Common\Observer
 */
class BeforePlaceOrder implements ObserverInterface
{
    /**
     * @var \Magento\Framework\App\Config\ScopeConfigInterface
     */
    protected $scopeConfig;
    /**
     * @var \Magento\Directory\Model\AllowedCountries
     */
    protected $allowedCountryModel;

    /**
     * @var \Magento\Checkout\Model\Session
     */
    protected $checkoutSession;

    /**
     * BeforePlaceOrder constructor.
     * @param \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig
     * @param \Magento\Directory\Model\AllowedCountries          $allowedCountryModel
     */
    public function __construct(
        \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
        \Magento\Directory\Model\AllowedCountries $allowedCountryModel,
        CheckoutSession $checkoutSession
    )
    {
        $this->scopeConfig = $scopeConfig;
        $this->allowedCountryModel = $allowedCountryModel;
        $this->checkoutSession = $checkoutSession;
    }

    /**
     * @param Observer $observer
     * @throws StateException
     */
    public function execute(Observer $observer)
    {
     
        $totalQuantity = (int)$this->checkoutSession->getQuote()->getItemsQty();
        $order = $observer->getOrder();
        $address = $order->getShippingAddress();
        $min_qty = $this->scopeConfig->getValue('feedback/min_cart_qty_config/min_cart_qty', \Magento\Store\Model\ScopeInterface::SCOPE_STORE);

        if($totalQuantity<$min_qty && $totalQuantity>0){
            throw new StateException(__('Add minimum '.$min_qty.' units in the cart for checkout'));
        }
        $countryCode = $address->getData('country_id');
        $allowedCountries = $this->allowedCountryModel->getAllowedCountries();
        $allowedCountries = array_values($allowedCountries);
        if (!in_array($countryCode, $allowedCountries)) {
            throw new StateException(__('Invalid Shipping Address Country'));
        }
    }
}