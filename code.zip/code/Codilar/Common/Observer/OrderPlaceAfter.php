<?php
/**
 * Created by salman.
 * Date: 12/4/18
 * Time: 12:40 PM
 * Filename: OrderPlaceAfter.php
 */

namespace Codilar\Common\Observer;


use Magento\Framework\Event\Observer;
use Magento\Framework\Event\ObserverInterface;

/**
 * Class OrderPlaceAfter
 * @package Codilar\Common\Observer
 */
class OrderPlaceAfter implements ObserverInterface
{
    /**
     * @param Observer $observer
     * @return $this|void
     */

    protected $kyc;
 
    public function __construct(
    \Codilar\KYC\Model\KYCFactory $kyc) {
        $this->_kyc = $kyc;
    }

    public function execute(Observer $observer)
    {
 
        $order = $observer->getOrder();
        $quote = $observer->getQuote();
        $total = $quote->getData("subtotal");

        $country_code = $quote->getShippingAddress()->getCountryId();
        $custom_discount = $quote->getData("tier_discount");
      
        $order->setData('tier_discount', $custom_discount);

        if($country_code == "SG"){
            $customer_id = $quote->getCustomer()->getId();
            $kyc_data = $this->_kyc->create();
            $kyc_data->load($customer_id, 'customer_id');
            if ($kyc_data->getId() && $total>10000) {
                $tax = 0;
            } else {
                $tax = $total*7/100;
            }
            $order->setData('tax_amount', $tax);
            $order->setData('base_tax_amount', $tax);
        }
        $order->setData('is_order_verify', "Order Not Verified");
       
        try {
            if ($payment = $order->getPayment()->getMethodInstance()) {
                $order->setData('payment_method_code', $payment->getCode());
                $order->setData('payment_method_label', $payment->getTitle());
            }
        } catch (\Exception $e) {

        }
        return $this;
    }

}