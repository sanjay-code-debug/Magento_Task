<?php

namespace Codilar\Common\Observer;

use Magento\Framework\Event\ObserverInterface;
use Magento\Store\Model\StoreManagerInterface;
use Psr\Log\LoggerInterface;
use Magento\Framework\App\Filesystem\DirectoryList;

/**
 * Class ProductCsvImporter
 * @package Codilar\Common\Observer
 */
class ProductCsvImporter implements ObserverInterface
{
    /**
     * @var StoreManagerInterface
     */
    private $storeManager;
    /**
     * @var LoggerInterface
     */
    private $logger;
    /**
     * @var DirectoryList
     */
    private $directoryList;
    /**
     * @var \Codilar\Common\Helper\Data
     */
    private $commonHelper;

    /**
     * ProductCsvImporter constructor.
     * @param StoreManagerInterface $storeManager
     * @param LoggerInterface $logger
     * @param DirectoryList $directoryList
     * @param \Codilar\Common\Helper\Data $commonHelper
     */
    public function __construct(
        StoreManagerInterface $storeManager,
        LoggerInterface $logger,
        DirectoryList $directoryList,
        \Codilar\Common\Helper\Data $commonHelper
    )
    {
        $this->storeManager = $storeManager;
        $this->logger = $logger;
        $this->directoryList = $directoryList;
        $this->commonHelper = $commonHelper;
    }

    /**
     * @param \Magento\Framework\Event\Observer $observer
     * @return $this
     */
    public function execute(\Magento\Framework\Event\Observer $observer)
    {
        $cacheTriggerStatus = $this->commonHelper->getProductSaveTriggeronCsvImport();
        if($cacheTriggerStatus){
            $rootPath = $this->directoryList->getRoot();
            $products = $observer->getBunch();
            $sku = [];
            foreach ($products as $rowNum => $rowData){
                $sku[] = $rowData['sku'];
            }
            $encodedSkus = base64_encode(json_encode($sku));
            $access_log = $rootPath."/var/log/product_save_trigger_access.log";
            $error_log = $rootPath."/var/log/product_save_trigger_error.log";
            $command = $rootPath."/bin/magento codilar:productsave:trigger:cache --skus='".$encodedSkus."'";
            shell_exec($command." > $access_log 2> $error_log &");
        }
        return $this;
    }
}