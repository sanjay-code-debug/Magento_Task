<?php

namespace Codilar\Common\Setup;

use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\SchemaSetupInterface;
use Magento\Framework\Setup\UpgradeSchemaInterface;
use Magento\Sales\Model\Order\Status;

/**
 * Class UpgradeSchema
 * @package Codilar\Common\Setup
 */
class UpgradeSchema implements UpgradeSchemaInterface
{
    CONST APPROVAL_PENDING = 'approval_pending';
    /**
     * @var Status
     */
    protected $orderStatus;

    public function __construct(
        Status $orderStatus
    )
    {
        $this->orderStatus = $orderStatus;
    }

    /**
     * @param SchemaSetupInterface   $setup
     * @param ModuleContextInterface $context
     */
    public function upgrade(SchemaSetupInterface $setup, ModuleContextInterface $context)
    {
        $setup->startSetup();

        //handle all possible upgrade versions

        if (!$context->getVersion()) {
            //no previous version found, installation, InstallSchema was just executed
            //be careful, since everything below is true for installation !
        }

        if (version_compare($context->getVersion(), '1.0.1') < 0) {
            //code to upgrade to 1.0.1
        }

        if (version_compare($context->getVersion(), '1.0.3') < 0) {
            //code to upgrade to 1.0.3
        }

        if (version_compare($context->getVersion(), '1.0.4') < 0) {
            //code to upgrade to 1.0.4
            $setup->getConnection()->addColumn(
                $setup->getTable('cms_block'),
                'country_codes',
                [
                    'type' => \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                    'length' => null,
                    'nullable' => true,
                    'comment' => 'Country Codes'
                ]
            );

            $setup->getConnection()->addColumn(
                $setup->getTable('cms_block'),
                'display_pages',
                [
                    'type' => \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                    'length' => null,
                    'nullable' => true,
                    'comment' => 'Display Pages'
                ]
            );
        }

        if (version_compare($context->getVersion(), '1.0.5') < 0) {
            $status = $this->orderStatus->setData('status', self::APPROVAL_PENDING)->setData('label', 'Approval Pending')->unsetData('id')->save();
            $status->assignState(\Magento\Sales\Model\Order::STATE_PENDING_PAYMENT, false, true);
            try {
                $status->save();
                $tableName = 'sales_order';
                $setup->getConnection()->addColumn(
                    $setup->getTable($tableName), 'banktransfer_transaction_id',
                    [
                    'type' => \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                    null,
                    'nullable' => true,
                    'default' => null,
                    'comment' => 'Bank transfer Transaction Id',
                ]);
                $setup->getConnection()->addColumn($setup->getTable($tableName), 'bank_receipt', [
                    'type' => \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                    null,
                    'nullable' => true,
                    'default' => null,
                    'comment' => 'Bank Receipt',
                ]);
                $setup->getConnection()->addColumn($setup->getTable($tableName), 'is_order_verify', [
                    'type' => \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                    null,
                    'nullable' => true,
                    'default' => null,
                    'comment' => 'Is Order Verify',
                ]);
                $setup->getConnection()->addColumn($setup->getTable("sales_order_grid"), 'is_order_verify', [
                    'type' => \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                    null,
                    'nullable' => true,
                    'default' => null,
                    'comment' => 'Is Order Verify',
                ]);
                $setup->getConnection()->addColumn($setup->getTable($tableName), 'bank_transaction_document', [
                    'type' => \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                    null,
                    'nullable' => true,
                    'default' => null,
                    'comment' => 'Bank Transaction Document',
                ]);
                $setup->getConnection()->addColumn($setup->getTable($tableName), 'is_banktransfer_approved', [
                    'type' => \Magento\Framework\DB\Ddl\Table::TYPE_BOOLEAN,
                    null,
                    'default' => 0,
                    'comment' => 'Is banktransfer approved',
                ]);
                $setup->getConnection()->addColumn($setup->getTable($tableName), 'payment_method_code', [
                    'type' => \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                    null,
                    'nullable' => true,
                    'default' => null,
                    'comment' => 'payment method code',
                ]);
                $setup->getConnection()->addColumn($setup->getTable($tableName), 'payment_method_label', [
                    'type' => \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                    null,
                    'nullable' => true,
                    'default' => null,
                    'comment' => 'payment method label',
                ]);
            } catch (\Exception $e) {
                echo $e->getMessage();
                exit;
            }
        }

        if (version_compare($context->getVersion(), '1.0.6') < 0) {
            //code to upgrade to 1.0.6
            $connection = $setup->getConnection();
            // truncate table
            $connection->truncateTable("inventory_reservation");
        }
        if (version_compare($context->getVersion(), '1.0.9') < 0) {
            $table = $setup->getTable("customer_eav_attribute");
            $query1 = "UPDATE `" . $table . "` SET `is_used_in_grid`= '0' WHERE attribute_id IN ('306','307','305','229','216','215','214','213','212','202','201','173','172') ";
            $connection = $setup->getConnection();
            $connection->query($query1);
        }
        $setup->endSetup();
    }
}
