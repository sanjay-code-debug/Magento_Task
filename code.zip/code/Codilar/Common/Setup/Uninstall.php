<?php

namespace Inchoo\SetupTest\Setup;

use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\SchemaSetupInterface;
use Magento\Framework\Setup\UninstallInterface;

/**
 * Class Uninstall
 * @package Inchoo\SetupTest\Setup
 */
class Uninstall implements UninstallInterface
{
    /**
     * @param SchemaSetupInterface   $setup
     * @param ModuleContextInterface $context
     */
    public function uninstall(SchemaSetupInterface $setup, ModuleContextInterface $context)
    {
        $setup->startSetup();

        //Tables to be removed from DB ..
        //Ex : $setup->getConnection()->query("DROP table codilar_table");

        $setup->endSetup();
    }
}