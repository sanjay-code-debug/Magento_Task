<?php

namespace Codilar\Common\Setup;

use Magento\Eav\Setup\EavSetupFactory;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\ModuleDataSetupInterface;
use Magento\Framework\Setup\UpgradeDataInterface;
use Magento\Cms\Model\BlockFactory;

/**
 * Class UpgradeData
 * @package Codilar\Common\Setup
 */
class UpgradeData implements UpgradeDataInterface
{

    /**
     * @var EavSetupFactory
     */
    private $eavSetupFactory;
    /**
     * @var BlockFactory
     */
    private $blockFactory;
    /**
     * @var resourceConfig
     */
    private $resourceConfig;

    /**
     * UpgradeData constructor.
     * @param EavSetupFactory $eavSetupFactory
     * @param BlockFactory $blockFactory
     */
    public function __construct(
        EavSetupFactory $eavSetupFactory,
        BlockFactory $blockFactory,
        \Magento\Framework\App\Config\ConfigResource\ConfigInterface  $resourceConfig
    )
    {
        $this->eavSetupFactory = $eavSetupFactory;
        $this->blockFactory = $blockFactory;
        $this->resourceConfig = $resourceConfig;

    }

    /**
     * @param ModuleDataSetupInterface $setup
     * @param ModuleContextInterface   $context
     */
    public function upgrade(ModuleDataSetupInterface $setup, ModuleContextInterface $context)
    {
        $setup->startSetup();

        //handle all possible upgrade versions

        if (!$context->getVersion()) {
            //no previous version found, installation, InstallSchema was just executed
            //be careful, since everything below is true for installation !
        }

        if (version_compare($context->getVersion(), '1.0.1') < 0) {
            //code to upgrade to 1.0.1

            $eavSetup = $this->eavSetupFactory->create(['setup' => $setup]);
            $eavSetup->addAttribute(
                \Magento\Catalog\Model\Product::ENTITY,
                'warranty',
                [
                    'type' => 'varchar',
                    'backend' => '',
                    'frontend' => '',
                    'label' => 'Warranty',
                    'input' => 'text',
                    'class' => '',
                    'source' => '',
                    'global' => \Magento\Eav\Model\Entity\Attribute\ScopedAttributeInterface::SCOPE_STORE,
                    'visible' => true,
                    'required' => false,
                    'user_defined' => true,
                    'default' => '',
                    'searchable' => false,
                    'filterable' => false,
                    'comparable' => false,
                    'visible_on_front' => true,
                    'used_in_product_listing' => true,
                    'unique' => false,
                    'apply_to' => '',
                    'group' => 'Additional Attributes'
                ]
            );

            $eavSetup->addAttribute(
                \Magento\Catalog\Model\Product::ENTITY,
                'additional_info',
                [
                    'type' => 'varchar',
                    'backend' => '',
                    'frontend' => '',
                    'label' => 'Additional Information',
                    'input' => 'text',
                    'class' => '',
                    'source' => '',
                    'global' => \Magento\Eav\Model\Entity\Attribute\ScopedAttributeInterface::SCOPE_STORE,
                    'visible' => true,
                    'required' => false,
                    'user_defined' => true,
                    'default' => '',
                    'searchable' => false,
                    'filterable' => false,
                    'comparable' => false,
                    'visible_on_front' => true,
                    'used_in_product_listing' => true,
                    'unique' => false,
                    'apply_to' => '',
                    'group' => 'Additional Attributes'
                ]
            );
        }

        if (version_compare($context->getVersion(), '1.0.2') < 0) {
            $this->createProductMaxSaleQtyAtrribute($setup);
            $this->createProductMaxSaleQtyFromDateAtrribute($setup);
            $this->createProductMaxSaleQtyToDateAtrribute($setup);
        }
        if (version_compare($context->getVersion(), '1.0.4') < 0) {
            $cmsBlockData = [
                'title' => 'Static Block Before Footer',
                'identifier' => 'static-block-before-footer',
                'content' => "<p></p>",
                'is_active' => 1,
                'stores' => [0],
                'country_codes' => "AU,IN,SG",
                'display_pages' => "all",
                'sort_order' => 0
            ];
            $this->createCmsStaticBlock($cmsBlockData);
        }

        if (version_compare($context->getVersion(), '1.0.7') < 0) {

            $eavSetup = $this->eavSetupFactory->create(['setup' => $setup]);
            $eavSetup->removeAttribute(\Magento\Catalog\Model\Product::ENTITY, 'easyship_height');
            $eavSetup->removeAttribute(\Magento\Catalog\Model\Product::ENTITY, 'easyship_width');
            $eavSetup->removeAttribute(\Magento\Catalog\Model\Product::ENTITY, 'easyship_length');
            $eavSetup->removeAttribute(\Magento\Catalog\Model\Product::ENTITY, 'easyship_category');

        }
        if (version_compare($context->getVersion(), '1.0.8') < 0) {

            $this->resourceConfig->saveConfig(
                'dev/js/move_script_to_bottom',
                1,
                \Magento\Framework\App\Config\ScopeConfigInterface::SCOPE_TYPE_DEFAULT,
                \Magento\Store\Model\Store::DEFAULT_STORE_ID
            );
            $this->resourceConfig->saveConfig(
                'dev/js/merge_files',
                1,
                \Magento\Framework\App\Config\ScopeConfigInterface::SCOPE_TYPE_DEFAULT,
                \Magento\Store\Model\Store::DEFAULT_STORE_ID
            );
            $this->resourceConfig->saveConfig(
                'dev/js/enable_js_bundling',
                1,
                \Magento\Framework\App\Config\ScopeConfigInterface::SCOPE_TYPE_DEFAULT,
                \Magento\Store\Model\Store::DEFAULT_STORE_ID
            );
            $this->resourceConfig->saveConfig(
                'dev/js/minify_files',
                1,
                \Magento\Framework\App\Config\ScopeConfigInterface::SCOPE_TYPE_DEFAULT,
                \Magento\Store\Model\Store::DEFAULT_STORE_ID
            );

        }
        $setup->endSetup();
    }

    /**
     * @param $setup
     */
    private function createProductMaxSaleQtyAtrribute($setup)
    {
        $eavSetup = $this->eavSetupFactory->create(['setup' => $setup]);

        /**
         * Add attributes to the eav/attribute
         */
        $eavSetup->addAttribute(
            \Magento\Catalog\Model\Product::ENTITY,
            'max_purchase',/* Custom Attribute Code */
            [
                'group' => 'SMK Attributes',
                'type' => 'int',/* Data type in which formate your value save in database*/
                'backend' => '',
                'frontend' => '',
                'label' => 'Max Quantity allowed to Purchase', /* lable of your attribute*/
                'input' => 'text',
                'class' => '',
                'source' => '',
                /* Source of your select type custom attribute options*/
                'global' => \Magento\Eav\Model\Entity\Attribute\ScopedAttributeInterface::SCOPE_STORE,
                /*Scope of your attribute */
                'visible' => true,
                'required' => false,
                'user_defined' => true,
                'default' => '',
                'searchable' => false,
                'filterable' => false,
                'comparable' => false,
                'visible_on_front' => false,
                'used_in_product_listing' => false,
                'unique' => false,
                'is_used_in_grid' => false,
                'is_visible_in_grid' => false,
                'is_searchable_in_grid' => false,
                'is_filterable_in_grid' => false,
            ]
        );

    }

    /**
     * @param $setup
     */
    private function createProductMaxSaleQtyFromDateAtrribute($setup)
    {
        $eavSetup = $this->eavSetupFactory->create(['setup' => $setup]);

        /**
         * Add attributes to the eav/attribute
         */
        $eavSetup->addAttribute(
            \Magento\Catalog\Model\Product::ENTITY,
            'max_purchase_from_date',/* Custom Attribute Code */
            [
                'group' => 'SMK Attributes',
                'type' => 'datetime',/* Data type in which formate your value save in database*/
                'backend' => 'Magento\Catalog\Model\Attribute\Backend\Startdate',
                'frontend' => '',
                'label' => 'Max Quantity Purchase From', /* lable of your attribute*/
                'input' => 'date',
                'class' => '',
                'source' => '',
                /* Source of your select type custom attribute options*/
                'global' => \Magento\Eav\Model\Entity\Attribute\ScopedAttributeInterface::SCOPE_STORE,
                /*Scope of your attribute */
                'visible' => true,
                'required' => false,
                'user_defined' => true,
                'default' => '',
                'searchable' => false,
                'filterable' => false,
                'comparable' => false,
                'visible_on_front' => false,
                'used_in_product_listing' => false,
                'unique' => false,
                'is_used_in_grid' => false,
                'is_visible_in_grid' => false,
                'is_searchable_in_grid' => false,
                'is_filterable_in_grid' => false,
            ]
        );

    }

    /**
     * @param $setup
     */
    private function createProductMaxSaleQtyToDateAtrribute($setup)
    {
        $eavSetup = $this->eavSetupFactory->create(['setup' => $setup]);

        /**
         * Add attributes to the eav/attribute
         */
        $eavSetup->addAttribute(
            \Magento\Catalog\Model\Product::ENTITY,
            'max_purchase_to_date',/* Custom Attribute Code */
            [
                'group' => 'SMK Attributes',
                'type' => 'datetime',/* Data type in which formate your value save in database*/
                'backend' => 'Magento\Eav\Model\Entity\Attribute\Backend\Datetime',
                'frontend' => '',
                'label' => 'Max Quantity Purchase To', /* lable of your attribute*/
                'input' => 'date',
                'class' => '',
                'source' => '',
                /* Source of your select type custom attribute options*/
                'global' => \Magento\Eav\Model\Entity\Attribute\ScopedAttributeInterface::SCOPE_STORE,
                /*Scope of your attribute */
                'visible' => true,
                'required' => false,
                'user_defined' => true,
                'default' => '',
                'searchable' => false,
                'filterable' => false,
                'comparable' => false,
                'visible_on_front' => false,
                'used_in_product_listing' => false,
                'unique' => false,
                'is_used_in_grid' => false,
                'is_visible_in_grid' => false,
                'is_searchable_in_grid' => false,
                'is_filterable_in_grid' => false,
            ]
        );
    }

    /**
     * @param $cmsBlockData
     */
    private function createCmsStaticBlock($cmsBlockData){
        try{
            $this->blockFactory->create()->setData($cmsBlockData)->save();
        }
        catch (\Exception $e){

        }
    }
}
