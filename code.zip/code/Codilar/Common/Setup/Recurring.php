<?php

namespace Codilar\Common\Setup;

use Magento\Framework\Setup\InstallSchemaInterface;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\SchemaSetupInterface;

/**
 * Class Recurring
 * @package Codilar\Common\Setup
 */
class Recurring implements InstallSchemaInterface
{
    /**
     * @param SchemaSetupInterface   $setup
     * @param ModuleContextInterface $context
     */
    public function install(SchemaSetupInterface $setup, ModuleContextInterface $context)
    {
        $setup->startSetup();

        //Code tat needs to update evrytime when bin.magento setup:upgrade is executed irrespective of module version
        //Ex : $setup->getConnection()->query("INSERT INTO codilar_table SET name = 'Codilar', email = 'test@codilar.com'");
        $setup->endSetup();
    }
}
