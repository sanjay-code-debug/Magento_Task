<?php
/**
 * Created by salman.
 * Date: 2/4/18
 * Time: 2:53 PM
 * Filename: Logger.php
 */

namespace Codilar\Common\Helper;


use Magento\Framework\App\Helper\Context;

/**
 * Class Logger
 * @package Codilar\Common\Helper
 */
class Logger extends \Magento\Framework\App\Helper\AbstractHelper
{
    /**
     *
     */
    CONST PAYMENT_LOG_FILE = 'payments_debug.log';
    /**
     *
     */
    CONST DEFAULT_LOG_FILE = 'codilar.log';
    /**
     *
     */
    CONST LOG_PATH = '/var/log/';
    /**
     * @var
     */
    protected $request;
    /**
     * @var \Magento\Framework\App\Filesystem\DirectoryList
     */
    protected $dir;

    /**
     * Logger constructor.
     * @param Context                                         $context
     * @param \Magento\Framework\App\Filesystem\DirectoryList $dir
     */
    public function __construct(
        Context $context,
        \Magento\Framework\App\Filesystem\DirectoryList $dir
    )
    {
        $this->dir = $dir;
        parent::__construct($context);
    }

    /**
     * @param $message
     */
    public function addPaymentLog($message)
    {
        $this->addLog($message, self::PAYMENT_LOG_FILE);
    }

    /**
     * @param        $message
     * @param string $file
     */
    public function addLog($message, $file = self::DEFAULT_LOG_FILE)
    {
        $writer = new \Zend\Log\Writer\Stream($this->dir->getRoot() . self::LOG_PATH . $file);
        $logger = new \Zend\Log\Logger();
        $logger->addWriter($writer);
        $logger->info($message);
    }

}