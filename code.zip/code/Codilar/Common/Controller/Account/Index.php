<?php

namespace Codilar\Common\Controller\Account;

use Magento\Customer\Model\Session;
use Magento\Framework\App\Action\Context;

/**
 * Class Index
 * @package Codilar\Common\Controller\Account
 */
class Index extends \Magento\Framework\App\Action\Action
{
    /**
     * @var Session
     */
    private $customerSession;

    /**
     * Index constructor.
     * @param Context $context
     * @param Session $customerSession
     */
    public function __construct(
        Context $context,
        Session $customerSession
    )
    {
        parent::__construct($context);
        $this->customerSession = $customerSession;
    }

    /**
     * @return $this|\Magento\Framework\App\ResponseInterface|\Magento\Framework\Controller\ResultInterface
     */
    public function execute()
    {
        /** @var \Magento\Backend\Model\View\Result\Redirect $resultRedirect */
        $resultRedirect = $this->resultRedirectFactory->create();
        if ($this->customerSession->isLoggedIn()) {
            $this->_view->loadLayout();
            $this->_view->renderLayout();
        } else {
            $this->messageManager->addErrorMessage(__("Please login to change password"));
            return $resultRedirect->setPath('customer/account');
        }
    }

}