<?php

namespace Codilar\Common\Controller\Index;

use Magento\Framework\App\ResourceConnection;
use Magento\Framework\Mail\Template\TransportBuilder;
use Magento\Framework\App\Action\Context;
use Magento\Store\Model\StoreManagerInterface;
use Magento\Framework\App\Config\ScopeConfigInterface;
use Psr\Log\LoggerInterface;
use Magento\Sales\Model\ResourceModel\Order\CollectionFactoryInterface;
/**
 * Class Index
 * @package Codilar\Common\Controller\Index
 */
class SendEmail extends \Magento\Framework\App\Action\Action
{

    CONST PAYMENT_CODE = 'banktransfer';
    CONST PAY_NOW_METHOD = "custompayment";

    /**
     * @var CollectionFactoryInterface
     */
    protected $collectionFactoryInterface;

    protected $emailTemplate;

    private $_resource;

    private $_transportbuilder;
     /**
     * @var \Codilar\OrdersExport\Helper\Data
     */
    private $helper;
    /**
     * @var StoreManagerInterface
     */
    private $storeManager;
    /**
     * @var ScopeConfigInterface
     */
    private $_scopeConfig;
    /**
     * @var LoggerInterface
     */
    private $logger;
    /**
     * @var \Magento\Sales\Api\OrderRepositoryInterface
     */
    protected $orderRepository;
    /**
     * @var \Magento\Framework\Api\SearchCriteriaBuilder
     */
    protected $searchCriteriaBuilder;
    
    public function __construct(
        ResourceConnection $_resource,
        Context $context,
        TransportBuilder $_transportbuilder,
        \Codilar\OrdersExport\Helper\Data $helper,
        StoreManagerInterface $storeManager,
        LoggerInterface $logger,
        ScopeConfigInterface $_scopeConfig,
        \Magento\Sales\Api\OrderRepositoryInterface $orderRepository,
        \Magento\Email\Model\BackendTemplate $emailTemplate,
        CollectionFactoryInterface $collectionFactoryInterface,
        \Magento\Framework\Api\SearchCriteriaBuilder $searchCriteriaBuilder
    )
    {
        parent::__construct($context);
        $this->_transportbuilder = $_transportbuilder;
        $this->_resource = $_resource;
        $this->helper = $helper;
        $this->logger = $logger;
        $this->storeManager = $storeManager;
        $this->_scopeConfig = $_scopeConfig;
        $this->emailTemplate = $emailTemplate;
        $this->orderRepository = $orderRepository;
        $this->collectionFactoryInterface = $collectionFactoryInterface;
        $this->searchCriteriaBuilder = $searchCriteriaBuilder;
    }

    /**
     * @return void
     */
    public function execute()
    {
        $searchCriteria = $this->searchCriteriaBuilder
        ->addFilter(
            'status',
            'pending',
            'eq'
        )->addFilter(
            'payment_method_code',
            'banktransfer',
            'eq'
        )
        ->addFilter(
            'banktransfer_transaction_id',
            null,
            'null'
        )
        ->create();

       // $orders = $this->orderRepository->getList($searchCriteria);
       $orders = $this->collectionFactoryInterface->create()->addFieldToSelect(
        '*'
    )->addFieldToFilter(
        ['payment_method_code','payment_method_code'],
        [
            ['eq' => self::PAYMENT_CODE],
            ['eq' => self::PAY_NOW_METHOD]
        ]
    )->addFieldToFilter(
        ['banktransfer_transaction_id'],
        [
            ['null' => null]
        ]
    )->addFieldToFilter(
        ['status','status'],
        [
            ['eq' => "pending_payment"],
            ['eq' => "pending"]
        ]
    )
    ->addFieldToFilter(
        ['state'],
        [
            ['eq' => "new"]
        ]
    )
    ->setOrder(
        'created_at',
        'desc'
    );
        echo "<pre>";
       // print_r($orders->getData());
        //die;
        $total_days = $this->_scopeConfig->getValue('feedback/email_days_config/email_send_days', \Magento\Store\Model\ScopeInterface::SCOPE_STORE);


       $current_date = date("Y-m-d H:i:s");


        foreach($orders as $order){
            $entity_id = $order["entity_id"];
            $updated_at = $order["created_at"];
            $new_updated_date =  date('Y-m-d H:i:s', strtotime($updated_at. ' + 5 days'));
            if($current_date<=$new_updated_date){
                //$this->sendMail($order);
                
                $updateCriteria = $this->searchCriteriaBuilder
                ->addFilter(
                    'entity_id',
                    $entity_id,
                    'eq'
                )
                ->create();
                $order_data = $this->orderRepository->getList($updateCriteria);
                foreach($order_data as $order){
                    $order->setData("state","new");
                    $order->setData("status","payment_wait");
                    $order->save();
                }
            }else{
                $updateCriteria = $this->searchCriteriaBuilder
                ->addFilter(
                    'entity_id',
                    $entity_id,
                    'eq'
                )
                ->create();
                $order_data = $this->orderRepository->getList($updateCriteria);
                foreach($order_data as $order){
                    $order->setData("state","holded");
                    $order->setData("status","holded");
                    $order->save();
                }
            }
        }

    }

    public function sendMail($order){
        
        try {
            $email_template = $this->emailTemplate->load('Order on hold', 'template_code');
            $storeid = $this->storeManager->getStore()->getId();
            $templateId = $email_template->getId(); 
            $customer_email = $order["customer_email"];

            $senderName = $this->helper->getSMTPData("trans_email/ident_general/name");
            $senderEmail = $this->helper->getSMTPData("trans_email/ident_general/email");
            $sender = [
                'name' => $senderName,
                'email' => $senderEmail,
            ];
            $vars = [
                'order' => $order
            ];
            if ($templateId && $senderEmail) {
                $transport = $this->_transportbuilder
                    ->setTemplateIdentifier($templateId)
                    ->setTemplateOptions(['area' => \Magento\Framework\App\Area::AREA_FRONTEND, 'store' => $storeid])
                    ->setTemplateVars($vars)
                    ->setFrom($sender)
                    ->addTo($customer_email, "Rehandel")
                    ->getTransport();
                $transport->sendMessage();
            }
        }
        catch (\Exception $e){
            //$this->logger->debug($e->getMessage());
        }
    }

}