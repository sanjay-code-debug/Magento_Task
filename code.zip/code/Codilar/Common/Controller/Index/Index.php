<?php

namespace Codilar\Common\Controller\Index;

use Magento\Catalog\Model\ProductFactory;
use Magento\Customer\Model\CustomerFactory;
use Magento\Framework\App\Action\Context;
use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Sales\Model\OrderFactory;
use Magento\Store\Model\StoreManagerInterface;

/**
 * Class Index
 * @package Codilar\Common\Controller\Index
 */
class Index extends \Magento\Framework\App\Action\Action
{

    /**
     * @var OrderFactory
     */
    private $_orderFactory;
    /**
     * @var CustomerFactory
     */
    private $_customerFactory;
    /**
     * @var ProductFactory
     */
    private $_productFactory;
    /**
     * @var ScopeConfigInterface
     */
    private $_scopeConfig;
    /**
     * @var StoreManagerInterface
     */
    private $_storeManager;

    /**
     * Index constructor.
     * @param Context               $context
     * @param OrderFactory          $orderFactory
     * @param CustomerFactory       $customerFactory
     * @param ProductFactory        $productFactory
     * @param ScopeConfigInterface  $scopeConfig
     * @param StoreManagerInterface $storeManager
     */
    public function __construct(
        Context $context,
        OrderFactory $orderFactory,
        CustomerFactory $customerFactory,
        ProductFactory $productFactory,
        ScopeConfigInterface $scopeConfig,
        StoreManagerInterface $storeManager
    )
    {
        parent::__construct($context);
        $this->_orderFactory = $orderFactory;
        $this->_customerFactory = $customerFactory;
        $this->_productFactory = $productFactory;
        $this->_scopeConfig = $scopeConfig;
        $this->_storeManager = $storeManager;
    }

    /**
     * @return void
     */
    public function execute()
    {
        $this->_redirect('/');
        return;
        $allStores = $this->_storeManager->getStores();
        print_r(array_keys($allStores));
        foreach (array_keys($allStores) as $storeId) {
            echo $this->_scopeConfig->getValue('web/secure/base_url', 'store', $storeId) . "<br>";
            echo $this->_scopeConfig->getValue('web/unsecure/base_url', 'store', $storeId) . "<br>";
        }
        die;
        return;
        //  for($i=0;$i<100000;$i++)
        //      echo "$i \n";
        echo __CLASS__;
        echo "\n";
        echo count($this->_orderFactory->create()->getCollection());
        echo "\n";
        echo count($this->_customerFactory->create()->getCollection());
        echo "\n";
        echo count($this->_productFactory->create()->getCollection());
    }

}