<?php

namespace Codilar\Common\Ui\Component\Listing\Column;

/**
 * Class DisplayPages
 * @package Codilar\Common\Ui\Component\Listing\Column
 */
class DisplayPages implements \Magento\Framework\Data\OptionSourceInterface
{
    /**
     * Get options
     *
     * @return array
     */
    public function toOptionArray()
    {
        return [
            ['value' => 'all', 'label' => __('All Pages')],
            ['value' => 'cms_index_index', 'label' => __('Homepage')],
            ['value' => 'cms_page_view', 'label' => __('Cms Static Pages')],
            ['value' => 'catalog_category_view', 'label' => __('Category Page')],
            ['value' => 'catalog_product_view', 'label' => __('Product Page')],
            ['value' => 'checkout_cart_index', 'label' => __('Cart Page')],
            ['value' => 'checkout_cart_view', 'label' => __('Cart View Page')],
            ['value' => 'checkout_index_index', 'label' => __('Checkout Page')],
            ['value' => 'customer_account_index', 'label' => __('Customer Dashboard Page')],
            ['value' => 'customer_account_login', 'label' => __('Customer Login Page')],
            ['value' => 'customer_account_create', 'label' => __('Customer Create Page')]
        ];
    }
}