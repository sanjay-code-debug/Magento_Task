<?php

namespace Codilar\Common\Ui\Component\Listing\Column;

use Magento\Framework\Stdlib\DateTime\TimezoneInterface;
use Magento\Framework\View\Element\UiComponent\ContextInterface;
use Magento\Framework\View\Element\UiComponentFactory;
use Magento\Sales\Api\OrderRepositoryInterface;
use Magento\Ui\Component\Listing\Columns\Column;

/**
 * Class StoreViewDate
 */
class StoreViewDate extends Column
{
    /**
     * @var TimezoneInterface
     */
    private $timezone;
    /**
     * @var OrderRepositoryInterface
     */
    private $orderRepository;


    /**
     * Constructor
     *
     * @param ContextInterface         $context
     * @param UiComponentFactory       $uiComponentFactory
     * @param TimezoneInterface        $timezone
     * @param OrderRepositoryInterface $orderRepository
     * @param array                    $components
     * @param array                    $data
     */
    public function __construct(
        ContextInterface $context,
        UiComponentFactory $uiComponentFactory,
        TimezoneInterface $timezone,
        OrderRepositoryInterface $orderRepository,
        array $components = [],
        array $data = []
    )
    {

        parent::__construct($context, $uiComponentFactory, $components, $data);
        $this->timezone = $timezone;
        $this->orderRepository = $orderRepository;
    }

    /**
     * Prepare Data Source
     *
     * @param array $dataSource
     * @return array
     */
    public function prepareDataSource(array $dataSource)
    {
        if (isset($dataSource['data']['items'])) {
            foreach ($dataSource['data']['items'] as & $item) {
                $order = $this->orderRepository->get($item['entity_id']);
                $orderStoreDate = $this->formatDate(
                    $order->getCreatedAt(),
                    \IntlDateFormatter::MEDIUM,
                    true,
                    $this->getTimezoneForStore($order->getStore())
                );
                $item['updated_at'] = $orderStoreDate;
            }
        }

        return $dataSource;
    }

    /**
     * Retrieve formatting date
     *
     * @param null|string|\DateTimeInterface $date
     * @param int                            $format
     * @param bool                           $showTime
     * @param null|string                    $timezone
     * @return string
     */
    public function formatDate(
        $date = null,
        $format = \IntlDateFormatter::SHORT,
        $showTime = false,
        $timezone = null
    )
    {
        $date = $date instanceof \DateTimeInterface ? $date : new \DateTime($date);
        return $this->timezone->formatDateTime(
            $date,
            $format,
            $showTime ? $format : \IntlDateFormatter::NONE,
            null,
            $timezone
        );
    }

    /**
     * Get timezone for store
     *
     * @param mixed $store
     * @return string
     */
    public function getTimezoneForStore($store)
    {
        return $this->timezone->getConfigTimezone(
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE,
            $store->getCode()
        );
    }
}
