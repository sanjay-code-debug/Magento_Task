<?php

namespace Codilar\Common\Ui\Component\Listing\Column;

use Magento\Framework\View\Element\UiComponent\ContextInterface;
use Magento\Framework\View\Element\UiComponentFactory;
use Magento\Sales\Api\OrderRepositoryInterface;
use Magento\Ui\Component\Listing\Columns\Column;

/**
 * Class StoreViewDate
 */
class OrderVerify extends Column
{
    /**
     * @var OrderRepositoryInterface
     */
    private $orderRepository;


    /**
     * Constructor
     *
     * @param ContextInterface         $context
     * @param UiComponentFactory       $uiComponentFactory
     * @param OrderRepositoryInterface $orderRepository
     * @param array                    $components
     * @param array                    $data
     */
    public function __construct(
        ContextInterface $context,
        UiComponentFactory $uiComponentFactory,
        OrderRepositoryInterface $orderRepository,
        array $components = [],
        array $data = []
    )
    {
        parent::__construct($context, $uiComponentFactory, $components, $data);
        $this->orderRepository = $orderRepository;
    }

    /**
     * Prepare Data Source
     *
     * @param array $dataSource
     * @return array
     */
    public function prepareDataSource(array $dataSource)
    {
        $orderStatus = "";
        if (isset($dataSource['data']['items'])) {
            foreach ($dataSource['data']['items'] as & $item) {
                $order = $this->orderRepository->get($item['entity_id']);
                if($order->getIsOrderVerify()==null){
                    $orderStatus = "Order Not Verified";
                }
                else{
                    $orderStatus = $order->getIsOrderVerify();
                }
                $item[$this->getData('name')] = $orderStatus;
            }
        }

        return $dataSource;
    }

}
