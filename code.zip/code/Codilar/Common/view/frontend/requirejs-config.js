var config = {
    "paths": {
        "magnifier/magnify": "Codilar_Common/js/magnify",
        "magnifier/magnifier": "Codilar_Common/js/magnifier",
    },
    'config': {
        'mixins': {
            'mage/gallery/gallery': {
                "Codilar_Common/js/galleryMixin": true
            }
        }
    }
};