define(['mage/utils/wrapper'], function (wrapper) {
	'use strict';
	return function (targetModule) {

		return targetModule.extend({
			initFullscreenSettings: function () {
				var self = this;

				var result = this._super(); //call parent method
				this.settings.$element.on('mouseup', '.magnifier-large', function () {
					self.openFullScreen();
				});
				return result;
			}
		});
	};
});