<?php
/**
 * Created by salman.
 * Date: 2/4/18
 * Time: 3:21 PM
 * Filename: AbstractIpn.php
 */

namespace Codilar\Common\Model\Paypal;

/**
 * Class Ipn
 * @package Codilar\Common\Model\Paypal
 */
class Ipn extends \Magento\Paypal\Model\Ipn
{
    /**
     * Get ipn data, send verification to PayPal, run corresponding handler
     *
     * @return void
     * @throws \Exception
     */
    public function processIpnRequest()
    {
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $loggerHelper = $objectManager->get('Codilar\Common\Helper\Logger');
        $loggerHelper->addPaymentLog($this->getRequestData());
        parent::processIpnRequest();
    }
}
