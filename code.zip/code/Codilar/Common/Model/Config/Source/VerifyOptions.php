<?php

namespace Codilar\Common\Model\Config\Source;

class VerifyOptions implements \Magento\Framework\Option\ArrayInterface
{
    /**
     * Get options
     *
     * @return array
     */
    public function toOptionArray()
    {
        return [
            ['value' => 'Order Verified', 'label' => __('Order Verified')],
            ['value' => 'Order Not Verified', 'label' => __('Order Not Verified')]
        ];
    }
}
