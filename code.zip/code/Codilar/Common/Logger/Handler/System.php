<?php
/**
 * Created by salman.
 * Date: 27/4/18
 * Time: 11:08 AM
 * Filename: System.php
 */

namespace Codilar\Common\Logger\Handler;

/**
 * Class System
 * @package Codilar\Common\Logger\Handler
 */
class System extends \Magento\Framework\Logger\Handler\System
{
    /**
     * @param array $record
     * @return $this|void
     */
    public function write(array $record)
    {
        return $this;
        parent::write($record);
    }
}