<?php

namespace Codilar\SmsModule\Model;
class SmsLog extends \Magento\Framework\Model\AbstractModel
{
    const CACHE_TAG = 'codilar_sms_sent_log';

    public function getIdentities()
    {
        return [self::CACHE_TAG . '_' . $this->getId()];
    }

    protected function _construct()
    {
        $this->_init('Codilar\SmsModule\Model\ResourceModel\SmsLog');
    }
}
