<?php

namespace Codilar\SmsModule\Block;

use Magento\Customer\Api\CustomerRepositoryInterface;
use Magento\Customer\Model\CustomerFactory;
use Magento\Framework\Data\Form\FormKey;
use Magento\Framework\Registry;
use Magento\Framework\View\Element\Template\Context;
use Magento\Store\Model\StoreManagerInterface;

/**
 * Class ResetOtp
 * @package Codilar\Customer\Block
 */
class ResetOtp extends \Magento\Framework\View\Element\Template
{
    private $orderRepository;
    protected $_checkoutSession;

    protected $customerSession;
    /**
     * @var Registry
     */
    protected $_registry;
    /**
     * @var
     */
    protected $_mobileNumber;
    /**
     * @var
     */
    protected $_customerId;
    /**
     * @var FormKey
     */
    protected $_formKey;
    /**
     * @var CustomerFactory
     */
    protected $_customerFactory;
    /**
     * @var \Magento\Framework\App\Config\ScopeConfigInterface
     */
    protected $_scopeConfig;
    /**
     * @var StoreManagerInterface
     */
    private $storeManager;
    /**
     * @var CustomerRepositoryInterface
     */
    private $customerRepository;

    /**
     * ResetOtp constructor.
     * @param Registry                    $registry
     * @param Context                     $context
     * @param FormKey                     $formKey
     * @param CustomerFactory             $customerFactory
     * @param StoreManagerInterface       $storeManager
     * @param CustomerRepositoryInterface $customerRepository
     * @param array                       $data
     */
    public function __construct(
        Registry $registry,
        Context $context,
        FormKey $formKey,
        CustomerFactory $customerFactory,
        StoreManagerInterface $storeManager,
        CustomerRepositoryInterface $customerRepository,
        \Magento\Sales\Api\OrderRepositoryInterface $orderRepository ,
        \Magento\Customer\Model\Session $customerSession,
        \Magento\Checkout\Model\Session $checkoutSession,
        array $data = []
    )
    {
        $this->orderRepository = $orderRepository;
        $this->_registry = $registry;
        $this->_formKey = $formKey;
        $this->_customerFactory = $customerFactory;
        $this->_scopeConfig = $context->getScopeConfig();
        parent::__construct($context, $data);
        $this->storeManager = $storeManager;
        $this->customerRepository = $customerRepository;
        $this->customerSession = $customerSession;
        $this->_checkoutSession = $checkoutSession;
    }

    /**
     * @return mixed
     */
    public function getMobileNumber()
    {
        $order = $this->_checkoutSession->getLastRealOrder();
        $orderId=$order->getEntityId();
        $order->getIncrementId();
        $mobileNumber = $order->getShippingAddress()->getTelephone();
        $this->_mobileNumber = $mobileNumber;
        return $mobileNumber;
    }

    public function getShippingDetails(){
        $order = $this->_checkoutSession->getLastRealOrder();
        $address_details = $order->getShippingAddress();
        return $address_details;
    }

    /**
     * @param $customerId
     * @return string
     * @throws \Magento\Framework\Exception\LocalizedException
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     */
    public function getCountryCode($customerId)
    {
        if($customerId){
            $customer = $this->customerRepository->getById($customerId);
             $countryCode = $customer->getCustomAttribute("country_code");
            if ($countryCode) {
                $countryCode = $customer->getCustomAttribute("country_code")->getValue();
                return "+" . $countryCode;
            }
            else{
                $countryCode = $this->getCountryCodeFromConfig();
                return "+" . $countryCode;
            }
        }
        else{
            $countryCode = $this->getCountryCodeFromConfig();
            return "+" . $countryCode;
        }
    }

    /**
     * This function will return Country Code
     * @param null
     * @return string
     */
    public function getCountryCodeFromConfig()
    {
        return $this->_scopeConfig->getValue('smsmodule/sms_global/country_code', \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
    }

    /**
     * @return int
     */
    public function getCustomerId()
    {
        if($this->customerSession->getCustomer()->getId()){
            $this->_customerId = $this->customerSession->getCustomer()->getId();
        }
        else{
            $this->_customerId = null;
        }
        
        return $this->_customerId;
    }

    /**
     * @return string
     */
    public function getResetMobileAction()
    {
        $mobileNumber = $this->_mobileNumber;
        $id = $this->_customerId;
        $baseUrl = $this->getUrl("codilar_customer/account/resetpasswordmobile/?id=$id&mobilenumber=$mobileNumber");
        return $baseUrl;
    }

    /**
     * @return string
     */
    public function getFormKey()
    {
        return $this->_formKey->getFormKey();
    }
}
