<?php

namespace Codilar\SmsModule\Controller\Adminhtml\Sms;

use Codilar\SmsModule\Model\SmsLogFactory;
use Magento\Backend\App\Action;

/**
 * Class Delete
 * @package Codilar\SmsModule\Controller\Adminhtml\Sms
 */
class Delete extends Action
{
    /**
     * @var \Magento\Framework\Filesystem
     */
    protected $_fileSystem;
    /**
     * @var \Magento\Framework\Filesystem\Driver\File
     */
    protected $_file;
    /**
     * @var SmsLogFactory
     */
    protected $_smsFactory;

    /**
     * Delete constructor.
     * @param \Magento\Framework\Filesystem             $filesystem
     * @param \Magento\Framework\Filesystem\Driver\File $file
     * @param Action\Context                            $context
     * @param SmsLogFactory                             $smsFactory
     */
    public function __construct(
        \Magento\Framework\Filesystem $filesystem,
        \Magento\Framework\Filesystem\Driver\File $file,
        Action\Context $context,
        SmsLogFactory $smsFactory
    )
    {
        $this->_fileSystem = $filesystem;
        $this->_file = $file;
        $this->_smsFactory = $smsFactory;
        parent::__construct($context);
    }

    /**
     * Delete action
     *
     * @return \Magento\Framework\Controller\ResultInterface
     */
    public function execute()
    {
        $id = $this->getRequest()->getParam('id');
        /** @var \Magento\Backend\Model\View\Result\Redirect $resultRedirect */
        $resultRedirect = $this->resultRedirectFactory->create();
        if ($id) {
            try {
                $Sms = $this->_smsFactory->create()->load($id);
                $Sms->delete();
                $this->messageManager->addSuccess(__('The Sms has been deleted.'));
                return $resultRedirect->setPath('*/*/');
            } catch (\Exception $e) {
                $this->messageManager->addError($e->getMessage());
                return $resultRedirect->setPath('*/*/edit', ['id' => $id]);
            }
        }
        $this->messageManager->addError(__('We can\'t find the Sms to delete.'));
        return $resultRedirect->setPath('*/*/');
    }
}
