<?php

namespace Codilar\SmsModule\Controller\Sms;

use Codilar\SmsModule\Helper\Data;
use Codilar\SmsModule\Model\SmsLogger;
use Magento\Framework\App\Action\Context;

/**
 * Class Index
 * @package Codilar\SmsModule\Controller\Index
 */
class Index extends \Magento\Framework\App\Action\Action
{
    /**
     * @var Data
     */
    protected $_helper;
    /**
     * @var SmsLogger
     */
    protected $_bannerDealsModel;

    /**
     * Index constructor.
     * @param Context               $context
     * @param Data                  $helperData
     * @param SmsLogger             $bannerDeals
     * @param CollectionFactory     $collectionFactory
     * @param LoggerInterface       $loggerInterface
     * @param TimezoneInterface     $timezoneInterface
     * @param StoreRepository       $storeRepository
     * @param StoreManagerInterface $storeManager
     */
    public function __construct(
        Context $context,
        Data $helperData,
        SmsLogger $bannerDeals
    )
    {
        $this->_helper = $helperData;
        $this->_bannerDealsModel = $bannerDeals;
        parent::__construct($context);
    }

    public function execute()
    {
        $data = $this->_helper->getCountryCodeFromMobile("434119999");
        echo $data;
        die;
        $this->_helper->getCountryCodeFromMobile("7411551772");
        die;
        $this->_helper->sendMessageToAusNumber("61434119999", "Testing message from shopmonk developer", "Testing", "1");
    }
}