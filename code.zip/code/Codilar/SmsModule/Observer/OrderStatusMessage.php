<?php

namespace Codilar\SmsModule\Observer;

use Codilar\SmsModule\Helper\Data;

class OrderStatusMessage implements \Magento\Framework\Event\ObserverInterface
{

    CONST ORDER_DISPATCHED = "dispatched"; //custom status
    CONST ORDER_CONFIRMED = "processing"; //order is confirmed
    CONST ORDER_CANCELED = "canceled";
    CONST ORDER_CLOSED = "closed";
    CONST ORDER_DELIVERED = "delivered";
    /** @var \Magento\Framework\Logger\Monolog */
    protected $_logger;
    /**
     * @var \Magento\Sales\Model\OrderFactory
     */
    protected $_orderFactory;
    /**
     * @var Data
     */
    protected $_smsSender;

    /**
     * OrderStatus constructor.
     * @param \Psr\Log\LoggerInterface          $loggerInterface
     * @param \Magento\Sales\Model\OrderFactory $orderFactory
     * @param Data                              $sender
     */
    public function __construct(
        \Psr\Log\LoggerInterface $loggerInterface,
        \Magento\Sales\Model\OrderFactory $orderFactory,
        Data $sender
    )
    {
        $this->_logger = $loggerInterface;
        $this->_orderFactory = $orderFactory;
        $this->_smsSender = $sender;
    }

    /**
     * This is the method that fires when the event runs.
     *
     * @param \Magento\Framework\Event\Observer $observer
     */
    public function execute(\Magento\Framework\Event\Observer $observer)
    {
        $order = $observer->getOrder();
        $shippingAddress = $order->getShippingAddress();
        $order = $this->_orderFactory->create()->load($order->getId());
        $items = $order->getAllVisibleItems();
        $itemNames = [];
        foreach ($items as $item) {
            $itemNames[] = $item->getName();
        }
        $itemsList = implode(",", $itemNames);
        $itemLength = count($itemNames);
        $finalLength = $itemLength - 1;
        $telephone = $shippingAddress->getTelephone();
        if ($order->getStatus() == $this::ORDER_CANCELED) {
            $this->_smsSender->sendMessage($telephone, "order_cancel", false, $order->getId(), $itemsList);
        } else if ($order->getStatus() == $this::ORDER_CLOSED) {
            $this->_smsSender->sendMessage($telephone, "order_closed", false, $order->getId(), $itemsList);
        } else if ($order->getStatus() == $this::ORDER_CONFIRMED) {
            $this->_smsSender->sendMessage($telephone, "order_confirmation", false, $order->getId(), $itemsList);
        } else if ($order->getStatus() == $this::ORDER_DELIVERED) {
            $this->_smsSender->sendMessage($telephone, "order_delivered", false, $order->getId(), $itemsList);
        } else if ($order->getStatus() == $this::ORDER_DISPATCHED) {
            $this->_smsSender->sendMessage($telephone, "order_dispatched", false, $order->getId(), $itemsList);
        }
    }
}