<?php
namespace Codilar\CustomCommand\Console\Command;

use Symfony\Component\Console\Command\Command;
use Symfony\Component\Console\Input\InputArgument;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;

class CustomSellCommand extends Command
{
    protected function configure()
    {
        $this->setName("custom:name");
        $this->setDescription("This is custom welcome command");
        $this->addArgument('username', InputArgument::REQUIRED, 'The username of the user.');
        $this->setHelp("This is a custom command where we need to pass a argument name it will welcome that person");
        parent::configure();
    }

    protected function execute(InputInterface $input, OutputInterface $output)
    {
        $name = $input->getArgument('username');
        $output->writeln("<info>hello $name welcome to our world</info>");
    }

}
