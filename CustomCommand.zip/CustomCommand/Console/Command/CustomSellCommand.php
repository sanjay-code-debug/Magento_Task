<?php
namespace Codilar\CustomCommand\Console\Command;

use Symfony\Component\Console\Command\Command;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;
use Symfony\Component\Process\Process;

class CustomSellCommand extends Command
{
    protected function configure()
    {
        $this->setName("check:package");
        $this->setDescription("This is custom command to Check the Package");
        parent::configure();
    }

    protected function execute(InputInterface $input, OutputInterface $output)
    {
        try {
            $this->getApplication()->find('cache:flush')->run($input, $output);
            $process = new Process(['sudo','chmod','-R','777','/var/www/html/adobe_training/var',
                '/var/www/html/adobe_training/pub','/var/www/html/adobe_training/generated']);
            $process->start();

            foreach ($process as $type => $data) {
                if ($process::OUT === $type) {
                    echo "\nRead from stdout: ".$data;
                } else {
                    echo "\nRead from stderr: ".$data;// $process::ERR === $type
                }
            }
        } catch (\Exception $e) {
            $output->writeln('<error>command not found</error>');
        }
        $output->writeln('<info>command run successfully</info>');
    }
}
