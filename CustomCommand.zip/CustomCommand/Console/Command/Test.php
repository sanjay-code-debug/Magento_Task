<?php
namespace Codilar\CustomCommand\Console\Command;

use \Symfony\Component\Console\Command\Command;
use \Symfony\Component\Console\Input\InputInterface;
use \Symfony\Component\Console\Output\OutputInterface;

class Test extends Command
{
    protected function configure()
    {
        $this->setName('check:composer')->setDescription('custom command to check the composer version');
        parent::configure();
    }

    protected function execute(InputInterface $input, OutputInterface $output)
    {
//      system("rm -r generated/*");
        system("php -v");
        $output->writeln('Generation Folder Clean Successfully.');
    }
}
