<?php
namespace Codilar\EmployeeDetails\Console\Command;

use Symfony\Component\Console\Command\Command;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Input\InputOption;
use Symfony\Component\Console\Output\OutputInterface;
use Symfony\Component\Process\Exception\ProcessFailedException;
use Symfony\Component\Process\Process;


class CustomCommand extends Command
{
    protected function configure()
    {
        $this->setName("custom:clean");
        $this->setDescription("This is custom command which clear and flush cache and give permission");
        parent::configure();
    }

    protected function execute(InputInterface $input, OutputInterface $output)
    {
        try {
            $this->getApplication()->find('setup:di:compile')->run($input,$output);
            $this->getApplication()->find('cache:clean')->run($input,$output);
            $this->getApplication()->find('cache:flush')->run($input,$output);
            $process = new Process(['sudo','chmod','-R','777','/var/www/html/magento2/project-community-edition/var',
                '/var/www/html/magento2/project-community-edition/pub','/var/www/html/magento2/project-community-edition/generated']);
            $process->start();
            foreach ($process as $type => $data) {
                if ($process::OUT === $type) {
                    echo "\nRead from stdout: ".$data;
                } else { // $process::ERR === $type
                    echo "\nRead from stderr: ".$data;
                }
            }

        }catch (\Exception $e)
        {
            $output->writeln('<error>command not found</error>');
        }
        $output->writeln('<info>command run successfully</info>');

    }

}
