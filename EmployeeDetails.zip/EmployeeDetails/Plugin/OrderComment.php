<?php

namespace Codilar\EmployeeDetails\Plugin;

class OrderComment
{
    protected \Magento\Backend\Model\Auth\Session $authSession;

    public function __construct( \Magento\Backend\Model\Auth\Session $authSession)
    {
        $this->authSession = $authSession;
    }
    /**
     * Returns comment
     *
     * @return string
     */
    public function afterGetComment()
    {
        return $this->authSession->getName();
    }
}
