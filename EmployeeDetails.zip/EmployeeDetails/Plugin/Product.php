<?php

namespace Codilar\EmployeeDetails\Plugin;

class Product
{
    public function aftergetName(\Magento\Catalog\Model\Product $product,$name)
    {
        $price = $product->getData('price');
        if($price >= 50)
        {
            $name .= "so expensive";
        }
        else
        {
             $name .= "so cheap";
        }
        return $name;
    }

}
