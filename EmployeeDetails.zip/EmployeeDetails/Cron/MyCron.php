<?php
namespace Codilar\EmployeeDetails\Cron;

class MyCron
{
    private $logger;

    public function __construct(\Psr\Log\LoggerInterface $logger)
    {
        $this->logger = $logger;
    }
    public function execute()
    {
        try {

            $this->logger->info("The task is executed on ".date("d/m/y h:i:s"));
        } catch (\Exception $e) {
            $this->logger->critical('Error message', ['exception' => $e]);
        }
    }
}



?>
