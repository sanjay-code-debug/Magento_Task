<?php
namespace Codilar\EmployeeDetails\Block;

use Magento\Framework\View\Element\Template;
use Codilar\EmployeeDetails\Helper\Data;

class ConfigBlock extends Template
{
    private $helperData;

    public function __construct(Template\Context $context, Data $helperData )
    {
        $this->helperData = $helperData;
        parent::__construct($context);

    }

    public function isEnable()
    {
        return $this->helperData->isModuleEnable();
//        $result = $this->helperData->getGeneralConfig('enable');
//        if ($result == 1) {
//            return true;
//        }
//        else{
//            return  false;
//        }
    }

}

?>
