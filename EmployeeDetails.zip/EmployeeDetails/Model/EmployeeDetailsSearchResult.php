<?php
namespace Codilar\EmployeeDetails\Model;

use Codilar\EmployeeDetails\Api\Data\EmployeeDetailsSearchResultInterface;
use Magento\Framework\Api\SearchResults;

class EmployeeDetailsSearchResult extends SearchResults implements EmployeeDetailsSearchResultInterface
{

}
