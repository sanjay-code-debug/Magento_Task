<?php

namespace Codilar\SmsModule\Cron;

use Codilar\SmsModule\Helper\Data;
use Codilar\SmsModule\Model\SmsLogger;
use Psr\Log\LoggerInterface;

class DeleteSms
{
    /**
     * @var Data
     */
    protected $_helper;
    /**
     * @var LoggerInterface
     */
    protected $_logger;
    /**
     * @var SmsLogger
     */
    protected $_smsLoggerModel;

    /**
     * DeleteSms constructor.
     * @param Data            $helperData
     * @param SmsLogger       $smsLogger
     * @param LoggerInterface $loggerInterface
     */
    public function __construct(
        Data $helperData,
        SmsLogger $smsLogger,
        LoggerInterface $loggerInterface
    )
    {
        $this->_helper = $helperData;
        $this->_smsLoggerModel = $smsLogger;
        $this->_logger = $loggerInterface;
    }

    public function execute()
    {
        $days = $this->_helper->getLogClearingDays();
        $this->_smsLoggerModel->deleteSmsLog($days);
    }
}