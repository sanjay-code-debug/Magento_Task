<?php

namespace Codilar\SmsModule\Observer;

use Codilar\SmsModule\Helper\Data;

class SendOrderMessage implements \Magento\Framework\Event\ObserverInterface
{

    /** @var \Magento\Framework\Logger\Monolog */
    protected $_logger;
    /**
     * @var \Magento\Sales\Model\OrderFactory
     */
    protected $_orderFactory;
    /**
     * @var Data
     */
    protected $_smsSender;

    /**
     * SendOrderMessage constructor.
     * @param \Psr\Log\LoggerInterface          $loggerInterface
     * @param \Magento\Sales\Model\OrderFactory $orderFactory
     * @param Data                              $sender
     */
    public function __construct(
        \Psr\Log\LoggerInterface $loggerInterface,
        \Magento\Sales\Model\OrderFactory $orderFactory,
        Data $sender
    )
    {
        $this->_logger = $loggerInterface;
        $this->_orderFactory = $orderFactory;
        $this->_smsSender = $sender;
    }

    /**
     * This is the method that fires when the event runs.
     *
     * @param \Magento\Framework\Event\Observer $observer
     */
    public function execute(\Magento\Framework\Event\Observer $observer)
    {
        $orderIds = $observer->getEvent()->getOrderIds();
        if (count($orderIds)) {
            $orderId = $orderIds[0];
            $order = $this->_orderFactory->create()->load($orderId);
            $items = $order->getAllVisibleItems();
            $itemNames = [];
            foreach ($items as $item) {
                $itemNames[] = $item->getName();
            }
            $itemsList = implode(",", $itemNames);
            $itemLength = count($itemNames);
            $finalLength = $itemLength - 1;
            $mobile = $order->getShippingAddress()->getTelephone();
            $shipping = $order->getShippingMethod();
            if($shipping == 'storepickup_storepickup') {
                $mobile = $order->getBillingAddress()->getTelephone();
            }
            $result = $this->_smsSender->sendMessage($mobile, "order_place", false, $orderId, $itemsList);
        }
    }
}