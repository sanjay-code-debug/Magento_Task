<?php

namespace Codilar\SmsModule\Ui\Component\Listing\DataProvider;

use Codilar\SmsModule\Model\ResourceModel\SmsLog\CollectionFactory;

/**
 * Class SmsGrid
 * @package Codilar\SmsModule\Ui\Component\Listing\DataProvider
 */
class SmsGrid extends \Magento\Ui\DataProvider\AbstractDataProvider
{
    /**
     * Grid constructor.
     * @param string            $name
     * @param string            $primaryFieldName
     * @param string            $requestFieldName
     * @param CollectionFactory $collectionFactory
     * @param array             $meta
     * @param array             $data
     */
    public function __construct(
        $name,
        $primaryFieldName,
        $requestFieldName,
        CollectionFactory $collectionFactory,
        array $meta = [],
        array $data = []
    )
    {
        parent::__construct($name, $primaryFieldName, $requestFieldName, $meta, $data);
        $this->collection = $collectionFactory->create();
    }
}
