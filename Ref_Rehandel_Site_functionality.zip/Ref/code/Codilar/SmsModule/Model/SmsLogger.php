<?php

namespace Codilar\SmsModule\Model;

use Magento\Customer\Api\CustomerRepositoryInterface;
use Magento\Customer\Model\CustomerFactory;
use Magento\Framework\Model\Context;

class SmsLogger extends \Magento\Framework\Model\AbstractModel
{
    /**
     * @var \Codilar\SmsModule\Model\SmsLog
     */
    protected $_smsLogModel;
    /**
     * @var CustomerFactory
     */
    protected $_customerFactory;
    /**
     * @var \Magento\Store\Model\StoreManagerInterface
     */
    protected $_storeManager;
    /**
     * @var CustomerRepositoryInterface
     */
    private $customerRepository;

    public function __construct(
        Context $context,
        \Magento\Framework\Registry $registry,
        SmsLog $smsLogModel,
        CustomerRepositoryInterface $customerRepository,
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        CustomerFactory $customerFactory
    )
    {
        $this->_smsLogModel = $smsLogModel;
        $this->customerRepository = $customerRepository;
        $this->_customerFactory = $customerFactory;
        $this->_storeManager = $storeManager;
        parent::__construct($context, $registry);
    }

    public function saveMessage($mobileNumber, $message, $eventType, $smsStatus, $smsError, $email = false, $orderId = false, $user_type = false)
    {
        if (!$user_type) {
            $user_type = "tracked";
        }
        if (!$orderId) {
            $orderId = null;
        }
        if (!$email) {
            $email = $this->getEmailFromMobile($mobileNumber);
        }
        if (!is_numeric($mobileNumber)) {
            $email = $mobileNumber;
            $mobileNumber = null;
        }
        $logData = [
            "order_id" => $orderId,
            "event_type" => $eventType,
            "mobile_number" => $mobileNumber,
            "email" => $email,
            "sms_text" => $message,
            "sms_status" => $smsStatus,
            "sms_error" => $smsError,
            "user_type" => $user_type
        ];
        $model = $this->_smsLogModel;
        $model->setData($logData);
        try {
            $model->getResource()->save($model);
            return true;
        } catch (\Exception $e) {
            return false;
        }
    }

    public function getEmailFromMobile($mobileNumber)
    {
        $websiteId = $this->_storeManager->getWebsite()->getId();
        $email = $this->_customerFactory->create()->getCollection()
            ->addFieldToFilter("website_id", $websiteId)
            ->addFieldToFilter('mobile_number', $mobileNumber)
            ->getFirstItem()
            ->getEmail();
        if (!$email) {
            return null;
        }
        return $email;
    }

    public function deleteSmsLog($days)
    {
        $storeDate = date("Y-m-d H:i:s");
        $storeDateTimestamp = strtotime($storeDate);
        $logDaysTimestamp = $storeDateTimestamp - (86400 * $days);
        $logDays = date("Y-m-d H:i:s", $logDaysTimestamp);
        $collection = $this->_smsLogModel->getCollection()
            ->addFieldToFilter('created_time', ['lteq' => $logDays]);
        if ($collection->getData()) {
            foreach ($collection as $item) {
                $item->delete();
            }
            return true;
        } else {
            return false;
        }

    }

    public function setLatestSmsLog($mobileNumber)
    {
        $sms_data_log = $this->_smsLogModel->getCollection()->addFieldToFilter(['mobile_number', 'email'],
        [
            ['eq' => $mobileNumber],
            ['eq' => $mobileNumber]
        ])
        ->addFieldToFilter('user_type', "untracked");
         foreach($sms_data_log as $log_data){
            $log_data->setData("user_type","tracked");
            $log_data->save();  
         }
    }

    public function setLatestSmsLogUntrackked($mobile,$emailValue){
        $sms_data_log = $this->_smsLogModel->getCollection()->addFieldToFilter(['mobile_number', 'email'],
        [
            ['eq' => $mobile],
            ['eq' => $emailValue]
        ])
        ->addFieldToFilter('user_type', "untracked");
         foreach($sms_data_log as $log_data){
            $log_data->setData("user_type","tracked");
            $log_data->save();  
         }
    }

}