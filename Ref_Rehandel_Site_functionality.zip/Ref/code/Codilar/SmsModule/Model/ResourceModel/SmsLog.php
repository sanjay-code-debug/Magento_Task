<?php

namespace Codilar\SmsModule\Model\ResourceModel;
class SmsLog extends \Magento\Framework\Model\ResourceModel\Db\AbstractDb
{
    /**
     * Define model & resource model
     */
    protected $_idFieldName = 'id';

    protected function _construct()
    {
        $this->_init('codilar_sms_sent_log', 'id');
    }
}
