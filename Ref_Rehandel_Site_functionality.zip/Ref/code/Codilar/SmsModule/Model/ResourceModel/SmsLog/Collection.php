<?php

namespace Codilar\SmsModule\Model\ResourceModel\SmsLog;
class Collection extends \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection
{
    /**
     * Define model & resource model
     */
    protected $_idFieldName = 'id';

    protected function _construct()
    {
        $this->_init('Codilar\SmsModule\Model\SmsLog', 'Codilar\SmsModule\Model\ResourceModel\SmsLog');
    }
}
