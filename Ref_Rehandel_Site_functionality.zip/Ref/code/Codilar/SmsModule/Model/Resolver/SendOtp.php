<?php

namespace Codilar\SmsModule\Model\Resolver;

use Magento\Framework\GraphQl\Config\Element\Field;
use Magento\Framework\GraphQl\Query\ResolverInterface;
use Magento\Framework\GraphQl\Schema\Type\ResolveInfo;

use Codilar\Customer\Helper\Data as CustomerHelper;
use Codilar\Customer\Model\OtpLogger as OtpLogger;
use Codilar\SmsModule\Helper\Data as SmsHelper;
use Magento\Customer\Model\CustomerFactory;
use Magento\Framework\App\Config\ScopeConfigInterface;
use Codilar\Customer\Helper\Data;
use Codilar\Customer\Model\Otp;

use Codilar\Customer\Model\ResourceModel\Otp\Collection;


class SendOtp implements ResolverInterface
{
    /**
     * @var CustomerHelper
     */
    protected $customerHelper;
    /**
     * @var OtpLogger
     */
    private $otpLogger;
    /**
     * @var SmsHelper
     */
    private $smsHelper;
    /**
     * @var CustomerFactory
     */
    private $customerFactory;
    /**
     * @var ScopeConfigInterface
     */
    private $scopeConfig;
    /**
     * @var Data
     */
    private $helper;

    /**
     * @var Otp
     */
    protected $_otp;
    /**
     * @var Collection
     */
    private $collection;


    public function __construct
    (
        CustomerHelper $customerHelper,
        OtpLogger $otpLogger,
        SmsHelper $smsHelper,
        CustomerFactory $customerFactory,
        ScopeConfigInterface $scopeConfig,
        Data $helper,
        Otp $_otp,
        Collection $collection
    )
    {
        $this->customerHelper = $customerHelper;
        $this->otpLogger = $otpLogger;
        $this->smsHelper = $smsHelper;
        $this->customerFactory = $customerFactory;
        $this->scopeConfig = $scopeConfig;
        $this->helper = $helper;
        $this->_otp = $_otp;
    }
    public function resolve(Field $field, $context, ResolveInfo $info, array $value = null, array $args = null)
    {
           $country_Code = $args['Contry_Code'];
           $mobile = $args['Mobile'];
           $email = $args['Email'];

           global  $ar;
           $ar =array();

           $mobileNumber = str_replace($country_Code,"",$mobile);
           $id =$this->getEmailFromMobile($mobileNumber);

            $newPasswordToken = $this->customerHelper->getUniqueHash();
            $otp = mt_rand(100000, 999999);
            $current_timeout = time();

            if ($mobile) {
                $mobileNumberOtp = $country_Code . $mobile;
                $this->otpLogger->setCustomerOtp($id, $otp, $mobileNumberOtp, $newPasswordToken, $current_timeout);
                $this->smsHelper->sendMessage($mobileNumberOtp, "register", $otp);
                $otpValue = $this->getMobileOtp($mobileNumberOtp);
                $ar[] = ['message' => 'OTP Sent Successfully To Mobile','otp'=>$otpValue];
                return $ar;
            }

            if ($email) {
                $id = $this->getIdFromEmail($email);
                $this->otpLogger->setCustomerOtp($id, $otp, $email, $newPasswordToken, $current_timeout);
                $otptemplateid = $this->scopeConfig->getValue('smsmodule/sms/register_email_template', \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
                $this->helper->sendMail($otptemplateid, $email, $otp);
                $otpValue = $this->getEmailOtp($email);
                $ar[] = ['message' => 'OTP Sent Successfully To Email','otp'=>$otpValue];
                return $ar;
            }
            $ar[] = ['message' => 'OTP Not Sent Successfully '];
            return $ar;
    }

    public function getEmailFromMobile($mobileNumber) {
        $websiteId = $this->customerHelper->getWebsiteId();
        if ($this->customerHelper->getAccountSharingOptions()) {
            $email = $this->customerFactory->create()->getCollection()
                ->addFieldToFilter("website_id", $websiteId)
                ->addFieldToFilter('mobile_number', $mobileNumber)
                ->getFirstItem()
                ->getId();
        } else {
            $email = $this->customerFactory->create()->getCollection()
                ->addFieldToFilter('mobile_number', $mobileNumber)
                ->getFirstItem()
                ->getId();
        }
        return $email;
    }

    public function getIdFromEmail($email) {
        $websiteId = $this->customerHelper->getWebsiteId();
        if ($this->customerHelper->getAccountSharingOptions()) {
            $id = $this->customerFactory->create()->getCollection()
                ->addFieldToFilter("website_id", $websiteId)
                ->addFieldToFilter('email', $email)
                ->getFirstItem()
                ->getId();
        } else {
            $id = $this->customerFactory->create()->getCollection()
                ->addFieldToFilter('email', $email)
                ->getFirstItem()
                ->getId();
        }
        return $id;
    }

    public function getMobileOtp($mobile)
    {
        $otp_data = $this->_otp->getCollection()
            ->addFieldToFilter("mobile_number", $mobile)
            ->getLastItem();
        $otpData = $otp_data->getOtp();
        return $otpData;
    }

    public function getEmailOtp($email)
    {
        $otp_data = $this->_otp->getCollection()
            ->addFieldToFilter("email", $email)
            ->getLastItem();
        $otpData = $otp_data->getOtp();
        return $otpData;
    }
}

