<?php

namespace Codilar\SmsModule\Model\Resolver;

use Magento\Framework\GraphQl\Config\Element\Field;
use Magento\Framework\GraphQl\Query\ResolverInterface;
use Magento\Framework\GraphQl\Schema\Type\ResolveInfo;


use Codilar\Customer\Helper\Data as CustomerHelper;
use Magento\Customer\Model\CustomerFactory;
use Codilar\Customer\Model\OtpLogger;
use Magento\Customer\Model\SessionFactory;
use Magento\Integration\Model\Oauth\TokenFactory as TokenModelFactory;

class VerifyOtp implements ResolverInterface {

    /**
     * @var CustomerHelper
     */
    protected $customerHelper;

    /**
     * @var CustomerFactory
     */
    protected $customerFactory;

    /**
     * @var OtpLogger
     */
    protected $_otpLogger;
    /**
     * @var SessionFactory
     */
    private $sessionFactory;
    /**
     * @var Collection
     */
    private $collection;
    /**
     * @var TokenModelFactory
     */
    private $tokenFactory;

    public function __construct
    (
        CustomerHelper $customerHelper,
        CustomerFactory $customerFactory,
        OtpLogger $_otpLogger,
        SessionFactory $sessionFactory,
        TokenModelFactory $tokenFactory
    )
    {
        $this->customerHelper = $customerHelper;
        $this->customerFactory = $customerFactory;
        $this->_otpLogger = $_otpLogger;
        $this->sessionFactory = $sessionFactory;
        $this->tokenFactory = $tokenFactory;
    }

    public function resolve(Field $field, $context, ResolveInfo $info, array $value = null, array $args = null)
    {
        $country_code = $args['Country_Code'];
        $mobile = $args['Mobile'];
        $email = $args['Email'];
        $otp = $args['Otp'];

        global  $ar;
        $ar =array();


        $mobile_number = str_replace($country_code, "", $mobile);

        $websiteId = $this->customerHelper->getWebsiteId();

        if ($this->customerHelper->getAccountSharingOptions()) {
            $customerid = $this->customerFactory->create()->getCollection()
                ->addFieldToFilter("website_id", $websiteId)
                ->addFieldToFilter('mobile_number', $mobile_number)
                ->getFirstItem()->getId();
        } else {
            $customerid = $this->customerFactory->create()->getCollection()
                ->addFieldToFilter('mobile_number', $mobile_number)
                ->getFirstItem()->getId();
        }

        if ($email) {
            if ($this->customerHelper->getAccountSharingOptions()) {
                $customerid = $this->customerFactory->create()->getCollection()
                    ->addFieldToFilter("website_id", $websiteId)
                    ->addFieldToFilter('email', $email)
                    ->getFirstItem()->getId();
            } else {
                $customerid = $this->customerFactory->create()->getCollection()
                    ->addFieldToFilter('email', $email)
                    ->getFirstItem()->getId();
            }
        }

        if ($mobile_number) {
            $status = $this->_otpLogger->validateOtp($customerid, $otp, $country_code.$mobile_number);
            if ($status) {
                if($customerid){
                    $tokenForMobile = $this->getToken($customerid);
                }
                else{
                    $tokenForMobile=null;
                }
                $ar[] = ['message'=>'OTP Verified Successfully','token'=>$tokenForMobile,
                    'error'=> 0
                ];
                return $ar;
            }
            else{
                $ar[] =[
                    'message'=> 'OTP is invalid or expired, please try again On Mobile Verify',
                    'token'=> null,
                    'error'=> 1
                ];
                return $ar;
            }
        }

        if($email) {
            $status = $this->_otpLogger->validateOtp($customerid, $otp, $email);
            if ($status) {
                if($customerid){
                    $tokenForEmail = $this->getToken($customerid);
                }
                else{
                    $tokenForEmail=null;
                }
                $ar[] = ['message'=>'OTP Verified Successfully','token'=>$tokenForEmail,
                    'error'=> 0
                ];
                return $ar;
            }
            else{
                $ar[] =
                    [
                        'message'=> 'OTP is invalid or expired, please try again On Mobile Verify',
                        'token'=> null,
                        'error'=> 1
                    ];
                return $ar;
            }
        }

        $ar[] = ['message'=>'OTP Not  Verified Successfully'];
        return $ar;
    }

    public function getToken($id) {
        $token =$this->tokenFactory->create()->createCustomerToken($id)->getToken();
        return $token;
    }
}
