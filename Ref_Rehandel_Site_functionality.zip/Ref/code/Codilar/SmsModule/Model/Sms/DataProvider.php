<?php

namespace Codilar\SmsModule\Model\Sms;

use Codilar\SmsModule\Model\ResourceModel\SmsLog\CollectionFactory;

;

class DataProvider extends \Magento\Ui\DataProvider\AbstractDataProvider
{
    /**
     * @var array
     */
    protected $_loadedData;

    public function __construct(
        $name,
        $primaryFieldName,
        $requestFieldName,
        CollectionFactory $bannerCollectionFactory,
        array $meta = [],
        array $data = []
    )
    {
        $this->collection = $bannerCollectionFactory->create();
        parent::__construct($name, $primaryFieldName, $requestFieldName, $meta, $data);
    }

    public function getData()
    {
        if (isset($this->_loadedData)) {
            return $this->_loadedData;
        }
        $items = $this->collection->getItems();
        foreach ($items as $sms) {
            $data = $sms->getData();
            $this->_loadedData[$sms->getId()] = $data;
        }
        return $this->_loadedData;
    }
}