<?php
/**
 *
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */

namespace Codilar\SmsModule\Controller\Sms;

use Codilar\Customer\Helper\Data as CustomerHelper;
use Codilar\Customer\Model\OtpLogger;
use Magento\Customer\Model\AccountManagement;
use Magento\Customer\Model\CustomerFactory;
use Magento\Framework\App\Action\Context;
use Magento\Framework\Data\Form\FormKey\Validator;
use Magento\Framework\UrlInterface;

/**
 * Class ResendOtp
 * @package Codilar\Customer\Controller\Account
 */
class ResendOtp extends \Magento\Framework\App\Action\Action
{
    /**
     * @var Validator
     */
    protected $_formKeyValidator;
    /**
     * @var CustomerHelper
     */
    protected $_customerHelper;
    /**
     * @var OtpLogger
     */
    protected $_otpLogger;
    /**
     * @var UrlInterface
     */
    protected $url;
    /**
     * @var CustomerFactory
     */
    private $customerFactory;
    /**
     * @var AccountManagement
     */
    private $accountManagement;

    protected $_coreSession;

    /**
     * ResendOtp constructor.
     * @param Validator         $formKeyValidator
     * @param CustomerHelper    $customerHelper
     * @param OtpLogger         $otpLogger
     * @param UrlInterface      $url
     * @param CustomerFactory   $customerFactory
     * @param AccountManagement $accountManagement
     * @param Context           $context
     */
    public function __construct(
        Validator $formKeyValidator,
        CustomerHelper $customerHelper,
        OtpLogger $otpLogger,
        UrlInterface $url,
        CustomerFactory $customerFactory,
        AccountManagement $accountManagement,
        \Magento\Framework\Session\SessionManagerInterface $coreSession,
        \Magento\Framework\App\Action\Context $context)
    {
        $this->_formKeyValidator = $formKeyValidator;
        $this->_customerHelper = $customerHelper;
        $this->_otpLogger = $otpLogger;
        $this->url = $url;
        $this->customerFactory = $customerFactory;
        $this->accountManagement = $accountManagement;
        $this->_coreSession = $coreSession;
        return parent::__construct($context);
    }

    /**
     * @return \Magento\Framework\App\ResponseInterface|\Magento\Framework\Controller\ResultInterface|void
     */
    public function execute()
    {

        if (!$this->_formKeyValidator->validate($this->getRequest())) {
            $result['status'] = "0";
            $result['error'] = "Form key is not valid nor expired";
        }
        $resultRedirect = $this->resultRedirectFactory->create();
        
        if($this->getValue()==null){
            $this->setValue(0);
        }

        $inactive = 600; 

        $session_life = time() - $this->getTimeout();

        if($session_life > $inactive)
        {  
            $this->unSetTimeout();
            $this->unSetValue();

        }
        $this->setTimeout(time());

        if($this->getValue()==5){
            $result['status'] = "0";
            $result['error'] = "OTP allowed only 5 times";
       
            return $this->getResponse()->representJson(
                $this->_objectManager->get('Magento\Framework\Json\Helper\Data')
                    ->jsonEncode($result)
            );
        }
        else{
           $updated_value = $this->getValue()+1;
            $this->setValue($updated_value);
        }
        $country_code = $this->getRequest()->getParam("country_code");
        $mobileNumber = $this->getRequest()->getParam("mobile_number");
        $id = $this->getRequest()->getParam("id");
        $websiteId = $this->_customerHelper->getWebsiteId();
        //$mobileNumber = $country_code.$mobileNumber;
        $mobileNumber = $mobileNumber;
        try {
            $this->accountManagement->initiateOrderVerifyMobile(
                $mobileNumber,
                $id,
                AccountManagement::EMAIL_RESET,
                $websiteId
            );
            $result['status'] = "1";
        } catch (\Exception $e) {
            $result['status'] = "0";
            $result['error'] = $e->getMessage();
        }
        $this->getResponse()->representJson(
            $this->_objectManager->get('Magento\Framework\Json\Helper\Data')
                ->jsonEncode($result)
        );
    }

    /**
     * @param $mobileNumber
     * @return string
     */
    public function getEmailFromMobile($mobileNumber)
    {
        /** @var \Magento\Framework\Controller\Result\Redirect $resultRedirect */
        $resultRedirect = $this->resultRedirectFactory->create();
        $websiteId = $this->_customerHelper->getWebsiteId();
        if ($this->_customerHelper->getAccountSharingOptions()) {
            $email = $this->customerFactory->create()->getCollection()
                ->addFieldToFilter("website_id", $websiteId)
                ->addFieldToFilter('mobile_number', $mobileNumber)
                ->getFirstItem()
                ->getEmail();
        } else {
            $email = $this->customerFactory->create()->getCollection()
                ->addFieldToFilter('mobile_number', $mobileNumber)
                ->getFirstItem()
                ->getEmail();
        }

        if (!$email) {
            $this->messageManager->addErrorMessage(__('Your mobile number does not exist.'));
            return $resultRedirect->setPath('/');
        }
        return $email;
    }

    public function setValue($value){
        $this->_coreSession->start();
        $this->_coreSession->setCounterSuccess($value);
    }
    
    public function getValue(){
        $this->_coreSession->start();
        return $this->_coreSession->getCounterSuccess();
    }
    
    public function unSetValue(){
        $this->_coreSession->start();
        return $this->_coreSession->unsCounterSuccess();
    }

    public function setTimeout($value){
        $this->_coreSession->start();
        $this->_coreSession->setTimeout($value);
    }
    
    public function getTimeout(){
        $this->_coreSession->start();
        return $this->_coreSession->getTimeout();
    }
    
    public function unSetTimeout(){
        $this->_coreSession->start();
        return $this->_coreSession->unsTimeout();
    }
}
