<?php
/**
 *
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */

namespace Codilar\SmsModule\Controller\Sms;

use Codilar\Customer\Helper\Data as CustomerHelper;
use Codilar\Customer\Model\OtpLogger;
use Magento\Framework\App\Action\Context;
use Magento\Framework\Data\Form\FormKey\Validator;
use Magento\Framework\UrlInterface;
use Magento\Framework\DataObject;

/**
 * Class VerifyOtp
 * @package Codilar\Customer\Controller\Account
 */
class VerifyOtp extends \Magento\Framework\App\Action\Action
{
    /**
     * @var Validator
     */
    protected $_messageManager;

    protected $_checkoutSession;

    protected $_formKeyValidator;
    /**
     * @var CustomerHelper
     */
    protected $_customerHelper;
    /**
     * @var OtpLogger
     */
    protected $_otpLogger;
    /**
     * @var UrlInterface
     */
    protected $url;

    private $orderRepository;
    /**
     * @var StoreManagerInterface
     */
    private $storeManager;
    /**
     * @var ScopeConfigInterface
     */
    private $_scopeConfig;
    /**
     * @var emailTemplate
     */
    protected $emailTemplate;
    /**
     * @var _transportbuilder
     */
    private $_transportbuilder;
    /**
     * @var PaymentHelper
     */
    protected $paymentHelper;
    /**
     * @var Renderer
     */
    protected $addressRenderer;
    /**
     * @var LoggerInterface
     */
    protected $logger;
    /**
     * VerifyOtp constructor.
     * @param Validator      $formKeyValidator
     * @param CustomerHelper $customerHelper
     * @param OtpLogger      $otpLogger
     * @param UrlInterface   $url
     * @param Context        $context
     */
    public function __construct(
        Validator $formKeyValidator,
        CustomerHelper $customerHelper,
        OtpLogger $otpLogger,
        UrlInterface $url,
        \Magento\Framework\Message\ManagerInterface $messageManager,
        \Magento\Sales\Api\OrderRepositoryInterface $orderRepository ,
        \Magento\Checkout\Model\Session $checkoutSession,
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        \Magento\Framework\App\Config\ScopeConfigInterface $_scopeConfig,
        \Magento\Email\Model\BackendTemplate $emailTemplate,
        \Magento\Framework\Mail\Template\TransportBuilder $_transportbuilder,
        \Magento\Sales\Model\Order\Address\Renderer $addressRenderer,
        \Magento\Payment\Helper\Data $paymentHelper,
        \Psr\Log\LoggerInterface $logger,
        \Magento\Framework\App\Action\Context $context)
    {
        $this->_formKeyValidator = $formKeyValidator;
        $this->_customerHelper = $customerHelper;
        $this->_otpLogger = $otpLogger;
        $this->url = $url;
        $this->_messageManager = $messageManager;
        $this->_checkoutSession = $checkoutSession;
        $this->orderRepository = $orderRepository;
        $this->storeManager = $storeManager;
        $this->_scopeConfig = $_scopeConfig;
        $this->emailTemplate = $emailTemplate;
        $this->_transportbuilder = $_transportbuilder;
        $this->addressRenderer = $addressRenderer;
        $this->logger = $logger;
        $this->paymentHelper = $paymentHelper;
        
        return parent::__construct($context);
    }

    /**
     * @return \Magento\Framework\App\ResponseInterface|\Magento\Framework\Controller\ResultInterface|void
     */
    public function execute()
    {
        if (!$this->_formKeyValidator->validate($this->getRequest())) {
            $result['status'] = "0";
            $result['error'] = "Form key is not valid nor expired";
        }

        $order = $this->_checkoutSession->getLastRealOrder();
        $orderId=$order->getEntityId();
        $order->getIncrementId();

        $order_id = $this->getRequest()->getParam("order_id");
        if(isset($order_id)){
            $orderId = $order_id;
        }

        $mobileNumber = $this->getRequest()->getParam("mobile_number");
        $country_code = $this->getRequest()->getParam("country_code");
        $id = $this->getRequest()->getParam("id");
        $otp = $this->getRequest()->getParam("otp");
        $mobileNumber =  $mobileNumber;

        $status = $this->_otpLogger->validateOtp($id, $otp, $mobileNumber);
        if($status) {
            $order = $this->orderRepository->get($orderId);
            $order->setIsOrderVerify("Order Verified");
            $this->orderRepository->save($order);
            $otpData = $this->_otpLogger->getOtpData($id, $mobileNumber);
            $token = $otpData->getRpToken();
            $this->sendMail($orderId);
            $result['status'] = "1";
            $result['token'] = $token;
            $result['url'] = $this->url->getUrl("/");
            $this->_messageManager->addSuccessMessage('Order status verified succesfully.');
        } else {
            $result['status'] = "0";
            $result['error'] = 'OTP is invalid or expired, please try again';
        }
        $this->getResponse()->representJson(
            $this->_objectManager->get('Magento\Framework\Json\Helper\Data')
                ->jsonEncode($result)
        );
    }

    public function sendMail($orderId)
    {
        try {
            $order = $this->orderRepository->get($orderId);
            $email_template = $this->emailTemplate->load('Order Confirmation After Otp', 'template_code');
            $storeid = $this->storeManager->getStore()->getId();
            $templateId = $email_template->getId();
            $customer_email = $order->getCustomerEmail();

            $senderName = $this->_scopeConfig->getValue("trans_email/ident_general/name", \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
            $senderEmail = $this->_scopeConfig->getValue("trans_email/ident_general/email", \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
            $sender = [
                'name' => $senderName,
                'email' => $senderEmail,
            ];
            $vars = [
                'order' => $order,
                'billing' => $order->getBillingAddress(),
                'payment_html' => $this->getPaymentHtml($order,$storeid),
                'store' => $order->getStore(),
                'formattedShippingAddress' => $this->getFormattedShippingAddress($order),
                'formattedBillingAddress' => $this->getFormattedBillingAddress($order),
                'created_at_formatted' => $order->getCreatedAtFormatted(2),
                'order_data' => [
                    'customer_name' => $order->getCustomerName(),
                    'is_not_virtual' => $order->getIsNotVirtual(),
                    'email_customer_note' => $order->getEmailCustomerNote(),
                    'frontend_status_label' => $order->getFrontendStatusLabel()
                ]
            ];
            $to = new DataObject($vars);
            if ($templateId && $senderEmail) {
                $transport = $this->_transportbuilder
                    ->setTemplateIdentifier($templateId)
                    ->setTemplateOptions(['area' => \Magento\Framework\App\Area::AREA_FRONTEND, 'store' => $storeid])
                    ->setTemplateVars($to->getData())
                    ->setFrom($sender)
                    ->addTo($customer_email, "Rehandel")
                    ->getTransport();
                $transport->sendMessage();
            }
        }
        catch (\Exception $e){
            $this->logger->debug($e->getMessage());
        }
    }
    protected function getFormattedShippingAddress($order)
    {
        return $order->getIsVirtual()
            ? null
            : $this->addressRenderer->format($order->getShippingAddress(), 'html');
    }
    protected function getFormattedBillingAddress($order)
    {
        return $this->addressRenderer->format($order->getBillingAddress(), 'html');
    }
    protected function getPaymentHtml($order,$storeid)
    {
        return $this->paymentHelper->getInfoBlockHtml($order->getPayment(),$storeid);
    }
}
