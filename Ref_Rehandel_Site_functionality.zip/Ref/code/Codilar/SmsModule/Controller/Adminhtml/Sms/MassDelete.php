<?php

namespace Codilar\SmsModule\Controller\Adminhtml\Sms;

use Codilar\SmsModule\Model\ResourceModel\SmsLog\CollectionFactory;
use Codilar\SmsModule\Model\SmsLogFactory;
use Magento\Backend\App\Action\Context;
use Magento\Framework\App\ResponseInterface;
use Magento\Framework\Controller\ResultFactory;
use Magento\Ui\Component\MassAction\Filter;

/**
 * Class MassDelete
 * @package Codilar\SmsModule\Controller\Adminhtml\Sms
 */
class MassDelete extends \Magento\Backend\App\Action
{
    /**
     * @var \Magento\Framework\Filesystem
     */
    protected $_fileSystem;
    /**
     * @var \Magento\Framework\Filesystem\Driver\File
     */
    protected $_file;
    /**
     * Massactions filter
     *
     * @var Filter
     */
    protected $filter;

    /**
     * @var CollectionFactory
     */
    protected $collectionFactory;
    /**
     * @var SmsLogFactory
     */
    protected $_smsFactory;

    /**
     * MassDelete constructor.
     * @param Context                                   $context
     * @param \Magento\Framework\Filesystem             $filesystem
     * @param \Magento\Framework\Filesystem\Driver\File $file
     * @param Filter                                    $filter
     * @param CollectionFactory                         $collectionFactory
     * @param SmsLogFactory                             $smsFactory
     */
    public function __construct(
        Context $context,
        \Magento\Framework\Filesystem $filesystem,
        \Magento\Framework\Filesystem\Driver\File $file,
        Filter $filter,
        CollectionFactory $collectionFactory,
        SmsLogFactory $smsFactory
    )
    {
        $this->_fileSystem = $filesystem;
        $this->_file = $file;
        $this->filter = $filter;
        $this->collectionFactory = $collectionFactory;
        $this->_smsFactory = $smsFactory;
        parent::__construct($context);
    }

    /**
     * @return ResponseInterface|\Magento\Framework\Controller\ResultInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function execute()
    {
        $collection = $this->filter->getCollection($this->collectionFactory->create());
        $collectionSize = 0;
        foreach ($collection->getItems() as $sms) {
            $sms = $this->_smsFactory->create()->load($sms->getId());
            $sms->delete();
            $collectionSize++;
        }
        $this->messageManager->addSuccess(
            __('A total of %1 record(s) have been deleted.', $collectionSize)
        );
        return $this->resultFactory->create(ResultFactory::TYPE_REDIRECT)->setPath('codilar_sms/sms/index');
    }
}
