<?php

namespace Codilar\SmsModule\Setup;

use Magento\Framework\DB\Ddl\Table;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\SchemaSetupInterface;
use Magento\Framework\Setup\UpgradeSchemaInterface;

class UpgradeSchema implements UpgradeSchemaInterface
{
    public function upgrade(SchemaSetupInterface $setup, ModuleContextInterface $context)
    {
        $installer = $setup;

        $installer->startSetup();
        if (version_compare($context->getVersion(), '1.0.1', '<')) {
            // sms sent log
            $tableName = $installer->getTable('codilar_sms_sent_log');
            if ($installer->getConnection()->isTableExists($tableName) != true) {
                $table = $installer->getConnection()
                    ->newTable($tableName)
                    ->addColumn(
                        'id',
                        Table::TYPE_INTEGER,
                        null,
                        [
                            'identity' => true,
                            'unsigned' => true,
                            'nullable' => false,
                            'primary' => true
                        ],
                        'ID'
                    )
                    ->addColumn(
                        'order_id',
                        Table::TYPE_INTEGER,
                        null,
                        ['nullable' => true],
                        'Order Id'
                    )
                    ->addColumn(
                        'event_type',
                        Table::TYPE_TEXT,
                        20,
                        ['nullable' => false],
                        'Event Type'
                    )
                    ->addColumn(
                        'mobile_number',
                        Table::TYPE_TEXT,
                        20,
                        ['nullable' => false],
                        'Customer Mobile Number'
                    )
                    ->addColumn(
                        'email',
                        Table::TYPE_TEXT,
                        50,
                        ['nullable' => true],
                        'Customer Email'
                    )
                    ->addColumn(
                        'sms_text',
                        Table::TYPE_TEXT,
                        null,
                        ['nullable' => false],
                        'SMS Text'
                    )
                    ->addColumn(
                        'sms_status',
                        Table::TYPE_TEXT,
                        null,
                        ['nullable' => true],
                        'SMS Status'
                    )
                    ->addColumn(
                        'sms_error',
                        Table::TYPE_TEXT,
                        null,
                        ['nullable' => true],
                        'SMS Error'
                    )
                    ->addColumn(
                        'created_time',
                        Table::TYPE_TIMESTAMP,
                        null,
                        ['nullable' => false, 'default' => \Magento\Framework\DB\Ddl\Table::TIMESTAMP_INIT],
                        'Created Time'
                    )

                    ->addIndex(
                        $installer->getIdxName('codilar_sms_sent_log', ['id']),
                        ['id']
                    )
                    ->setComment('Codilar Sms Sent Logs Table');
                $installer->getConnection()->createTable($table);
            }
        }

        if (version_compare($context->getVersion(), '1.0.2', '<')) {
            $tableName = $setup->getTable('codilar_sms_sent_log');
            $installer->getConnection()->addColumn(
                $installer->getTable($tableName),
                'user_type',
                [
                    'type' => Table::TYPE_TEXT,
                    'comment' => 'User type',
                    'nullable' => false,
                    'default' =>"tracked",
                    'length' => 20
                ]
            );
        }
        if (version_compare($context->getVersion(), '1.0.3', '<')) {
            $tableName = $setup->getTable('codilar_sms_sent_log');
            $installer->getConnection()->addColumn(
                $installer->getTable($tableName),
                'email',
                [
                    'type' => Table::TYPE_TEXT,
                    'comment' => 'Email',
                    'nullable' => true,
                    'default' =>0,
                    'length' => 200
                ]
            );
        }

        $installer->endSetup();
    }
}
