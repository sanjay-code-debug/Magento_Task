<?php

namespace Codilar\SmsModule\Helper;

define('__ROOT__', dirname(dirname(__FILE__)));
require_once __ROOT__ . '/lib/Plivo/vendor/autoload.php';

use Codilar\SmsModule\Model\SmsLogger;
use Magento\Customer\Api\CustomerRepositoryInterface;
use Magento\Customer\Model\CustomerFactory;
use Magento\Framework\App\Helper\Context;
use Magento\Sales\Api\OrderRepositoryInterface;
use Magento\Store\Model\StoreManagerInterface;
use Plivo\RestAPI;
use Psr\Log\LoggerInterface;

/**
 * Class Data
 * @package Codilar\SmsModule\Helper
 */
class Data extends \Magento\Framework\App\Helper\AbstractHelper
{
    /**
     * @var $_scopeConfigInterface
     */
    protected $_scopeConfig;
    /**
     * @var LoggerInterface
     */
    protected $_logger;
    /**
     * @var StoreManagerInterface
     */
    protected $_storeManager;
    /**
     * @var SmsLogger
     */
    protected $_smsLogger;
    /**
     * @var CustomerRepositoryInterface
     */
    protected $customerRepository;
    /**
     * @var CustomerFactory
     */
    protected $_customerFactory;
    /**
     * @var OrderRepositoryInterface
     */
    private $orderRepository;

    /**
     * Data constructor.
     * @param StoreManagerInterface       $storeManager
     * @param Context                     $context
     * @param LoggerInterface             $loggerInterface
     * @param SmsLogger                   $smsLogger
     * @param CustomerRepositoryInterface $customerRepository
     * @param CustomerFactory             $customerFactory
     * @param OrderRepositoryInterface    $orderRepository
     */
    public function __construct(
        StoreManagerInterface $storeManager,
        Context $context,
        LoggerInterface $loggerInterface,
        SmsLogger $smsLogger,
        CustomerRepositoryInterface $customerRepository,
        CustomerFactory $customerFactory,
        OrderRepositoryInterface $orderRepository
    )
    {
        $this->_storeManager = $storeManager;
        $this->_scopeConfig = $context->getScopeConfig();
        $this->_logger = $loggerInterface;
        $this->_smsLogger = $smsLogger;
        $this->customerRepository = $customerRepository;
        $this->_customerFactory = $customerFactory;
        parent::__construct($context);
        $this->orderRepository = $orderRepository;
    }

    /**
     * This function will return module status 0/1
     * @param null
     * @return boolean
     */
    public function getPlivoModuleStatus()
    {
        return $this->_scopeConfig->getValue('smsmodule/plivo/plivo_status', \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
    }

    /**
     * This function will return module status 0/1
     * @param null
     * @return boolean
     */
    public function isMobilenumberFilterable()
    {
        return $this->_scopeConfig->getValue('smsmodule/plivo/filter_status', \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
    }

    /**
     * This function will return Log clearing days
     * @param null
     * @return int
     */
    public function getLogClearingDays()
    {
        return $this->_scopeConfig->getValue('smsmodule/sms_log_clear/log_days', \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
    }

    public function getStoreId()
    {
        try {
            return $this->_storeManager->getStore()->getId();
        } catch (\Exception $e) {
            return false;
        }
    }

    public function sendAccountConfirmationMessageToCustomer($mobileNumber,$countryCode,$eventType,$websiteId){
        $template = $this->getAccountConfirmationMessageTemplate();
        $message = $template;
        $eventType = "Business Account Confirmation";
        $orderId = null;
        $this->sendMessageToMobileNumber($mobileNumber, $message, $eventType, $orderId, $countryCode);
    }

    /**
     * @param      $mobileNumber
     * @param      $messagePlace
     * @param bool $otp
     * @param bool $orderId
     * @param bool $items
     */
    public function sendMessage($mobileNumber, $messagePlace, $otp = false, $orderId = false, $items = false, $country_code = false)
    {
        $message = "";
        $eventType = "";
        $moduleStatus = $this->getModuleStatus();
        if ($moduleStatus == "1") {
            $storeCode = $this->getStoreCode();
            $countryCode = $this->getCountryCodeFromMobile($mobileNumber,$orderId);
            if ($messagePlace == "forgot" && $this->sendOtpOnForgotPassword() && $otp) {
                $template = $this->getOtpTemplate();
                $message = str_replace("{{otp}}", $otp, $template);
                $eventType = "OTP";
                $orderId = null;
            }
            elseif ($messagePlace == "order_verify" && $this->sendOtpOnOrderVerify() && $otp) { 
                $template = $this->getOrderVerifyTemplate();
                $message = str_replace("{{otp}}", $otp, $template);
                $eventType = "OTP";
                $orderId = null;
             }
            elseif ($messagePlace == "register" &&  $otp) {
                $template = $this->getRegisterTemplate();
                $message = str_replace("{{otp}}", $otp, $template);
                $eventType = "OTP";
                $orderId = null;
             }
            elseif ($messagePlace == "order_place" && $this->sendOtpOnOrderPlace() && $orderId) {
                //$store = $this->getOrderStore($orderId);
                //$countryCode = $this->getCountryCodeFromStoreView($store);
                $template = $this->getOrderPlacedTemplate();
                $message = str_replace("{{items_list}}", $items, $template);
                $eventType = "Order Place";
            } elseif ($messagePlace == "order_confirmation" && $this->sendOtpOnOrderConfirmation()) {
                //$store = $this->getOrderStore($orderId);
                //$countryCode = $this->getCountryCodeFromStoreView($store);
                $template = $this->getOrderConfirmationTemplate();
                $message = str_replace("{{items_list}}", $items, $template);
                $eventType = "Order Confirmation";
            } elseif ($messagePlace == "order_cancel" && $this->sendOtpOnOrderCancel()) {
                //$store = $this->getOrderStore($orderId);
                //$countryCode = $this->getCountryCodeFromStoreView($store);
                $template = $this->getOrderCancellationTemplate();
                $message = str_replace("{{items_list}}", $items, $template);
                $eventType = "Order Cancellation";
            } elseif ($messagePlace == "order_dispatched" && $this->sendOtpOnOrderDispatch()) {
                //$store = $this->getOrderStore($orderId);
                //$countryCode = $this->getCountryCodeFromStoreView($store);
                $template = $this->getOrderDispatchedTemplate();
                $message = str_replace("{{items_list}}", $items, $template);
                $eventType = "Order Dispatched";
            } elseif ($messagePlace == "order_delivered" && $this->sendOtpOnOrderDelivery()) {
                //$store = $this->getOrderStore($orderId);
                //$countryCode = $this->getCountryCodeFromStoreView($store);
                $template = $this->getOrderDeliveredTemplate();
                $message = str_replace("{{items_list}}", $items, $template);
                $eventType = "Order Delivered";
            } elseif ($messagePlace == "order_closed" && $this->sendOtpOnOrderClosed()) {
                //$store = $this->getOrderStore($orderId);
                //$countryCode = $this->getCountryCodeFromStoreView($store);
                $template = $this->getOrderClosedTemplate();
                $message = str_replace("{{items_list}}", $items, $template);
                $eventType = "Order Closed";
            }
            if (strlen($message) > 1) {
                $this->sendMessageToMobileNumber($mobileNumber, $message, $eventType, $orderId, $countryCode,$messagePlace,$country_code);
            }
        }
    }

    /**
     * This function will return module status 0/1
     * @param null
     * @return boolean
     */
    public function getModuleStatus()
    {
        return $this->_scopeConfig->getValue('smsmodule/sms_global/module_status', \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
    }

    public function getStoreCode()
    {
        try {
            return $this->_storeManager->getStore()->getCode();
        } catch (\Exception $e) {
            return "australia";
        }
    }

    public function getCountryCodeFromMobile($mobileNumber,$orderId = false)
    {
        $websiteId = $this->getWebsiteId();
        if ($this->getAccountSharingOptions()) {
            if($orderId){
                $customerId = $this->getCustomerId($orderId);
            }
            else{
                $customerId = $this->_customerFactory->create()->getCollection()
                    ->addFieldToFilter("website_id", $websiteId)
                    ->addFieldToFilter('mobile_number', $mobileNumber)
                    ->getFirstItem()
                    ->getEntityId();
            }
        } else {
            if($orderId){
                $customerId = $this->getCustomerId($orderId);
            }
            else{
                $customerId = $this->_customerFactory->create()->getCollection()
                    ->addFieldToFilter('mobile_number', $mobileNumber)
                    ->getFirstItem()
                    ->getEntityId();
            }
        }
        if ($customerId) {
            $customer = $this->customerRepository->getById($customerId);
            $countryCode = $customer->getCustomAttribute("country_code");
            if ($countryCode) {
                $countryCode = $customer->getCustomAttribute("country_code")->getValue();
                if(!$countryCode){
                    if($orderId){
                        $store = $this->getOrderStore($orderId);
                        $countryCode = $this->getCountryCodeFromStoreView($store);
                    }
                }
                return $countryCode;
            }
            return "61";
        }
        return false;
    }

    public function getWebsiteId()
    {
        try {
            return $this->_storeManager->getWebsite()->getId();
        } catch (\Exception $e) {
            return false;
        }
    }

    public function getAccountSharingOptions()
    {
        return $this->_scopeConfig->getValue('customer/account_share/scope', \Magento\Store\Model\ScopeInterface::SCOPE_WEBSITE);
    }

    /**
     * This function will return Country Code
     * @param null
     * @return string
     */
    public function getCountryCode()
    {
        return $this->_scopeConfig->getValue('smsmodule/sms_global/country_code', \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
    }

    /**
     * This function will return Send Otp on Forgotpassword
     * @param null
     * @return string
     */
    public function sendOtpOnForgotPassword()
    {
        return $this->_scopeConfig->getValue('smsmodule/sms/send_otp_forgot', \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
    }

    public function sendOtpOnOrderVerify()
    {
        return $this->_scopeConfig->getValue('smsmodule/sms/send_otp_order_verify',\Magento\Store\Model\ScopeInterface::SCOPE_STORE);
    }
    /**
     * This function will return Template
     * @param null
     * @return string
     */
    public function getOtpTemplate()
    {
        return $this->_scopeConfig->getValue('smsmodule/sms/otp_template', \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
    }

    public function getOrderVerifyTemplate()
    {
        return $this->_scopeConfig->getValue('smsmodule/sms/order_verify_template', \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
    }

    /**
     * This function will return Send Otp on Order Place
     * @param null
     * @return string
     */
    public function sendOtpOnOrderPlace()
    {
        return $this->_scopeConfig->getValue('smsmodule/sms/sms_order_placed', \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
    }

    public function getOrderStore($orderId)
    {
        $order = $this->orderRepository->get($orderId);
        $storeCode = $this->_storeManager->getStore($order->getStoreId());
        return $storeCode;
    }

    public function getCustomerId($orderId)
    {
        $order = $this->orderRepository->get($orderId);
        return $order->getCustomerId();
    }

    public function getCountryCodeFromStoreView($store)
    {
        return $this->_scopeConfig->getValue('smsmodule/sms_global/country_code', \Magento\Store\Model\ScopeInterface::SCOPE_STORE, $store);
    }

    /**
     * This function will return Template
     * @param null
     * @return string
     */
    public function getOrderPlacedTemplate()
    {
        return $this->_scopeConfig->getValue('smsmodule/sms/order_place_template', \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
    }
    /**
     * This function will return Template
     * @param null
     * @return string
     */
    public function getRegisterTemplate()
    {
        return $this->_scopeConfig->getValue('smsmodule/sms/register_template', \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
    }

    /**
     * This function will return Send Otp on Order Confirmation
     * @param null
     * @return string
     */
    public function sendOtpOnOrderConfirmation()
    {
        return $this->_scopeConfig->getValue('smsmodule/sms/sms_order_confirmation', \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
    }

    /**
     * This function will return Template
     * @param null
     * @return string
     */
    public function getOrderConfirmationTemplate()
    {
        return $this->_scopeConfig->getValue('smsmodule/sms/order_confirmation_template', \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
    }

    /**
     * This function will return Send Otp on Order Cancellation
     * @param null
     * @return string
     */
    public function sendOtpOnOrderCancel()
    {
        return $this->_scopeConfig->getValue('smsmodule/sms/sms_order_cancel', \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
    }

    /**
     * This function will return Template
     * @param null
     * @return string
     */
    public function getOrderCancellationTemplate()
    {
        return $this->_scopeConfig->getValue('smsmodule/sms/order_cancel_template', \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
    }

    /**
     * This function will return Send Otp on Order Dispatch
     * @param null
     * @return string
     */
    public function sendOtpOnOrderDispatch()
    {
        return $this->_scopeConfig->getValue('smsmodule/sms/sms_order_dispatched', \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
    }

    /**
     * This function will return Template
     * @param null
     * @return string
     */
    public function getOrderDispatchedTemplate()
    {
        return $this->_scopeConfig->getValue('smsmodule/sms/order_dispatched_template', \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
    }

    /**
     * This function will return Send Otp on Order Delivery
     * @param null
     * @return string
     */
    public function sendOtpOnOrderDelivery()
    {
        return $this->_scopeConfig->getValue('smsmodule/sms/sms_order_delivered', \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
    }

    /**
     * This function will return Template
     * @param null
     * @return string
     */
    public function getOrderDeliveredTemplate()
    {
        return $this->_scopeConfig->getValue('smsmodule/sms/order_delivered_template', \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
    }

    /**
     * This function will return Send Otp on Order Closed
     * @param null
     * @return string
     */
    public function sendOtpOnOrderClosed()
    {
        return $this->_scopeConfig->getValue('smsmodule/sms/sms_order_closed', \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
    }

    /**
     * This function will return Template
     * @param null
     * @return string
     */
    public function getOrderClosedTemplate()
    {
        return $this->_scopeConfig->getValue('smsmodule/sms/order_closed_template', \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
    }

    /**
     * This function will return Account Confirmation Message
     * @param null
     * @return string
     */
    public function sendAccountConfirmationMessage()
    {
        return $this->_scopeConfig->getValue('smsmodule/sms/account_confirmation', \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
    }

    /**
     * This function will return Template
     * @param null
     * @return string
     */
    public function getAccountConfirmationMessageTemplate()
    {
        return $this->_scopeConfig->getValue('smsmodule/sms/account_confirmation_template', \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
    }

    /**
     * This function will return Excluded Countries
     * @param null
     * @return string
     */
    public function getExcludedCountries()
    {
        return $this->_scopeConfig->getValue('smsmodule/sms/exclude_countries_list', \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
    }

    public function sendMessageToMobileNumber($mobileNumber, $message, $eventType, $orderId, $countryCode,$messagePlace = false,$iso_code)
    {
        if($this->isMobilenumberFilterable()){
            $mobileNumber = $this->getMobileNumberByCountryCode($mobileNumber,$countryCode);
        }
        $mobile = str_replace($iso_code,"",$mobileNumber);
        $senderId = $this->getPlivoSmsSenderId();
        $authId = $this->getPlivoAuthId();
        $authToken = $this->getPlivoAuthToken();
        $p = new RestAPI("$authId", $authToken);

        $customerId=null;
        $websiteId = $this->getWebsiteId();
        if ($this->getAccountSharingOptions()) {
            if($orderId){
                $customerId = $this->getCustomerId($orderId);
            }
            else{
                $customerId = $this->_customerFactory->create()->getCollection()
                    ->addFieldToFilter("website_id", $websiteId)
                    ->addFieldToFilter('mobile_number', $mobile)
                    ->getFirstItem()
                    ->getEntityId();
            }
        } else {
            if($orderId){
                $customerId = $this->getCustomerId($orderId);
            }
            else{
                $customerId = $this->_customerFactory->create()->getCollection()
                    ->addFieldToFilter('mobile_number', $mobile)
                    ->getFirstItem()
                    ->getEntityId();
            }
        }
        
        $number_series = $this->_scopeConfig->getValue('smsmodule/sms/number_series_restriction', \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
        if($number_series!=""){
            $number_series_list = explode(",",$number_series);
            foreach($number_series_list as $number_list){
                if (strpos("+".$mobileNumber, $number_list)!== false) { 
                    return false;
                }
            }
        }
        if($customerId==null){
            $user_type="untracked";
        }
        else{
            $user_type="tracked";
        }
        // Set message parameters
        $params = array(
            'src' => $senderId, // Sender's phone number with country code
            'dst' => $countryCode . $mobileNumber, // Receiver's phone number with country code
            'text' => $message, // Your SMS text message
            // To send Unicode text
            'method' => 'POST' // The method used to call the url
        );
        try {
            // Send message
            if($this->getPlivoModuleStatus()){
                $response = $p->send_message($params);
                if($response['status']==400){
                    $this->_smsLogger->saveMessage($countryCode . $mobileNumber, $message, $eventType, $response['status'], $response['response']['error'], false, $orderId,$user_type);
                }
                else{
                    if ($this->getIsSmsLogged() == "1") {
                        if ($messagePlace == "register") {
                            $this->_smsLogger->saveMessage($countryCode . $mobileNumber, $message, $eventType, $response['status'], $response['response']['message'], false, $orderId,$user_type);
                        }
                        else{
                            $this->_smsLogger->saveMessage($countryCode . $mobileNumber, $message, $eventType, $response['status'], $response['response']['message'], false, $orderId);
                        }
                    }
                }
            }
            else{
                if ($this->getIsSmsLogged() == "1") {
                    if ($messagePlace == "register") {                    
                        $this->_smsLogger->saveMessage($countryCode . $mobileNumber, $message, $eventType, "Status", "Message", false, $orderId,$user_type);
                     }
                     else{
                        $this->_smsLogger->saveMessage($countryCode . $mobileNumber, $message, $eventType, "Status", "Message", false, $orderId);
                     }
                }
            }
            return true;
        } catch (\Exception $e) {
            $this->_logger->critical($e->getMessage());
            return false;
        }
    }

    public function saveMessageEmail($email,$otp)
    {
        $customerId=null;
        $websiteId = $this->getWebsiteId();
        if ($this->getAccountSharingOptions()) {
                $customerId = $this->_customerFactory->create()->getCollection()
                    ->addFieldToFilter("website_id", $websiteId)
                    ->addFieldToFilter('email', $email)
                    ->getFirstItem()
                    ->getEntityId();
        } else {
                $customerId = $this->_customerFactory->create()->getCollection()
                    ->addFieldToFilter('email', $email)
                    ->getFirstItem()
                    ->getEntityId();
        }

        if($customerId==null){
            $user_type="untracked";
        }
        else{
            $user_type="tracked";
        }

        $template = $this->getRegisterTemplate();
        $message = str_replace("{{otp}}", $otp, $template);
        $eventType = "OTP";
        $orderId = null;

        $this->_smsLogger->saveMessage($email, $message, $eventType, 202, "message(s) queued", false, $orderId,$user_type);
    }


    public function getMobileNumberByCountryCode($mobileNumber,$countryCode){
        if ($countryCode == "91" && strlen($mobileNumber) > 10) {
            //india
            $mobileNumber = substr($mobileNumber, -10);
        } elseif ($countryCode == "61" && strlen($mobileNumber) > 9) {
            //australia
            $mobileNumber = substr($mobileNumber, -9);
        } elseif ($countryCode == "65" && strlen($mobileNumber) > 8) {
            //singapore
            $mobileNumber = substr($mobileNumber, -8);
        }
        elseif ($countryCode == "1" && strlen($mobileNumber) > 10) {
            //us country code
            $mobileNumber = substr($mobileNumber, -10);
        }
        elseif ($countryCode == "30" && strlen($mobileNumber) > 10) {
            //greece
            $mobileNumber = substr($mobileNumber, -10);
        }
        elseif ($countryCode == "31" && strlen($mobileNumber) > 9) {
            //netherlands
            $mobileNumber = substr($mobileNumber, -9);
        }
        elseif ($countryCode == "32" && strlen($mobileNumber) > 9) {
            //belgium
            $mobileNumber = substr($mobileNumber, -9);
        }
        elseif ($countryCode == "33" && strlen($mobileNumber) > 9) {
            //france
            $mobileNumber = substr($mobileNumber, -9);
        }
        elseif ($countryCode == "34" && strlen($mobileNumber) > 9) {
            //spain
            $mobileNumber = substr($mobileNumber, -9);
        }
        elseif ($countryCode == "36" && strlen($mobileNumber) > 9) {
            //hungary
            $mobileNumber = substr($mobileNumber, -9);
        }
        elseif ($countryCode == "39" && strlen($mobileNumber) > 13) {
            //italy
            $mobileNumber = substr($mobileNumber, -13);
        }
        elseif ($countryCode == "43" && strlen($mobileNumber) > 11) {
            //Austria
            $mobileNumber = substr($mobileNumber, -11);
        }
        elseif ($countryCode == "44" && strlen($mobileNumber) > 10) {
            //uk
            $mobileNumber = substr($mobileNumber, -10);
        }
        elseif ($countryCode == "45" && strlen($mobileNumber) > 8) {
            //denmark
            $mobileNumber = substr($mobileNumber, -8);
        }
        elseif ($countryCode == "46" && strlen($mobileNumber) > 7) {
            //sweden
            $mobileNumber = substr($mobileNumber, -7);
        }
        elseif ($countryCode == "48" && strlen($mobileNumber) > 9) {
            //poland
            $mobileNumber = substr($mobileNumber, -9);
        }
        elseif ($countryCode == "49" && strlen($mobileNumber) > 11) {
            //germany
            $mobileNumber = substr($mobileNumber, -11);
        }
        elseif ($countryCode == "351" && strlen($mobileNumber) > 9) {
            //portugal
            $mobileNumber = substr($mobileNumber, -9);
        }
        elseif ($countryCode == "352" && strlen($mobileNumber) > 9) {
            //Luxembourg
            $mobileNumber = substr($mobileNumber, -9);
        }
        elseif ($countryCode == "353" && strlen($mobileNumber) > 9) {
            //ireland
            $mobileNumber = substr($mobileNumber, -9);
        }
        /*elseif ($countryCode == "356" && strlen($mobileNumber) > 8) {
            //malta
            $mobileNumber = substr($mobileNumber, -8);
        }*/
        elseif ($countryCode == "357" && strlen($mobileNumber) > 6) {
            //Cyprus
            $mobileNumber = substr($mobileNumber, -6);
        }
        elseif ($countryCode == "358" && strlen($mobileNumber) > 10) {
            //finland
            $mobileNumber = substr($mobileNumber, -10);
        }
        elseif ($countryCode == "359" && strlen($mobileNumber) > 9) {
            //bulgaria
            $mobileNumber = substr($mobileNumber, -9);
        }
        elseif ($countryCode == "370" && strlen($mobileNumber) > 8) {
            //lithuania
            $mobileNumber = substr($mobileNumber, -8);
        }
        elseif ($countryCode == "371" && strlen($mobileNumber) > 8) {
            //latvia
            $mobileNumber = substr($mobileNumber, -8);
        }
        elseif ($countryCode == "385" && strlen($mobileNumber) > 9) {
            //croatia
            $mobileNumber = substr($mobileNumber, -9);
        }
        elseif ($countryCode == "420" && strlen($mobileNumber) > 9) {
            //czech republic
            $mobileNumber = substr($mobileNumber, -9);
        }
        elseif ($countryCode == "421" && strlen($mobileNumber) > 9) {
            //slovakia
            $mobileNumber = substr($mobileNumber, -9);
        }
        elseif ($countryCode == "852" && strlen($mobileNumber) > 8) {
            //hong kong
            $mobileNumber = substr($mobileNumber, -8);
        }
//        elseif ($countryCode == "971" && strlen($mobileNumber) > 8) {
//            //uae
//            $mobileNumber = substr($mobileNumber, -8);
//        }
        return $mobileNumber;
    }

    /**
     * This function will return Sender Id
     * @param null
     * @return string
     */
    public function getPlivoSmsSenderId()
    {
        return $this->_scopeConfig->getValue('smsmodule/plivo/sender', \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
    }

    /**
     * This function will return API
     * @param null
     * @return string
     */
    public function getPlivoAuthId()
    {
        return $this->_scopeConfig->getValue('smsmodule/plivo/auth_id', \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
    }

    /**
     * This function will return API Key
     * @param null
     * @return string
     */
    public function getPlivoAuthToken()
    {
        return $this->_scopeConfig->getValue('smsmodule/plivo/auth_token', \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
    }

    /**
     * This function will return Sms Is logged or not
     * @param null
     * @return string
     */
    public function getIsSmsLogged()
    {
        return $this->_scopeConfig->getValue('smsmodule/sms/save_sms', \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
    }

    public function sendMessageToIndiaNumber($mobileNumber, $message, $eventType, $orderId)
    {
        $messageEncoded = urlencode($message);
        $senderId = $this->getSmsSenderId();
        $countryCode = $this->getCountryCode();
        // $api
        $api = $this->getApi();
        $apiKey = $this->getApiKey();
        try {
            $urlkey = "$api?api_key=$apiKey&method=sms&message=$messageEncoded&to=$countryCode$mobileNumber&sender=$senderId";
            $url = curl_init($urlkey);
            curl_setopt($url, CURLOPT_POST, true);
            //curl_setopt($url, CURLOPT_POSTFIELDS, $data);
            curl_setopt($url, CURLOPT_RETURNTRANSFER, true);
            $result = curl_exec($url); // This is the result from the API
            $responseData = json_decode($result);
            if ($this->getIsSmsLogged() == "1") {
                $this->_smsLogger->saveMessage($mobileNumber, $message, $eventType, $responseData->status, $responseData->message, false, $orderId);
            }
            curl_close($url);
            return true;
        } catch (\Exception $e) {
            // If we are not able to send a reset password otp, this should be ignored
            $this->_logger->critical($e->getMessage());
            return false;
        }
    }

    /**
     * This function will return Sender Id
     * @param null
     * @return string
     */
    public function getSmsSenderId()
    {
        return $this->_scopeConfig->getValue('smsmodule/sms_global/sender', \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
    }

    /**
     * This function will return API
     * @param null
     * @return string
     */
    public function getApi()
    {
        return $this->_scopeConfig->getValue('smsmodule/sms_global/api', \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
    }

    /**
     * This function will return API Key
     * @param null
     * @return string
     */
    public function getApiKey()
    {
        return $this->_scopeConfig->getValue('smsmodule/sms_global/api_key', \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
    }

    public function sendMessageToAusNumber($mobileNumber, $message, $eventType, $orderId)
    {
        $messageEncoded = urlencode($message);
        $senderId = $this->getPlivoSmsSenderId();
        $countryCode = $this->getPlivoCountryCode();
        $authId = $this->getPlivoAuthId();
        $authToken = $this->getPlivoAuthToken();
        $p = new RestAPI("$authId", $authToken);
        // Set message parameters
        $params = array(
            'src' => $senderId, // Sender's phone number with country code
            'dst' => "61" . $mobileNumber, // Receiver's phone number with country code
            'text' => $message, // Your SMS text message
            // To send Unicode text
            'method' => 'POST' // The method used to call the url
        );
        try {
            // Send message
            $response = $p->send_message($params);
            if ($this->getIsSmsLogged() == "1") {
                $this->_smsLogger->saveMessage($mobileNumber, $message, $eventType, $response['status'], $response['response']['message'], false, $orderId);
            }
            return true;
        } catch (\Exception $e) {
            $this->_logger->critical($e->getMessage());
            return false;
        }
    }

    /**
     * This function will return Country Code
     * @param null
     * @return string
     */
    public function getPlivoCountryCode()
    {
        return $this->_scopeConfig->getValue('smsmodule/plivo/country_code', \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
    }

    public function saveLog($text){
        $this->_logger->debug($text);
    }

    public function getphonecode($code)
    {
        $countrycode = array(
            'AD'=>'376',
            'AE'=>'971',
            'AF'=>'93',
            'AG'=>'1268',
            'AI'=>'1264',
            'AL'=>'355',
            'AM'=>'374',
            'AN'=>'599',
            'AO'=>'244',
            'AQ'=>'672',
            'AR'=>'54',
            'AS'=>'1684',
            'AT'=>'43',
            'AU'=>'61',
            'AW'=>'297',
            'AZ'=>'994',
            'BA'=>'387',
            'BB'=>'1246',
            'BD'=>'880',
            'BE'=>'32',
            'BF'=>'226',
            'BG'=>'359',
            'BH'=>'973',
            'BI'=>'257',
            'BJ'=>'229',
            'BL'=>'590',
            'BM'=>'1441',
            'BN'=>'673',
            'BO'=>'591',
            'BR'=>'55',
            'BS'=>'1242',
            'BT'=>'975',
            'BW'=>'267',
            'BY'=>'375',
            'BZ'=>'501',
            'CA'=>'1',
            'CC'=>'61',
            'CD'=>'243',
            'CF'=>'236',
            'CG'=>'242',
            'CH'=>'41',
            'CI'=>'225',
            'CK'=>'682',
            'CL'=>'56',
            'CM'=>'237',
            'CN'=>'86',
            'CO'=>'57',
            'CR'=>'506',
            'CU'=>'53',
            'CV'=>'238',
            'CX'=>'61',
            'CY'=>'357',
            'CZ'=>'420',
            'DE'=>'49',
            'DJ'=>'253',
            'DK'=>'45',
            'DM'=>'1767',
            'DO'=>'1809',
            'DZ'=>'213',
            'EC'=>'593',
            'EE'=>'372',
            'EG'=>'20',
            'ER'=>'291',
            'ES'=>'34',
            'ET'=>'251',
            'FI'=>'358',
            'FJ'=>'679',
            'FK'=>'500',
            'FM'=>'691',
            'FO'=>'298',
            'FR'=>'33',
            'GA'=>'241',
            'GB'=>'44',
            'GD'=>'1473',
            'GE'=>'995',
            'GH'=>'233',
            'GI'=>'350',
            'GL'=>'299',
            'GM'=>'220',
            'GN'=>'224',
            'GQ'=>'240',
            'GR'=>'30',
            'GT'=>'502',
            'GU'=>'1671',
            'GW'=>'245',
            'GY'=>'592',
            'HK'=>'852',
            'HN'=>'504',
            'HR'=>'385',
            'HT'=>'509',
            'HU'=>'36',
            'ID'=>'62',
            'IE'=>'353',
            'IL'=>'972',
            'IM'=>'44',
            'IN'=>'91',
            'IQ'=>'964',
            'IR'=>'98',
            'IS'=>'354',
            'IT'=>'39',
            'JM'=>'1876',
            'JO'=>'962',
            'JP'=>'81',
            'KE'=>'254',
            'KG'=>'996',
            'KH'=>'855',
            'KI'=>'686',
            'KM'=>'269',
            'KN'=>'1869',
            'KP'=>'850',
            'KR'=>'82',
            'KW'=>'965',
            'KY'=>'1345',
            'KZ'=>'7',
            'LA'=>'856',
            'LB'=>'961',
            'LC'=>'1758',
            'LI'=>'423',
            'LK'=>'94',
            'LR'=>'231',
            'LS'=>'266',
            'LT'=>'370',
            'LU'=>'352',
            'LV'=>'371',
            'LY'=>'218',
            'MA'=>'212',
            'MC'=>'377',
            'MD'=>'373',
            'ME'=>'382',
            'MF'=>'1599',
            'MG'=>'261',
            'MH'=>'692',
            'MK'=>'389',
            'ML'=>'223',
            'MM'=>'95',
            'MN'=>'976',
            'MO'=>'853',
            'MP'=>'1670',
            'MR'=>'222',
            'MS'=>'1664',
            'MT'=>'356',
            'MU'=>'230',
            'MV'=>'960',
            'MW'=>'265',
            'MX'=>'52',
            'MY'=>'60',
            'MZ'=>'258',
            'NA'=>'264',
            'NC'=>'687',
            'NE'=>'227',
            'NG'=>'234',
            'NI'=>'505',
            'NL'=>'31',
            'NO'=>'47',
            'NP'=>'977',
            'NR'=>'674',
            'NU'=>'683',
            'NZ'=>'64',
            'OM'=>'968',
            'PA'=>'507',
            'PE'=>'51',
            'PF'=>'689',
            'PG'=>'675',
            'PH'=>'63',
            'PK'=>'92',
            'PL'=>'48',
            'PM'=>'508',
            'PN'=>'870',
            'PR'=>'1',
            'PT'=>'351',
            'PW'=>'680',
            'PY'=>'595',
            'QA'=>'974',
            'RO'=>'40',
            'RS'=>'381',
            'RU'=>'7',
            'RW'=>'250',
            'SA'=>'966',
            'SB'=>'677',
            'SC'=>'248',
            'SD'=>'249',
            'SE'=>'46',
            'SG'=>'65',
            'SH'=>'290',
            'SI'=>'386',
            'SK'=>'421',
            'SL'=>'232',
            'SM'=>'378',
            'SN'=>'221',
            'SO'=>'252',
            'SR'=>'597',
            'ST'=>'239',
            'SV'=>'503',
            'SY'=>'963',
            'SZ'=>'268',
            'TC'=>'1649',
            'TD'=>'235',
            'TG'=>'228',
            'TH'=>'66',
            'TJ'=>'992',
            'TK'=>'690',
            'TL'=>'670',
            'TM'=>'993',
            'TN'=>'216',
            'TO'=>'676',
            'TR'=>'90',
            'TT'=>'1868',
            'TV'=>'688',
            'TW'=>'886',
            'TZ'=>'255',
            'UA'=>'380',
            'UG'=>'256',
            'US'=>'1',
            'UY'=>'598',
            'UZ'=>'998',
            'VA'=>'39',
            'VC'=>'1784',
            'VE'=>'58',
            'VG'=>'1284',
            'VI'=>'1340',
            'VN'=>'84',
            'VU'=>'678',
            'WF'=>'681',
            'WS'=>'685',
            'XK'=>'381',
            'YE'=>'967',
            'YT'=>'262',
            'ZA'=>'27',
            'ZM'=>'260',
            'ZW'=>'263'
        );

        $key = array_search($code,$countrycode);
        return $key;
    }
}
