<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Codilar\LoginCustomer\Model\Resolver;

use Magento\Framework\Exception\AuthenticationException;
use Magento\Framework\GraphQl\Config\Element\Field;
use Magento\Framework\GraphQl\Exception\GraphQlAuthenticationException;
use Magento\Framework\GraphQl\Exception\GraphQlInputException;
use Magento\Framework\GraphQl\Query\ResolverInterface;
use Magento\Framework\GraphQl\Schema\Type\ResolveInfo;
use Magento\Integration\Api\CustomerTokenServiceInterface;

use Magento\Customer\Model\CustomerFactory;
use Magento\Integration\Model\Oauth\TokenFactory as TokenModelFactory;
use Magento\Framework\GraphQl\Exception\GraphQlAlreadyExistsException;
/**
 * Customers Token resolver, used for GraphQL request processing.
 */
class GenerateCustomerToken implements ResolverInterface
{
    /**
     * @var CustomerTokenServiceInterface
     */
    private $customerTokenService;
    /**
     * @var CustomerFactory
     */
    private $customerFactory;
    /**
     * @var TokenModelFactory
     */
    private $tokenFactory;

    /**
     * @param CustomerTokenServiceInterface $customerTokenService
     */
    public function __construct(
        CustomerTokenServiceInterface $customerTokenService,
        CustomerFactory $customerFactory,
        TokenModelFactory $tokenFactory
    ) {
        $this->customerTokenService = $customerTokenService;
        $this->customerFactory = $customerFactory;
        $this->tokenFactory = $tokenFactory;
    }

    /**
     * @inheritdoc
     */
    public function resolve(Field $field, $context, ResolveInfo $info, array $value = null, array $args = null) {

        if (empty($args['password'])) {
            throw new GraphQlInputException(__('Specify the "password" value.'));
        }
         $email = $args['email'];

        if(!empty($email)) {
            try {
                $token = $this->customerTokenService->createCustomerAccessToken($args['email'], $args['password']);
                return ['token' => $token];
            } catch (AuthenticationException $e) {
                throw new GraphQlAuthenticationException(__($e->getMessage()), $e);
            }
        }

        $country_code = $args['country_code'];
        $mobile = $args['mobile_number'];

        $mobile_number = str_replace($country_code, "", $mobile);


        $dbEmail = $this->customerFactory->create()->getCollection()
            ->addFieldToFilter('mobile_number', $mobile_number)
            ->getFirstItem()->getData('email');


        $dbMobile = $this->customerFactory->create()->getCollection()
            ->addFieldToFilter('mobile_number', $mobile_number)
            ->getFirstItem()->getData('mobile_number');

        if($mobile_number==$dbMobile) {
            try {
                $token = $this->customerTokenService->createCustomerAccessToken($dbEmail, $args['password']);
                return ['token' => $token];
            } catch (AuthenticationException $e) {
                throw new GraphQlAuthenticationException(__($e->getMessage()), $e);
            }
        }
        else{
            throw new GraphQlAlreadyExistsException(
                __('The account sign-in was incorrect  or your account is disabled temporarily. Please wait and try again later.')
            );
        }
    }
}
