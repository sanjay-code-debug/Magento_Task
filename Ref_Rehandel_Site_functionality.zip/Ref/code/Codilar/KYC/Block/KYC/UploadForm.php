<?php

namespace Codilar\KYC\Block\KYC;

use Codilar\KYC\Helper\Data;
use Magento\Customer\Model\Session;
use Magento\Framework\App\Request\Http;
use Magento\Framework\Data\Form\FormKey;
use Magento\Framework\Registry;
use Magento\Framework\UrlInterface;
use Magento\Framework\View\Element\Template;
use Magento\Sales\Api\OrderRepositoryInterface;
use Magento\Sales\Model\ResourceModel\Order\Collection;
use Codilar\KYC\Model\KYCManager;
use Magento\Sales\Model\Order;
use Magento\Customer\Model\CustomerFactory;
/**
 * Class UploadForm
 * @package Codilar\KYC\Block\KYC
 */
class UploadForm extends \Magento\Framework\View\Element\Template
{
    /**
     * @var Data
     */
    protected $_kycHelper;
    /**
     * @var FormKey
     */
    private $formKey;
    /**
     * @var Session
     */
    private $customerSession;
    /**
     * @var OrderRepositoryInterface
     */
    private $orderRepository;
    /**
     * @var UrlInterface
     */
    private $url;
    /**
     * @var Registry
     */
    private $registry;
    /**
     * @var Collection
     */
    private $ordersCollection;
    /**
     * @var Http
     */
    private $request;
    /**
     * @var KYCManager
     */
    private $KYCManager;
    /**
     * @var Order
     */
    private $order;
    
    /**
     * @var CustomerFactory
     */
    protected $customerFactory;

    /**
     * Reviews constructor.
     * @param Template\Context $context
     * @param Data $kycHelper
     * @param FormKey $formKey
     * @param Session $customerSession
     * @param OrderRepositoryInterface $orderRepository
     * @param UrlInterface $url
     * @param Registry $registry
     * @param Collection $ordersCollection
     * @param Http $request
     * @param KYCManager $KYCManager
     * @param Order $Order
     */
    public function __construct(
        Template\Context $context,
        Data $kycHelper,
        FormKey $formKey,
        Session $customerSession,
        OrderRepositoryInterface $orderRepository,
        UrlInterface $url,
        Registry $registry,
        Collection $ordersCollection,
        Http $request,
        KYCManager $KYCManager,
        Order $order,
        \Magento\Directory\Block\Data $directoryBlock,
        CustomerFactory $customerFactory
    )
    {
        $this->_customerFactory = $customerFactory;
        $this->directoryBlock = $directoryBlock;
        $this->_kycHelper = $kycHelper;
        parent::__construct($context);
        $this->formKey = $formKey;
        $this->customerSession = $customerSession;
        $this->orderRepository = $orderRepository;
        $this->url = $url;
        $this->registry = $registry;
        $this->ordersCollection = $ordersCollection;
        $this->request = $request;
        $this->KYCManager = $KYCManager;
        $this->order = $order;
    }

    /**
     * @return bool
     */
    public function getModuleStatus()
    {
        return $this->_kycHelper->getModuleStatus();
    }

    /**
     * @return string
     */
    public function getFormKey()
    {
        return $this->formKey->getFormKey();
    }

    /**
     * @param $orderId
     * @return string
     */
    public function getSalesOrderViewUrl($orderId)
    {
        return $this->url->getUrl('sales/order/view', ['order_id' => $orderId]);
    }

    /**
     * @param $orderId
     * @return string
     */
    public function getKycUploadUrl($orderId)
    {
        $customerId = $this->getCustomerId();
        return $this->url->getUrl('kyc/kyc/uploadform', ['order_id' => $orderId, 'customer_id' => $customerId]);
    }

    /**
     * @return int|null
     */
    public function getCustomerId()
    {
        if ($this->customerSession->isLoggedIn()) {
            return $this->customerSession->getCustomerId();
        }
        return null;
    }

    /**
     * @return mixed
     */
    public function getOrderId()
    {
        
       //return 1;
        $customerOrder = $this->order->getCollection()->addAttributeToFilter('customer_id',$this->getCustomerId())->setOrder('entity_id','DESC')->getFirstItem();
        return $customerOrder->getData("entity_id");
    }

    /**
     * @return string
     */
    public function getKycUploadPostUrl()
    {
        return $this->url->getUrl('kyc/kyc/kycpost');
    }

    /**
     * @return string
     */
    public function getBusinessKycUploadPostUrl()
    {
        return $this->url->getUrl('kyc/businesskyc/kycpost');
    }

    public function getKycDataByCustomerId($customerId){
        $collection = $this->KYCManager->getKycDataByCustomerId($customerId);
        return $collection;
    }

    public function getGst(){
        return $this->customerSession->getCustomer()->getGstNumber();
    }
    public function getAbn(){
       return $this->customerSession->getCustomer()->getAbn();
    }
    public function getCustomerCountry(){
        return $this->customerSession->getCustomer()->getBaseCountry();
    }
    public function getCustomerEmail(){
        return $this->customerSession->getCustomer()->getEmail();
    }
    public function getBusinessName(){
        return $this->customerSession->getCustomer()->getBusinessName();
    }
    public function getCountries()
    {
        $country = $this->directoryBlock->getCountryHtmlSelect();
        return $country;
    }
    public function getKycId(){
        $customerId = $this->getCustomerId();
        $kycData = $this->getKycDataByCustomerId($customerId);
        if($kycData){
            return $kycData->getId();
        }
        else{
            return null;
        }
    }
    public function isVatFileExists(){
        $customerId = $this->getCustomerId();
        $kycData = $this->getKycDataByCustomerId($customerId);
        if($kycData){
            if(strlen($kycData->getVatCertificateFilename()) > 0){
                return true;
            }
            return false;
        }
        else{
            return false;
        }
    }

    public function getVatFilename(){
        $customerId = $this->getCustomerId();
        $kycData = $this->getKycDataByCustomerId($customerId);
        if($kycData){
            if(strlen($kycData->getVatCertificateFilename()) > 0){
                return $kycData->getVatCertificateFilename();
            }
            return false;
        }
        else{
            return false;
        }
    }

    public function getCompanyRegistrationFilename(){
        $customerId = $this->getCustomerId();
        $kycData = $this->getKycDataByCustomerId($customerId);
        if($kycData){
            if(strlen($kycData->getCompanyRegistrationFilename()) > 0){
                return $kycData->getCompanyRegistrationFilename();
            }
            return false;
        }
        else{
            return false;
        }
    }

    public function isCompanyRegistrationFileExists(){
        $customerId = $this->getCustomerId();
        $kycData = $this->getKycDataByCustomerId($customerId);
        if($kycData){
            if(strlen($kycData->getCompanyRegistrationFilename()) > 0){
                return true;
            }
            return false;
        }
        else{
            return false;
        }
    }

    public function isPoaFileExists(){
        $customerId = $this->getCustomerId();
        $kycData = $this->getKycDataByCustomerId($customerId);
        if($kycData){
            if(strlen($kycData->getPoaFilename()) > 0){
                return true;
            }
            return false;
        }
        else{
            return false;
        }
    }
}