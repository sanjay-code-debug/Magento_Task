<?php

namespace Codilar\KYC\Block\KYC;

use Codilar\KYC\Helper\Data;
use Codilar\KYC\Model\KYCFactory;
use Magento\Customer\Model\Session;
use Magento\Framework\Data\Form\FormKey;
use Magento\Framework\Registry;
use Magento\Framework\UrlInterface;
use Magento\Framework\View\Element\Template;
use Magento\Sales\Api\OrderRepositoryInterface;
use Magento\Sales\Model\ResourceModel\Order\Collection;
use Magento\Store\Model\StoreManagerInterface;

/**
 * Class Orders
 * @package Codilar\KYC\Block\KYC
 */
class Orders extends \Magento\Framework\View\Element\Template
{
    /**
     * @var Data
     */
    protected $_kycHelper;
    /**
     * @var FormKey
     */
    private $formKey;
    /**
     * @var Session
     */
    private $customerSession;
    /**
     * @var OrderRepositoryInterface
     */
    private $orderRepository;
    /**
     * @var UrlInterface
     */
    private $url;
    /**
     * @var Registry
     */
    private $registry;
    /**
     * @var Collection
     */
    private $ordersCollection;
    /**
     * @var KYCFactory
     */
    private $KYCFactory;
    /**
     * @var StoreManagerInterface
     */
    private $storeManager;

    /**
     * Reviews constructor.
     * @param Template\Context         $context
     * @param Data                     $kycHelper
     * @param FormKey                  $formKey
     * @param Session                  $customerSession
     * @param OrderRepositoryInterface $orderRepository
     * @param UrlInterface             $url
     * @param Registry                 $registry
     * @param Collection               $ordersCollection
     * @param KYCFactory               $KYCFactory
     * @param StoreManagerInterface    $storeManager
     */
    public function __construct(
        Template\Context $context,
        Data $kycHelper,
        FormKey $formKey,
        Session $customerSession,
        OrderRepositoryInterface $orderRepository,
        UrlInterface $url,
        Registry $registry,
        Collection $ordersCollection,
        KYCFactory $KYCFactory,
        StoreManagerInterface $storeManager
    )
    {
        $this->_kycHelper = $kycHelper;
        parent::__construct($context);
        $this->formKey = $formKey;
        $this->customerSession = $customerSession;
        $this->orderRepository = $orderRepository;
        $this->url = $url;
        $this->registry = $registry;
        $this->ordersCollection = $ordersCollection;
        $this->KYCFactory = $KYCFactory;
        $this->storeManager = $storeManager;
    }

    /**
     * @return bool
     */
    public function getModuleStatus()
    {
        return $this->_kycHelper->getModuleStatus();
    }

    /**
     * @return string
     */
    public function getFormKey()
    {
        return $this->formKey->getFormKey();
    }

    /**
     * @return $this|null
     */
    public function getAllOrders()
    {
        $customerId = $this->getCustomerId();
        if ($customerId) {
            $collection = $this->ordersCollection->addFieldToFilter('customer_id', $customerId)->load();
            return $collection;
        }
        return null;
    }

    /**
     * @return int|null
     */
    public function getCustomerId()
    {
        if ($this->customerSession->isLoggedIn()) {
            return $this->customerSession->getCustomerId();
        }
        return null;
    }

    /**
     * @param $orderId
     * @return string
     */
    public function getSalesOrderViewUrl($orderId)
    {
        return $this->url->getUrl('sales/order/view', ['order_id' => $orderId]);
    }

    /**
     * @param $orderId
     * @return string
     */
    public function getKycUploadUrl($orderId)
    {
        $customerId = $this->getCustomerId();
        return $this->url->getUrl('kyc/kyc/uploadform', ['order_id' => $orderId, 'customer_id' => $customerId]);
    }

    /**
     * @param $orderId
     * @return string
     */
    public function getBusinessKycUploadUrl($orderId)
    {
        $customerId = $this->getCustomerId();
        return $this->url->getUrl('kyc/businesskyc/uploadform', ['order_id' => $orderId, 'customer_id' => $customerId]);
    }

    /**
     * @param $orderId
     * @return bool
     */
    public function isKycAlreadyUploaded($orderId)
    {
        $customerId = $this->getCustomerId();
        $kycData = $this->getKycDataByOrderId($orderId, $customerId);
        if ($kycData) {
            if ($kycData['id_proof'] || $kycData['address_proof']) {
                return false;
            }
            return true;
        } else {
            return true;
        }
    }

    /**
     * @param $orderId
     * @return bool
     */
    public function isBusinessKycAlreadyUploaded($orderId)
    {
        $customerId = $this->getCustomerId();
        $kycData = $this->getKycDataByOrderId($orderId, $customerId);
        if ($kycData) {
            if ($kycData['vat_certificate_filename'] || $kycData['company_registration_filename'] || $kycData['poa_filename']) {
                return false;
            }
            return true;
        } else {
            return true;
        }
    }

    /**
     * @param $orderId
     * @param $customerId
     * @return \Magento\Framework\DataObject|null
     */
    public function getKycDataByOrderId($orderId, $customerId)
    {
        $collection = $this->KYCFactory->create()->getCollection()
            ->addFieldToFilter('order_id', $orderId)
            ->addFieldToFilter('customer_id', $customerId)
            ->getFirstItem();
        if ($collection) {
            return $collection->getData();
        }
        return null;
    }

    public function getStoreCode(){
        return $this->storeManager->getStore()->getCode();
    }

    /**
     * @param $storeId
     * @return string
     */
    public function getStoreCodeByStoreId($storeId)
    {
        return $this->storeManager->getStore($storeId)->getCode();
    }
}