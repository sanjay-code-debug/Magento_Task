<?php

namespace Codilar\KYC\Block\Adminhtml\KYC;

use Magento\Backend\Block\Template\Context;
use Magento\Framework\Filesystem;
use Magento\Framework\Filesystem\Driver\File;
use Magento\Framework\Registry;
use Magento\Store\Model\StoreManagerInterface;

/**
 * Class BusinessKYC
 * @package Codilar\KYC\Block\Adminhtml\KYC
 */
class BusinessKYC extends \Magento\Backend\Block\Template
{
    /**
     * Core registry
     *
     * @var Registry
     */
    protected $_coreRegistry = null;
    /**
     * Block template.
     *
     * @var string
     */
    protected $_template = 'kyc/business_kyc.phtml';
    /**
     * @var Filesystem\Directory\WriteInterface
     */
    protected $_mediaDirectory;
    /**
     * @var StoreManagerInterface
     */
    private $storeManager;
    /**
     * @var File
     */
    private $file;
    /**
     * @var customer
     */
    protected $customer;
    /**
     * @var directoryBlock
     */
    protected $directoryBlock;

    /**
     * BusinessKYC constructor.
     * @param Context               $context
     * @param Registry              $registry
     * @param Filesystem            $filesystem
     * @param StoreManagerInterface $storeManager
     * @param File                  $file
     * @param array                 $data
     */
    public function __construct(
        Context $context,
        Registry $registry,
        Filesystem $filesystem,
        StoreManagerInterface $storeManager,
        File $file,
        \Magento\Customer\Model\CustomerFactory $customer,
        \Magento\Directory\Block\Data $directoryBlock,
        array $data = []
    )
    {
        $this->_coreRegistry = $registry;
        parent::__construct($context, $data);
        $this->_mediaDirectory = $filesystem->getDirectoryRead(\Magento\Framework\App\Filesystem\DirectoryList::MEDIA);
        $this->storeManager = $storeManager;
        $this->file = $file;
        $this->customer = $customer;
        $this->directoryBlock = $directoryBlock;
    }

    /**
     * @return bool
     */
    public function isFileExists()
    {
        $addressProofPath = $this->getKYCAddressProof();
        if (strlen($addressProofPath) < 1) {
            return false;
        }
        $absoluteAddressProof = $this->_mediaDirectory->getAbsolutePath($addressProofPath);
        try {
            if ($this->file->isExists($absoluteAddressProof)) {
                return true;
            }
            return false;
        } catch (\Exception $e) {
            return false;
        }
    }

    /**
     * @return bool
     */
    public function isVatDataExists()
    {
        $kycData = $this->getKYCData();
        $vatFile = $kycData->getVatCertificateFilename();
        if (strlen($vatFile) < 1) {
            return false;
        }
        if($kycData->getVatCertificate()){
            return true;
        }
        return false;
    }

    /**
     * @return bool
     */
    public function isCRDataExists()
    {
        $kycData = $this->getKYCData();
        $vatFile = $kycData->getCompanyRegistrationFilename();
        if (strlen($vatFile) < 1) {
            return false;
        }
        if($kycData->getCompanyRegistration()){
            return true;
        }
        return false;
    }

    /**
     * @return bool
     */
    public function isPoaDataExists()
    {
        $kycData = $this->getKYCData();
        $vatFile = $kycData->getPoaFilename();
        if (strlen($vatFile) < 1) {
            return false;
        }
        if($kycData->getPoa()){
            return true;
        }
        return false;
    }

    /**
     * @return string
     */
    public function getKYCAddressProof()
    {
        $kyc = $this->getKYCData();
        if ($kyc) {
            return $kyc->getAddressProof();
        }
        return "";
    }

    /**
     * @return mixed
     */
    public function getKYCData()
    {
        $kyc = $this->_coreRegistry->registry("ws_kyc_registry");
        if ($kyc) {
            return $kyc;
        } else {
            return null;
        }
    }

    public function getKycId(){
        $kycData = $this->getKYCData();
        if($kycData){
            return $kycData->getId();
        }
        return null;
    }

    public function getKycCustomerData(){
        $kycData = $this->getKYCData();
        if($kycData){
            $customerid = $kycData->getCustomerId();
            $customer = $this->customer->create()->load($customerid);
            return $customer;
        }
        return null;
    }

    public function getCountries()
    {
        $country = $this->directoryBlock->getCountryHtmlSelect();
        $options = $this->directoryBlock->getCountryCollection()
                ->setForegroundCountries($this->directoryBlock->getTopDestinations())
                ->toOptionArray();
        return $options;
    }
    /**
     * @return string
     */
    public function getAddressProofPath()
    {
        $addressProofPath = $this->getKYCAddressProof();
        $mediaUrl = $this->storeManager->getStore()->getBaseUrl(\Magento\Framework\UrlInterface::URL_TYPE_MEDIA);
        $lastChar = substr($mediaUrl, -1);
        if ($lastChar == "/") {
            $mediaUrl = substr($mediaUrl, 0, strlen($mediaUrl) - 1);
        }
        $absoluteAddressProof = $mediaUrl . $addressProofPath;
        return $absoluteAddressProof;
    }
}
