<?php

namespace Codilar\KYC\Block\Adminhtml\KYC\Edit;

use Codilar\KYC\Helper\Data;
/**
 * Class GenericButton
 * @package Codilar\KYC\Block\Adminhtml\KYC\Edit
 */
class GenericButton
{
    protected $helper;
    /**
     * GenericButton constructor.
     * @param \Magento\Backend\Block\Widget\Context $context
     */
    //putting all the button methods in here.  No "right", but the whole
    //button/GenericButton thing seems -- not that great -- to begin with
    public function __construct(
        Data $helper,
        \Magento\Backend\Block\Widget\Context $context
    )
    {
        $this->helper = $helper;
        $this->context = $context;
    }

    /**
     * @return string
     */
    public function getBackUrl()
    {
        return $this->getUrl('*/*/');
    }

    /**
     * @param string $route
     * @param array  $params
     * @return string
     */
    public function getUrl($route = '', $params = [])
    {
        return $this->context->getUrlBuilder()->getUrl($route, $params);
    }

    /**
     * @return string
     */
    public function getDeleteUrl()
    {
        return $this->getUrl('*/*/delete', ['id' => $this->getId()]);
    }

    /**
     * @return int
     */
    public function getId()
    {
        return $this->context->getRequest()->getParam('id');
    }

    public function getRole(){
        return $this->helper->getAllowedResources();
    }

    /**
     * @return string
     */
    public function getDeleteVideoUrl()
    {
        return $this->getUrl('*/*/deletevideo', ['id' => $this->getId()]);
    }
}
