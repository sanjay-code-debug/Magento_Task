<?php

namespace Codilar\KYC\Block\Adminhtml\KYC;

use Magento\Backend\Block\Template\Context;
use Magento\Framework\Filesystem;
use Magento\Framework\Filesystem\Driver\File;
use Magento\Framework\Registry;
use Magento\Store\Model\StoreManagerInterface;

/**
 * Class IdProof
 * @package Codilar\KYC\Block\Adminhtml\KYC
 */
class IdProof extends \Magento\Backend\Block\Template
{
    /**
     * Core registry
     *
     * @var Registry
     */
    protected $_coreRegistry = null;
    /**
     * Block template.
     *
     * @var string
     */
    protected $_template = 'kyc/id_proof.phtml';
    /**
     * @var Filesystem\Directory\WriteInterface
     */
    protected $_mediaDirectory;
    /**
     * @var StoreManagerInterface
     */
    private $storeManager;
    /**
     * @var File
     */
    private $file;

    /**
     * IdProof constructor.
     * @param Context               $context
     * @param Registry              $registry
     * @param Filesystem            $filesystem
     * @param StoreManagerInterface $storeManager
     * @param File                  $file
     * @param array                 $data
     */
    public function __construct(
        Context $context,
        Registry $registry,
        Filesystem $filesystem,
        StoreManagerInterface $storeManager,
        File $file,
        array $data = []
    )
    {
        $this->_coreRegistry = $registry;
        parent::__construct($context, $data);
        $this->_mediaDirectory = $filesystem->getDirectoryRead(\Magento\Framework\App\Filesystem\DirectoryList::MEDIA);
        $this->storeManager = $storeManager;
        $this->file = $file;
    }

    /**
     * @return bool
     */
    public function isFileExists()
    {
        $idProofPath = $this->getKYCIdProof();
        if (strlen($idProofPath) < 1) {
            return false;
        }
        $absoluteIdProof = $this->_mediaDirectory->getAbsolutePath($idProofPath);
        try {
            if ($this->file->isExists($absoluteIdProof)) {
                return true;
            }
            return false;
        } catch (\Exception $e) {
            return false;
        }
    }

    /**
     * @return string
     */
    public function getKYCIdProof()
    {
        $kyc = $this->getKYCData();
        if ($kyc) {
            return $kyc->getIdProof();
        }
        return "";
    }

    /**
     * @return mixed
     */
    public function getKYCData()
    {
        $kyc = $this->_coreRegistry->registry("ws_kyc_registry");
        if ($kyc) {
            return $kyc;
        } else {
            return null;
        }
    }

    /**
     * @return string
     */
    public function getIdProofPath()
    {
        $idProofPath = $this->getKYCIdProof();
        $mediaUrl = $this->storeManager->getStore()->getBaseUrl(\Magento\Framework\UrlInterface::URL_TYPE_MEDIA);
        $lastChar = substr($mediaUrl, -1);
        if ($lastChar == "/") {
            $mediaUrl = substr($mediaUrl, 0, strlen($mediaUrl) - 1);
        }
        $absoluteIdProof = $mediaUrl . $idProofPath;
        return $absoluteIdProof;
    }
}