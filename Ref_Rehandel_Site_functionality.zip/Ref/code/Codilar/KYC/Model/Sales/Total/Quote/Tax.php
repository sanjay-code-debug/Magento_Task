<?php

namespace Codilar\KYC\Model\Sales\Total\Quote;

use Magento\Customer\Api\Data\AddressInterfaceFactory as CustomerAddressFactory;
use Magento\Customer\Api\Data\RegionInterfaceFactory as CustomerAddressRegionFactory;
use Magento\Framework\App\ObjectManager;
use Magento\Framework\Serialize\Serializer\Json;
use Magento\Quote\Api\Data\ShippingAssignmentInterface;
use Magento\Quote\Model\Quote\Address;
use Magento\Tax\Api\Data\TaxClassKeyInterface;
use Magento\Tax\Model\Calculation;

class Tax extends \Magento\Tax\Model\Sales\Total\Quote\Tax
{

 
    /**
    * Class constructor
    *
    * @param \Magento\Tax\Model\Config $taxConfig
    * @param \Magento\Tax\Api\TaxCalculationInterface $taxCalculationService
    * @param \Magento\Tax\Api\Data\QuoteDetailsInterfaceFactory $quoteDetailsDataObjectFactory
    * @param \Magento\Tax\Api\Data\QuoteDetailsItemInterfaceFactory $quoteDetailsItemDataObjectFactory
    * @param \Magento\Tax\Api\Data\TaxClassKeyInterfaceFactory $taxClassKeyDataObjectFactory
    * @param CustomerAddressFactory $customerAddressFactory
    * @param CustomerAddressRegionFactory $customerAddressRegionFactory
    * @param \Magento\Tax\Helper\Data $taxData
    */
    public function __construct(
        \Magento\Tax\Model\Config $taxConfig,
        \Magento\Tax\Api\TaxCalculationInterface $taxCalculationService,
        \Magento\Tax\Api\Data\QuoteDetailsInterfaceFactory $quoteDetailsDataObjectFactory,
        \Magento\Tax\Api\Data\QuoteDetailsItemInterfaceFactory $quoteDetailsItemDataObjectFactory,
        \Magento\Tax\Api\Data\TaxClassKeyInterfaceFactory $taxClassKeyDataObjectFactory,
        CustomerAddressFactory $customerAddressFactory,
        CustomerAddressRegionFactory $customerAddressRegionFactory,
        \Codilar\KYC\Model\KYCFactory $kyc,
        \Magento\Customer\Model\Customer $customer,
        \Magento\Tax\Helper\Data $taxData
    ) {
        $this->_kyc = $kyc;
        $this->customer = $customer;
        $this->setCode('tax');
        parent::__construct(
            $taxConfig,
            $taxCalculationService,
            $quoteDetailsDataObjectFactory,
            $quoteDetailsItemDataObjectFactory,
            $taxClassKeyDataObjectFactory,
            $customerAddressFactory,
            $customerAddressRegionFactory,
            $taxData
        );
    }

    /**
    * Custom Collect tax totals for quote address
    *
    * @param Quote $quote
    * @param ShippingAssignmentInterface $shippingAssignment
    * @param Address\Total $total
    * @return $this
    * @throws RemoteServiceUnavailableException
    */
    public function collect(
        \Magento\Quote\Model\Quote $quote,
        \Magento\Quote\Api\Data\ShippingAssignmentInterface $shippingAssignment,
        \Magento\Quote\Model\Quote\Address\Total $total
    ) {

        $country_code = $quote->getShippingAddress()->getCountryId();
        
        if($country_code == "SG"){
            $subtotal = $total->getData("subtotal");
            $customer_id = $quote->getCustomer()->getId();
            $customer = $this->customer->load($customer_id);
            $is_gst = 0;
            $gst_number = $customer->getResource()
                ->getAttribute('gst_number')
                ->getFrontend()
                ->getValue($customer);
                
            if((is_numeric($gst_number) && $gst_number>0) || strlen($gst_number)>1){
                $is_gst = 1;
            }
            $kyc_data = $this->_kyc->create();
            $kyc_data->load($customer_id, 'customer_id');
            if ($is_gst==1 && $subtotal>10000) {
                $tax = 0;
            } else {
                $tax = $subtotal*7/100;
            }
            
            $total->setData('tax_amount', $tax);
            $total->setData('base_tax_amount', $tax);
            $total->setGrandTotal($total->getGrandTotal() + $tax);
            $total->setBaseGrandTotal($total->getBaseGrandTotal() + $tax);

            return $this;
        }
    }

}?>



