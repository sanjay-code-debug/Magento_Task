<?php

namespace Codilar\KYC\Model\Config\Source;

use Magento\Framework\Option\ArrayInterface;
use Magento\Store\Model\StoreManagerInterface;

/**
 * Class Websites
 * @package Codilar\KYC\Model\Config\Source
 */
class Websites implements ArrayInterface
{

    /**
     * @var StoreManagerInterface
     */
    private $storeManager;

    /**
     * Websites constructor.
     * @param StoreManagerInterface $storeManager
     */
    public function __construct(
        StoreManagerInterface $storeManager
    )
    {

        $this->storeManager = $storeManager;
    }

    /**
     * @return array
     */
    public function toOptionArray()
    {
        $websites = $this->storeManager->getWebsites();
        $_options = [];
        foreach ($websites as $website) {
            $_options[] = [
                'value' => $website->getId(),
                'label' => $website->getName()
            ];
        }
        return $_options;
    }
}