<?php
namespace Codilar\KYC\Model\Config\Source;

class Email implements \Magento\Framework\Option\ArrayInterface
{
    /**
     *
     * @var \Codilar\KYC\Model\KYCFactory
     */
    protected $_kycModel;

    /**
     *
     * @var \Magento\Customer\Model\CustomerFactory
     */
    protected $_customerFactory;

    /**
     * 
     * @param \Codilar\KYC\Model\KYCFactory $kycfactory
     * @param \Magento\Customer\Model\CustomerFactory $customerFactory
     */
    public function __construct(
        \Codilar\KYC\Model\KYCFactory $kycfactory,
        \Magento\Customer\Model\CustomerFactory $customerFactory
    )
    {
        $this->_kycModel = $kycfactory;
        $this->_customerFactory = $customerFactory;
    }
    /**
     * @return customers
     */
    public function getCustomerEmail(){
        $params = $this->_kycModel->create()->getCollection()->addfieldToSelect('customer_id')->load();
        $customerObj = $this->_customerFactory->create()->getCollection();
        $customers = $customerObj->addAttributeToSelect('email')
                    ->addAttributeToFilter('entity_id', array('nin' => $params->getData(),))
                    ->load();
        return $customers;
    }
    /**
     * Options getter
     *
     * @return array
     */
    public function toOptionArray()
    {
        $customers = $this->getCustomerEmail();
        foreach($customers as $c){
            $data[] = ['value'=>$c->getEmail(),'label' => $c->getEmail()];
        }
        return $data;
    } 
}
