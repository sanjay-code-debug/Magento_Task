<?php

namespace Codilar\KYC\Model\Resolver;

use Magento\Framework\GraphQl\Config\Element\Field;
use Magento\Framework\GraphQl\Query\ResolverInterface;
use Magento\Framework\GraphQl\Schema\Type\ResolveInfo;
use Magento\Customer\Model\Customer;
use Magento\Framework\Filesystem\DirectoryList;

use Codilar\KYC\Model\KYCFactory;
use Magento\Store\Model\StoreManagerInterface;

class SaveKycData implements ResolverInterface {

    protected $customer;
    /**
     * @var KYCFactory
     */
    protected $kycModel;

    /**
     * @var StoreManagerInterface
     */
    protected $storeManager;
    /**
     * @var DirectoryList
     */
    private $directoryList;

    public function __construct(
        Customer $customer,
        KYCFactory $kycModel,
        StoreManagerInterface $storeManager,
        DirectoryList $directoryList
    )
    {
        $this->customer = $customer;
        $this->kycModel = $kycModel;
        $this->storeManager = $storeManager;
        $this->directoryList = $directoryList;
    }

    public function resolve(Field $field, $context, ResolveInfo $info, array $value = null, array $args = null)
    {
        $business_name = $args['business_name'];
        $abn = $args['business_regd_no'];
        $email = $args['email'];
        $country = $args['country'];
        $gst_number = $args['vat_gst_tax_no'];

        $vat_certificate_filename =$args['vat_certificate_filename'];
        $company_registration_filename = $args['company_registration_filename'];

        $websiteId = $this->storeManager->getStore()->getWebsiteId();
        $customer = $this->customer->setWebsiteId($websiteId)->loadByEmail($email);

        $rootPath = $this->directoryList->getRoot();

        $vatFileValue =explode(",",$vat_certificate_filename,3);

        $vatImageEncode =substr($vatFileValue[1], 0, -1);
        $imageName= $vatFileValue[2];
        $vatImageName = $this->getImageName($imageName);

        $id = $customer->getId();

        $makeVatImage =base64_decode($vatImageEncode);
        $saveVatImage = $rootPath."/pub/media/codilar/kyc_documents/kyc_business/".$id. "/";
         if (!file_exists($saveVatImage)) {
            if (!mkdir($saveVatImage, 0777, true)) {
                die('Failed to create folders...');
            }
         }

        file_put_contents($saveVatImage.$vatImageName, $makeVatImage);

        $companyFileValue =explode(",",$company_registration_filename,3);

        $companyImageEncode =substr($companyFileValue[1], 0, -1);
        $imageNameSec = $companyFileValue[2];
        $companyImageName = $this->getImageName($imageNameSec);

        $makeCompanyImage =base64_decode($companyImageEncode);
        $saveCompanyImage = $rootPath."/pub/media/codilar/kyc_documents/kyc_business/".$id. "/";
         if (!file_exists($saveCompanyImage)) {
            if (!mkdir($saveCompanyImage, 0777, true)) {
                die('Failed to create folders...');
            }
         }

        file_put_contents($saveCompanyImage.$companyImageName, $makeCompanyImage);

            if(!empty($customer->getData())) {
            $customer->setData('gst_number', $gst_number);
            $customer->setData('business_name', $business_name);
            $customer->setData('base_country', $country);
            $customer->setData('abn', $abn);
            $customer->save();

            $model = $this->kycModel->create();
            $model->load($email, 'customer_email');

           $customer_id = $customer->getId();
            $kyc_type = 2;

            $website_id = $websiteId;
            $current_date =date('Y-m-d h:i:s');

            $gst_Number = $gst_number;

            $model->setData("customer_id", $customer_id);
            $model->setData("kyc_type", $kyc_type);
            $model->setData("website_id", $website_id);
            $model->setData("uploaded_at", $current_date);
            $model->setData("customer_email", $email);
            $model->setData("gst_number",$gst_Number);
            $model->setData("vat_certificate",$vatImageEncode);
            $model->setData("vat_certificate_filename",$vatImageName);
            $model->setData("company_registration",$companyImageEncode);
            $model->setData("company_registration_filename",$companyImageName);
            $model->save();

            $msg = "Kyc Details Saved Successfully";
            $ar[] = ['message' => $msg];
            return $ar;
        }
        else{
            $msg = "User Is Not Register";
            $ar[] = ['message' => $msg];
            return $ar;
        }
    }

    public function getImageName($imageName) {
        $imageNameArr = explode(":",$imageName);
        $imageNameFinal = $imageNameArr[1];
        global $actualImage;
        $actualImage =array();

        for ($i=0; $i<strlen($imageNameFinal); $i++) {
            if($imageNameFinal[$i]=='"' || $imageNameFinal[$i]=='}') {
                continue;
            }
            $actualImage[] = $imageNameFinal[$i];
        }
        return implode($actualImage);
    }
}
