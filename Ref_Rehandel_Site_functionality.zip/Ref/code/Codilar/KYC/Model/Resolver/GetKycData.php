<?php

namespace Codilar\KYC\Model\Resolver;

use Magento\Framework\GraphQl\Config\Element\Field;
use Magento\Framework\GraphQl\Query\ResolverInterface;
use Magento\Framework\GraphQl\Schema\Type\ResolveInfo;
use Magento\Customer\Model\Customer;
use Codilar\KYC\Model\KYCFactory;
use Magento\Store\Model\StoreManagerInterface;

use Codilar\KYC\Block\KYC\UploadForm;

class GetKycData implements ResolverInterface {

    /**
     * @var Customer
     */
    protected $customer;

    /**
     * @var KYCFactory
     */
    protected $kycModel;

    /**
     * @var StoreManagerInterface
     */
    protected $storeManager;
    /**
     * @var UploadForm
     */
    private $uploadForm;

    public function __construct(
        Customer $customer,
        KYCFactory $kycModel,
        StoreManagerInterface $storeManager,
        UploadForm $uploadForm
    )
    {
        $this->customer = $customer;
        $this->kycModel = $kycModel;
        $this->storeManager = $storeManager;
        $this->uploadForm = $uploadForm;
    }

    public function resolve(Field $field, $context, ResolveInfo $info, array $value = null, array $args = null)
    {
        $email = $args['email'];
        $websiteId =$this->storeManager->getStore()->getWebsiteId();
        $customer = $this->customer->setWebsiteId($websiteId)->loadByEmail($email)->getDataModel();
        $customerAttributeData = $customer->__toArray();

        $em = $this->uploadForm->getCustomerEmail();
        $kycId = $this->uploadForm->getKycId();

        if($customer->getId()!="") {
            $businessName = $customerAttributeData['custom_attributes']['business_name']['value'];
            $gst_no = $customerAttributeData['custom_attributes']['gst_number']['value'];
            $abn = $customerAttributeData['custom_attributes']['abn']['value'];
            $countryList = $customerAttributeData['custom_attributes']['base_country']['value'];

            $vat_certificate_filename = $this->uploadForm->getUrl('kyc/businesskyc/downloadcrfile/kyc_id/' . $kycId);
            $company_registration_filename = $this->uploadForm->getUrl('kyc/businesskyc/downloadvatfile/kyc_id/' . $kycId);

            $model = $this->kycModel->create();
            $model->load($email, 'customer_email');

            $ar[] = [
                'business_name'=>$businessName,
                'business_regd_no'=>$abn,
                'email'=>$email,
                'country'=>$countryList,
                'vat_gst_tax_no'=>$gst_no,
                'vat_certificate_filename'=>$vat_certificate_filename,
                'company_registration_filename'=>$company_registration_filename,
                'message'=>'Data Get Successfully'
            ];
            return $ar;
        }

        $ar[] = ['message'=>'Need To Login To Get  User Data'];
        return  $ar;
    }
}
