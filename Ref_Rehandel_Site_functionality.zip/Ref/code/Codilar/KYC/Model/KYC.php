<?php

namespace Codilar\KYC\Model;
/**
 * Class KYC
 * @package Codilar\KYC\Model
 */
class KYC extends \Magento\Framework\Model\AbstractModel
{
    /**
     *
     */
    const CACHE_TAG = 'codilar_kyc_documents';

    /**
     * @return array
     */
    public function getIdentities()
    {
        return [self::CACHE_TAG . '_' . $this->getId()];
    }

    protected function _construct()
    {
        $this->_init('Codilar\KYC\Model\ResourceModel\KYC');
    }
}
