<?php

namespace Codilar\KYC\Model\ResourceModel;
/**
 * Class KYC
 * @package Codilar\KYC\Model\ResourceModel
 */
class KYC extends \Magento\Framework\Model\ResourceModel\Db\AbstractDb
{
    /**
     * @var string
     */
    protected $_idFieldName = 'id';

    protected function _construct()
    {
        $this->_init('codilar_kyc_documents', 'id');
    }
}
