<?php

namespace Codilar\KYC\Model\ResourceModel\KYC;
/**
 * Class Collection
 * @package Codilar\KYC\Model\ResourceModel\KYC
 */
class Collection extends \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection
{
    /**
     * Define model & resource model
     */
    protected $_idFieldName = 'id';

    protected function _construct()
    {
        $this->_init('Codilar\KYC\Model\KYC', 'Codilar\KYC\Model\ResourceModel\KYC');
    }
}
