<?php

namespace Codilar\KYC\Model;

use Codilar\KYC\Model\KYCFactory;
use Magento\Framework\Filesystem;
use Magento\Framework\Filesystem\Driver\File;
use Magento\Framework\Mail\Template\TransportBuilder;
use Magento\Framework\Model\Context;
use Magento\Framework\Registry;
use Magento\Sales\Model\Order;
use Magento\Store\Model\StoreManagerInterface;
use Psr\Log\LoggerInterface;
use Magento\Customer\Model\CustomerFactory;
use Magento\Customer\Api\CustomerRepositoryInterface;
/**
 * Class KYCManager
 * @package Codilar\KYC\Model
 */
class KYCManager extends \Magento\Framework\Model\AbstractModel
{
    /**
     * @var \Magento\Customer\Api\AddressRepositoryInterface
     */
    protected $addressRepository;
    /**
     * @var \Codilar\KYC\Model\KYCFactory
     */
    protected $_kycModel;
    /**
     * @var StoreManagerInterface
     */
    protected $_storeManager;
    /**
     * @var Filesystem\Directory\WriteInterface
     */
    protected $_mediaDirectory;
    /**
     * @var Filesystem
     */
    private $filesystem;
    /**
     * @var File
     */
    private $file;
    /**
     * @var LoggerInterface
     */
    private $logger;
    /**
     * @var TransportBuilder
     */
    private $transportBuilder;
    /**
     * @var Order
     */
    private $order;
    /**
     * @var CustomerFactory
     */
    protected $customerFactory;

        /**
     * @var Customer
     */
    protected $customer;

    /**
     * KYCManager constructor.
     * @param Context                       $context
     * @param Registry                      $registry
     * @param \Codilar\KYC\Model\KYCFactory $kycModel
     * @param Filesystem                    $filesystem
     * @param LoggerInterface               $logger
     * @param TransportBuilder              $transportBuilder
     * @param File                          $file
     * @param Order                         $order
     * @throws \Magento\Framework\Exception\FileSystemException
     */
    public function __construct(
        Context $context,
        Registry $registry,
        KYCFactory $kycModel,
        Filesystem $filesystem,
        LoggerInterface $logger,
        TransportBuilder $transportBuilder,
        File $file,
        CustomerFactory $customerFactory,
        CustomerRepositoryInterface $customer,
        Order $order,
        \Magento\Customer\Api\AddressRepositoryInterface $addressRepository
    )
    {
        $this->addressRepository = $addressRepository;
        $this->_kycModel = $kycModel;
        parent::__construct($context, $registry);
        $this->filesystem = $filesystem;
        $this->_mediaDirectory = $filesystem->getDirectoryWrite(\Magento\Framework\App\Filesystem\DirectoryList::MEDIA);
        $this->file = $file;
        $this->logger = $logger;
        $this->transportBuilder = $transportBuilder;
        $this->_customerFactory = $customerFactory;
        $this->_customer = $customer;
        $this->order = $order;
    }

    /**
     * @param $customerId
     * @param $kycType
     * @param $idProof
     * @param $addressProof
     * @param $websiteId
     * @return bool
     */
    public function saveKycInformation($customerId, $kycType, $idProof, $addressProof, $websiteId)
    {
        $kycId = $this->getKycIdByCustomer($customerId);
        $kycData = [
            "id" => $kycId,
            "customer_id" => $customerId,
            "kyc_type" => $kycType,
            "id_proof" => $idProof,
            "address_proof" => $addressProof,
            "website_id" => $websiteId
        ];
        $model = $this->_kycModel->create();
        $model->setData($kycData);
        try {
            $model->getResource()->save($model);
            $this->setKycUploaded($customerId);
            return true;
        } catch (\Exception $e) {
            return false;
        }
    }

    public function saveBusinessKycInformation($customerId, $data, $websiteId)
    {

        $kycId = null;
        
        $customer = $this->_customerFactory->create()->load($customerId)->getDataModel();
        $customer->setCustomAttribute('gst_number', $data['gst_number']);
        $customer->setCustomAttribute('business_name', $data['business_name']);
        $customer->setCustomAttribute('base_country', $data['country_id']);
        $customer->setCustomAttribute('abn', $data['abn']);
        $this->_customer->save($customer);
        
        if (array_key_exists('id', $data)) {
            $kycId = $data['id'];
            $kycData = [
                "id" => $kycId,
                "customer_id" => $customerId,
                "kyc_type" => 2,
                "vat_certificate_filename" => $data['vat_certificate_filename'],
                "vat_certificate" => $data['vat_certificate'],
                "company_registration_filename" => $data['company_registration_filename'],
                "company_registration" => $data['company_registration'],
                "poa_filename" => $data['poa_filename'],
                "poa" => $data['poa'],
                "gst_number" => $data['gst_number'],
                "website_id" => $websiteId,
                "customer_email" =>$data['customer_email']
            ];
        }
        else{
            $kycData = [
                "customer_id" => $customerId,
                "kyc_type" => 2,
                "vat_certificate_filename" => $data['vat_certificate_filename'],
                "vat_certificate" => $data['vat_certificate'],
                "company_registration_filename" => $data['company_registration_filename'],
                "company_registration" => $data['company_registration'],
                "poa_filename" => $data['poa_filename'],
                "poa" => $data['poa'],
                "gst_number" => $data['gst_number'],
                "website_id" => $websiteId,
                "customer_email" =>$data['customer_email']
            ];
        }
        $model = $this->_kycModel->create();
        $model->setData($kycData);
        
        try {
            $saveData = $model->save();
            $this->setKycUploaded($customerId);
            return true;
        } catch (\Exception $e) {
            return false;
        }
    }

    /**
     * @param $customerId
     * @return null
     */
    public function getKycIdByCustomer($customerId)
    {
        $collection = $this->_kycModel->create()->getCollection()
            ->addFieldToFilter('customer_id', $customerId)
            ->getFirstItem();
        if ($collection) {
            return $collection->getId();
        }
        return null;
    }

    /**
     * @param $kycId
     * @return null
     */
    public function getKycDataByKycId($kycId)
    {
        $collection = $this->_kycModel->create()->getCollection()
            ->addFieldToFilter('id', $kycId)
            ->getFirstItem();
        if ($collection) {
            return $collection;
        }
        return null;
    }

    /**
     * @param $customerId
     * @return null
     */
    public function getKycDataByCustomerId($customerId)
    {
        $collection = $this->_kycModel->create()->getCollection()
            ->addFieldToFilter('customer_id', $customerId)
            ->addFieldToFilter('kyc_type', 2)
            ->getFirstItem();
        if ($collection) {
            return $collection;
        }
        return null;
    }

    /**
     * @param $customerId
     * @throws \Exception
     */
    public function setKycUploaded($customerId)
    {
        $model = $this->_kycModel->create()->getCollection()
        ->addFieldToFilter('customer_id', $customerId)
        ->getFirstItem();
        $model->setIsKYCVerified("1");
        $model->getResource()->save($model);
    }

    /**
     * @param $path
     * @return bool|string
     */
    public function deleteFile($path)
    {
        $target = $this->_mediaDirectory->getAbsolutePath($path);
        try {
            if ($this->file->isExists($target)) {
                $this->file->deleteFile($target);
                return true;
            }
        } catch (\Exception $e) {
            return $e->getMessage();
        }
    }

    /**
     * @param $customerId
     * @throws \Exception
     */
    public function unsetKycUploaded($customerId)
    {
        $model = $this->_kycModel->create()->getCollection()
        ->addFieldToFilter('customer_id', $customerId)
        ->getFirstItem();
        $model->setIsKYCVerified("0");
        $model->getResource()->save($model);
    }

}