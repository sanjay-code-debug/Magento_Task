<?php

namespace Codilar\KYC\Ui\Component\Listing\Column;

/**
 * Class Status
 * @package Codilar\KYC\Ui\Component\Listing\Column
 */
class Status implements \Magento\Framework\Data\OptionSourceInterface
{
    /**
     * Get options
     *
     * @return array
     */
    public function toOptionArray()
    {
        return [['value' => '1', 'label' => __('Yes')], ['value' => '0', 'label' => __('No')]];
    }
}