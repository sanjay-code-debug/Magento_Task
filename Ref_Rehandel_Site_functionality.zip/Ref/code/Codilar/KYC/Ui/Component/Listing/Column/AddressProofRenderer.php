<?php

namespace Codilar\KYC\Ui\Component\Listing\Column;

use Magento\Framework\View\Element\UiComponent\ContextInterface;
use Magento\Framework\View\Element\UiComponentFactory;
use Magento\Store\Model\StoreManagerInterface;
use Magento\Ui\Component\Listing\Columns\Column;

/**
 * Class AddressProofRenderer
 * @package Codilar\KYC\Ui\Component\Listing\Column
 */
class AddressProofRenderer extends Column
{

    /**
     * @var StoreManagerInterface
     */
    protected $_storeManager;
    /**
     * @var
     */
    protected $_productFactory;

    /**
     * AddressProofRenderer constructor.
     * @param ContextInterface      $context
     * @param UiComponentFactory    $uiComponentFactory
     * @param StoreManagerInterface $storeManager
     * @param array                 $components
     * @param array                 $data
     */
    public function __construct(
        ContextInterface $context,
        UiComponentFactory $uiComponentFactory,
        StoreManagerInterface $storeManager,
        array $components = [],
        array $data = []
    )
    {
        $this->_storeManager = $storeManager;
        parent::__construct($context, $uiComponentFactory, $components, $data);
    }

    /**
     * @param array $dataSource
     * @return array
     */
    public function prepareDataSource(array $dataSource)
    {
        if (isset($dataSource['data']['items'])) {
            foreach ($dataSource['data']['items'] as & $item) {
                $addressProof = $item['address_proof'];
                if (strlen($addressProof) > 0) {
                    $item['address_proof'] = 1;
                } else {
                    $item['address_proof'] = 0;
                }
            }
        }
        return $dataSource;
    }
}