<?php

namespace Codilar\KYC\Ui\Component\Listing\Column;

/**
 * Class KYCType
 * @package Codilar\KYC\Ui\Component\Listing\Column
 */
class IsKYC implements \Magento\Framework\Data\OptionSourceInterface
{
    /** 
     * Get options
     *
     * @return array
     */
    public function toOptionArray()
    {
        return [['value' => '1', 'label' => __('Verified')],['value' => '0', 'label' => __('Not Verified')]];
    }
} 