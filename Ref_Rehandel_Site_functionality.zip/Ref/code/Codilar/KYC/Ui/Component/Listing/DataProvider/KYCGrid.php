<?php

namespace Codilar\KYC\Ui\Component\Listing\DataProvider;

use Codilar\KYC\Model\ResourceModel\KYC\CollectionFactory;

/**
 * Class KYCGrid
 * @package Codilar\KYC\Ui\Component\Listing\DataProvider
 */
class KYCGrid extends \Magento\Ui\DataProvider\AbstractDataProvider
{
    /**
     * Grid constructor.
     * @param string            $name
     * @param string            $primaryFieldName
     * @param string            $requestFieldName
     * @param CollectionFactory $collectionFactory
     * @param array             $meta
     * @param array             $data
     */
    public function __construct(
        $name,
        $primaryFieldName,
        $requestFieldName,
        CollectionFactory $collectionFactory,
        array $meta = [],
        array $data = []
    )
    {
        parent::__construct($name, $primaryFieldName, $requestFieldName, $meta, $data);
        $this->collection = $collectionFactory->create()->addFieldToSelect(array('id','customer_id','customer_email','is_kyc_verify','uploaded_at'));
    }
}
