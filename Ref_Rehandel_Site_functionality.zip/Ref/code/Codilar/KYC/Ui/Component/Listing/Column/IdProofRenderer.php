<?php

namespace Codilar\KYC\Ui\Component\Listing\Column;

use Magento\Framework\View\Element\UiComponent\ContextInterface;
use Magento\Framework\View\Element\UiComponentFactory;
use Magento\Store\Model\StoreManagerInterface;
use Magento\Ui\Component\Listing\Columns\Column;

/**
 * Class IdProofRenderer
 * @package Codilar\KYC\Ui\Component\Listing\Column
 */
class IdProofRenderer extends Column
{

    /**
     * @var StoreManagerInterface
     */
    protected $_storeManager;
    /**
     * @var
     */
    protected $_productFactory;

    /**
     * IdProofRenderer constructor.
     * @param ContextInterface      $context
     * @param UiComponentFactory    $uiComponentFactory
     * @param StoreManagerInterface $storeManager
     * @param array                 $components
     * @param array                 $data
     */
    public function __construct(
        ContextInterface $context,
        UiComponentFactory $uiComponentFactory,
        StoreManagerInterface $storeManager,
        array $components = [],
        array $data = []
    )
    {
        $this->_storeManager = $storeManager;
        parent::__construct($context, $uiComponentFactory, $components, $data);
    }

    /**
     * @param array $dataSource
     * @return array
     */
    public function prepareDataSource(array $dataSource)
    {
        if (isset($dataSource['data']['items'])) {
            foreach ($dataSource['data']['items'] as & $item) {
                $idProof = $item['id_proof'];
                if (strlen($idProof) > 0) {
                    $item['id_proof'] = 1;
                } else {
                    $item['id_proof'] = 0;
                }
            }
        }
        return $dataSource;
    }
}