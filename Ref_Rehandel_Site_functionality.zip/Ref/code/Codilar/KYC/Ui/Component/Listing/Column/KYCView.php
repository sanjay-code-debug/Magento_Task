<?php

namespace Codilar\KYC\Ui\Component\Listing\Column;

use Codilar\KYC\Model\KYCFactory;
use Magento\Framework\Filesystem\DirectoryList;
use Magento\Framework\UrlInterface;
use Magento\Framework\View\Element\UiComponent\ContextInterface;
use Magento\Framework\View\Element\UiComponentFactory;
use Magento\Ui\Component\Listing\Columns\Column;

/**
 * Class KYCView
 * @package Codilar\KYC\Ui\Component\Listing\Column
 */
class KYCView extends Column
{
    /**
     * @var UrlInterface
     */
    protected $url;
    /**
     * @var DirectoryList
     */
    private $directoryList;
    /**
     * @var KYCFactory
     */
    private $KYCFactory;

    /**
     * KYCView constructor.
     * @param UrlInterface       $url
     * @param DirectoryList      $directoryList
     * @param ContextInterface   $context
     * @param UiComponentFactory $uiComponentFactory
     * @param KYCFactory         $KYCFactory
     * @param array              $components
     * @param array              $data
     */
    public function __construct(
        UrlInterface $url,
        DirectoryList $directoryList,
        ContextInterface $context,
        UiComponentFactory $uiComponentFactory,
        KYCFactory $KYCFactory,
        array $components = [],
        array $data = []
    )
    {
        $this->url = $url;
        $this->directoryList = $directoryList;
        parent::__construct($context, $uiComponentFactory, $components, $data);
        $this->KYCFactory = $KYCFactory;
    }

    /**
     * @param array $dataSource
     * @return array
     */
    public function prepareDataSource(array $dataSource)
    {
        if (isset($dataSource['data']['items'])) {
            foreach ($dataSource['data']['items'] as & $item) {
                $kycUploaded = $item['kyc_uploaded'];
                $orderId = $item['entity_id'];
                $customerId = $item['customer_id'];
                if ($kycUploaded == "1") {
                    $kycId = $this->getKycDataByOrderId($orderId, $customerId);
                    if ($kycId) {
                        $url = $this->url->getUrl('kyc/kyc/edit/id/' . $kycId);
                        //$item['kyc_uploaded'] = '<a target="_blank" href="' . $url . '">View KYC</a>';
                        $item['kyc_uploaded'] = "Yes";
                    } else {
                        $url = $this->url->getUrl('kyc/kyc/newkyc/');
                        //$item['kyc_uploaded'] = '<a target="_blank" href="' . $url . '">Upload KYC</a>';
                        $item['kyc_uploaded'] = "No";
                    }
                } else {
                    $url = $this->url->getUrl('kyc/kyc/newkyc/');
                    //$item['kyc_uploaded'] = '<a target="_blank" href="' . $url . '">Upload KYC</a>';
                    $item['kyc_uploaded'] = "No";
                }
                //$item['kyc_uploaded'] = "hello";
            }
        }

        return $dataSource;
    }

    /**
     * @param $orderId
     * @param $customerId
     * @return \Magento\Framework\DataObject|null
     */
    public function getKycDataByOrderId($orderId, $customerId)
    {
        $collection = $this->KYCFactory->create()->getCollection()
            ->addFieldToFilter('order_id', $orderId)
            ->addFieldToFilter('customer_id', $customerId)
            ->getFirstItem();
        if ($collection) {
            return $collection->getId();
        }
        return null;
    }
}