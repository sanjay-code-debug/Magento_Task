<?php

namespace Codilar\KYC\Ui;

use \Magento\Framework\View\Element\UiComponent\ContextInterface;
use \Codilar\KYC\Helper\Data;
/**
 * Class MassAction
 * @package Codilar\KYC\Ui
 */
class MassAction extends \Magento\Ui\Component\MassAction
{
    /**
     * @param array $dataSource
     * @return array
     */

    protected $context;
    protected $helper;

    public function __construct(
        ContextInterface $context, 
        Data $helper,
        $components,
        array $data
    ) {
        $this->helper = $helper;
        parent::__construct($context, $components, $data);
    }
    public function prepare()
    {
        parent::prepare();
        $config = $this->getConfiguration();
        if (!$this->helper->getAllowedResources()) {
            $allowedActions = [];
            foreach ($config['actions'] as $action) {
                if ('delete' != $action['type']) {
                    $allowedActions[] = $action;
                }
            }
            $config['actions'] = $allowedActions;
        }
        $this->setData('config', (array)$config);
    }

}
