<?php

namespace Codilar\KYC\Helper;

use Magento\Framework\App\Helper\Context;
use Psr\Log\LoggerInterface;

/**
 * Class Data
 * @package Codilar\KYC\Helper
 */
class Data extends \Magento\Framework\App\Helper\AbstractHelper
{
    /**
     * @var $_scopeConfigInterface
     */
    protected $_scopeConfig;
    /**
     * @var LoggerInterface
     */
    protected $_logger;

    protected $_checkoutSession;

    protected $aclRetriever;

    protected $authSession;

    /**
     * Data constructor.
     * @param Context         $context
     * @param LoggerInterface $loggerInterface
     */
    public function __construct(
        Context $context,
        LoggerInterface $loggerInterface,
        \Magento\Authorization\Model\Acl\AclRetriever $aclRetriever,
        \Magento\Backend\Model\Auth\Session $authSession, 
        \Magento\Checkout\Model\Session $_checkoutSession)
    {
        parent::__construct($context);
        $this->_scopeConfig = $context->getScopeConfig();
        $this->_logger = $loggerInterface;
        $this->_checkoutSession = $_checkoutSession;
        $this->aclRetriever = $aclRetriever;
        $this->authSession = $authSession;
    }

    /**
     * This function will return module status 0/1
     * @param null
     * @return boolean
     */
    public function getModuleStatus()
    {
        return $this->_scopeConfig->getValue('kyc/general/module_status', \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
    }

    /**
     * @param $path
     * @return string
     */
    public function getScopeConfigValues($path){
        return $this->_scopeConfig->getValue($path, \Magento\Store\Model\ScopeInterface::SCOPE_WEBSITE);
    }
    
    public function getAllowedResources()
    {
        $user = $this->authSession->getUser();
        $role = $user->getRole();
        $role_name = $role->getRoleName();
        $resources = $this->aclRetriever->getAllowedResourcesByRole($role->getId());
        if(in_array("Magento_Backend::all",$resources) || in_array("Codilar_KYC::kyc_delete",$resources)){
            return true;
        }
        else{
            return false;
        }
    }
}
