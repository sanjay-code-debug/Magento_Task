<?php

namespace Codilar\KYC\Controller\BusinessKYC;

use Codilar\KYC\Model\KYCManager;
use Magento\Customer\Model\Session;
use Magento\Framework\App\Action\Context;
use Magento\Framework\Data\Form\FormKey\Validator;
use Magento\Framework\Filesystem;
use Magento\Framework\View\Result\PageFactory;
use Magento\MediaStorage\Model\File\UploaderFactory;
use Magento\Sales\Api\OrderRepositoryInterface;
use Magento\Store\Model\StoreManagerInterface;
use Magento\Framework\App\Config\ScopeConfigInterface;
use Psr\Log\LoggerInterface;
use Magento\Framework\Mail\Template\TransportBuilder;

/**
 * Class KYCPost
 * @package Codilar\KYC\Controller\BusinessKYC
 */
class KYCPost extends \Magento\Framework\App\Action\Action
{
    const KYC_TYPE = 2;
    /**
     * @var PageFactory
     */
    protected $resultPageFactory;
    /**
     * @var Validator
     */
    protected $_formKeyValidator;
    /**
     * @var Filesystem\Directory\WriteInterface
     */
    protected $_mediaDirectory;
    /**
     * @var UploaderFactory
     */
    protected $_fileUploaderFactory;
    /**
     * @var OrderRepositoryInterface
     */
    private $orderRepository;
    /**
     * @var Session
     */
    private $session;
    /**
     * @var KYCManager
     */
    private $kycManager;
    /**
     * @var StoreManagerInterface
     */
    private $storeManager;
    /**
     * @var ScopeConfigInterface
     */
    private $_scopeConfig;
    /**
     * @var LoggerInterface
     */
    private $logger;
    /**
     * @var _transportbuilder
     */
    private $_transportbuilder;

    /**
     * KYCPost constructor.
     * @param Context                  $context
     * @param PageFactory              $resultPageFactory
     * @param OrderRepositoryInterface $orderRepository
     * @param Session                  $session
     * @param Validator                $formKeyValidator
     * @param KYCManager               $kycManager
     * @param StoreManagerInterface    $storeManager
     * @param Filesystem               $filesystem
     * @param UploaderFactory          $fileUploaderFactory
     * @throws \Magento\Framework\Exception\FileSystemException
     */
    public function __construct(
        Context $context,
        PageFactory $resultPageFactory,
        OrderRepositoryInterface $orderRepository,
        Session $session,
        Validator $formKeyValidator,
        KYCManager $kycManager,
        StoreManagerInterface $storeManager,
        Filesystem $filesystem,
        LoggerInterface $logger,
        TransportBuilder $_transportbuilder,
        ScopeConfigInterface $_scopeConfig,
        UploaderFactory $fileUploaderFactory
    )
    {
        $this->resultPageFactory = $resultPageFactory;
        parent::__construct($context);
        $this->orderRepository = $orderRepository;
        $this->session = $session;
        $this->_formKeyValidator = $formKeyValidator;
        $this->kycManager = $kycManager;
        $this->storeManager = $storeManager;
        $this->_mediaDirectory = $filesystem->getDirectoryWrite(\Magento\Framework\App\Filesystem\DirectoryList::MEDIA);
        $this->logger = $logger;
        $this->_scopeConfig = $_scopeConfig;
        $this->_transportbuilder = $_transportbuilder;
        $this->_fileUploaderFactory = $fileUploaderFactory;
    }

    /**
     * @return $this|\Magento\Framework\App\ResponseInterface|\Magento\Framework\Controller\ResultInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function execute()
    {
        /** @var \Magento\Backend\Model\View\Result\Redirect $resultRedirect */
        $resultRedirect = $this->resultRedirectFactory->create();
        if (!$this->_formKeyValidator->validate($this->getRequest())) {
            $this->messageManager->addErrorMessage(__("Form key is invalid"));
            return $resultRedirect->setPath('kyc/businesskyc/documents');
        }

        $data = $this->getRequest()->getParams();
        $data['kyc_type'] = self::KYC_TYPE;

        if ($this->session->isLoggedIn()) {

            $customerId = $this->session->getCustomerId();
            $customerEmail = $this->session->getCustomer()->getEmail();
            $data['customer_email'] = $customerEmail;
            $kyc_data = $this->kycManager->getKycDataByCustomerId($customerId);

            if($kyc_data->getCompanyRegistrationFilename()){
                $data['company_registration_filename'] =$kyc_data->getCompanyRegistrationFilename();
                $data['company_registration'] =$kyc_data->getCompanyRegistration();
            }
            else{
                $data['company_registration_filename'] ="";
                $data['company_registration'] ="";
            }
            if($kyc_data->getVatCertificateFilename()){
                $data['vat_certificate_filename'] =$kyc_data->getVatCertificateFilename();
                $data['vat_certificate'] =$kyc_data->getVatCertificate();
            }
            else{
                $data['vat_certificate_filename'] ="";
                $data['vat_certificate'] ="";
            }
            if($kyc_data->getPoaFilename()){
                $data['poa_filename'] =$kyc_data->getPoaFilename();
                $data['poa'] =$kyc_data->getPoaFile();
            }
            else{
                $data['poa_filename'] ="";
                $data['poa'] ="";
            }

            $websiteId = $this->storeManager->getWebsite()->getId();
            $path = "/codilar/kyc_documents/kyc_business/" . $customerId . "/";
            $max_upload_size_mb= $this->_scopeConfig->getValue('kyc/general/kyc_upload_size', \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
            $byte_size = "1024000";
            $max_upload_size = $max_upload_size_mb * $byte_size;
            $type_message = "Only JPG,PNG and PDF file formats allowed";
           $upload_error_message="Maximum upload size is ".$max_upload_size_mb."MB";

            if (array_key_exists('vat_certificate', $_FILES)) {
                if(!empty($_FILES['vat_certificate']['name'])){
                    if ($_FILES['vat_certificate']['size'] < $max_upload_size) {
                        $fileEncodedData = base64_encode(file_get_contents($_FILES['vat_certificate']['tmp_name']));
                        $resultPath = $this->uploadFile('vat_certificate',$path);
                        if ($resultPath) {
                            $data['vat_certificate_filename'] = $resultPath;
                            $data['vat_certificate'] = $fileEncodedData;
                        } else {
                            $this->messageManager->addError($type_message);
                            return $resultRedirect->setPath('kyc/businesskyc/documents');
                        }
                    }else{
                        $this->messageManager->addError($upload_error_message);
                        return $resultRedirect->setPath('kyc/businesskyc/documents');
                    }
                }
            }

            if (array_key_exists('company_registration', $_FILES)) {
                if(!empty($_FILES['company_registration']['name'])){
                    if ($_FILES['company_registration']['size'] < $max_upload_size) {
                        $fileEncodedData = base64_encode(file_get_contents($_FILES['company_registration']['tmp_name']));
                        $resultPath = $this->uploadFile('company_registration',$path);
                        if ($resultPath) {
                            $data['company_registration_filename'] = $resultPath;
                            $data['company_registration'] = $fileEncodedData;
                        } else {
                            $this->messageManager->addError($type_message);
                            return $resultRedirect->setPath('kyc/businesskyc/documents');
                        }
                    }else{
                        $this->messageManager->addError($upload_error_message);
                        return $resultRedirect->setPath('kyc/businesskyc/documents');
                    }
                }
            }
            if (array_key_exists('poa', $_FILES)) {
                if(!empty($_FILES['poa']['name'])){
                    if ($_FILES['poa']['size'] < $max_upload_size) {
                        $fileEncodedData = base64_encode(file_get_contents($_FILES['poa']['tmp_name']));
                        $resultPath = $this->uploadFile('poa',$path);
                        if ($resultPath) {
                            $data['poa_filename'] = $resultPath;
                            $data['poa'] = $fileEncodedData;
                        } else {
                            $this->messageManager->addError($type_message);
                            return $resultRedirect->setPath('kyc/businesskyc/documents');
                        }
                    }else{
                        $this->messageManager->addError($upload_error_message);
                        return $resultRedirect->setPath('kyc/businesskyc/documents');
                    }
                }

            }
                $this->kycManager->saveBusinessKycInformation($customerId, $data,$websiteId);

                $data['customername'] = $this->session->getCustomer()->getName();

                $admintemplateid = $this->_scopeConfig->getValue('kyc/general/kyc_submit', \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
                $adminreceiver = $this->_scopeConfig->getValue('trans_email/ident_general/email', \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
                $this->sendMail($admintemplateid,$adminreceiver,$data);
                $customertemplateid = $this->_scopeConfig->getValue('kyc/general/kyc_customer', \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
                $customerreceiver = $customerEmail;
                $this->sendMail($customertemplateid,$customerreceiver,$data);
                $this->messageManager->addSuccessMessage(__("It will take 24 hrs to verify your documents, please be patient"));
                return $resultRedirect->setPath('kyc/businesskyc/documents');
        }
        else {
            $this->messageManager->addErrorMessage(__("Customer not logged in"));
            return $resultRedirect->setPath('customer/account/');
        }
    }


    /**
     * @param $fileId
     * @param $path
     * @return mixed|null
     */
    protected function uploadFile($fileId,$path)
    {
        $message = "Only JPG,PNG and PDF file formats allowed";
        try {
            $target = $this->_mediaDirectory->getAbsolutePath($path);
            /** @var $uploader \Magento\MediaStorage\Model\File\Uploader */
            $uploader = $this->_fileUploaderFactory->create(['fileId' => $fileId]);
            /** Allowed extension types */
            $uploader->setAllowedExtensions(['jpg', 'jpeg', 'png', 'pdf']);
            /** rename file name if already exists */
            $uploader->setAllowRenameFiles(true);
            /** upload file in folder "$path" */
            $result = $uploader->save($target);
            if ($result['file']) {
            }

        } catch (\Exception $e) {
             $this->messageManager->addError($message);
             return false;
        }
        try{
            $originalFilename = $_FILES[$fileId]['name'];
            $path_parts = pathinfo($_FILES[$fileId]["name"]);
            $extension = $path_parts['extension'];
            $extensionLength = strlen($extension);
            $newFilename = preg_replace("![^a-z0-9]+!i", "_", $originalFilename);
            $filenameLength = strlen($newFilename);
            $completeFilename = substr_replace($newFilename,".",$filenameLength-$extensionLength-1,1);
            return $completeFilename;
        }
        catch (\Exception $e){
            return null;
        }
    }

    public function sendMail($template,$receiver,$data){

        try {
            $storeid = $this->storeManager->getStore()->getId();
            $templateId = $template;
            $customer_email = $receiver;

            $senderName = $this->_scopeConfig->getValue("trans_email/ident_general/name", \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
            $senderEmail = $this->_scopeConfig->getValue("trans_email/ident_general/email", \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
            $sender = [
                'name' => $senderName,
                'email' => $senderEmail,
            ];
            $vars = [
                'data' => $data
            ];
            if ($templateId && $senderEmail) {
                $transport = $this->_transportbuilder
                    ->setTemplateIdentifier($templateId)
                    ->setTemplateOptions(['area' => \Magento\Framework\App\Area::AREA_FRONTEND, 'store' => $storeid])
                    ->setTemplateVars($vars)
                    ->setFrom($sender)
                    ->addTo($customer_email, "Rehandel")
                    ->getTransport();
                $transport->sendMessage();
            }
        }
        catch (\Exception $e){
            $this->logger->debug($e->getMessage());
        }
    }

}
