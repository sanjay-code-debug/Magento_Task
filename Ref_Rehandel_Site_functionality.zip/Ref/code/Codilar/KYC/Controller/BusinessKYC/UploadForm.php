<?php

namespace Codilar\KYC\Controller\BusinessKYC;

use Codilar\KYC\Model\KYCFactory;
use Magento\Customer\Model\Session;
use Magento\Framework\App\Action\Context;
use Magento\Sales\Api\OrderRepositoryInterface;
use Magento\Sales\Model\ResourceModel\Order\Collection;

/**
 * Class Index
 * @package Codilar\KYC\Controller\BusinessKYC
 */
class UploadForm extends \Magento\Framework\App\Action\Action
{
    /**
     * @var Session
     */
    private $customerSession;
    /**
     * @var KYCFactory
     */
    private $KYCFactory;
    /**
     * @var OrderRepositoryInterface
     */
    private $orderRepository;
    /**
     * @var Collection
     */
    private $ordersCollection;

    /**
     * Index constructor.
     * @param Context                  $context
     * @param Session                  $customerSession
     * @param KYCFactory               $KYCFactory
     * @param OrderRepositoryInterface $orderRepository
     * @param Collection               $ordersCollection
     */
    public function __construct(
        Context $context,
        Session $customerSession,
        KYCFactory $KYCFactory,
        OrderRepositoryInterface $orderRepository,
        Collection $ordersCollection
    )
    {
        parent::__construct($context);
        $this->customerSession = $customerSession;
        $this->KYCFactory = $KYCFactory;
        $this->orderRepository = $orderRepository;
        $this->ordersCollection = $ordersCollection;
    }

    /**
     * @return \Magento\Framework\App\ResponseInterface|\Magento\Framework\Controller\ResultInterface|void
     */
    public function execute()
    {
        /** @var \Magento\Backend\Model\View\Result\Redirect $resultRedirect */
        $resultRedirect = $this->resultRedirectFactory->create();
        if ($this->customerSession->isLoggedIn()) {
            $orderId = $this->getRequest()->getParam('order_id');
            $sessionCustomerId = $this->customerSession->getCustomerId();
            $kycData = $this->getKycDataByOrderId($orderId, $sessionCustomerId);
            if ($kycData) {
                if ($kycData['vat_certificate_filename'] || $kycData['company_registration_filename'] || $kycData['poa_filename']) {
                    $this->messageManager->addErrorMessage(__("Business KYC Documents uploaded already"));
                    return $resultRedirect->setPath('kyc/businesskyc/documents');
                } else {
                    $this->_view->loadLayout();
                    $this->_view->renderLayout();
                }
            } elseif (!$this->isOrderExists($orderId, $sessionCustomerId)) {
                $this->messageManager->addErrorMessage(__("No orders found to upload KYC Documents"));
                return $resultRedirect->setPath('kyc/businesskyc/documents');
            } else {
                $this->_view->loadLayout();
                $this->_view->renderLayout();
            }
        } else {
            $this->messageManager->addErrorMessage(__("Please login to upload KYC Documents"));
            return $resultRedirect->setPath('/');
        }
    }

    /**
     * @param $orderId
     * @param $customerId
     * @return bool
     */
    public function getKycDataByOrderId($orderId, $customerId)
    {
        $collection = $this->KYCFactory->create()->getCollection()
            ->addFieldToFilter('order_id', $orderId)
            ->addFieldToFilter('customer_id', $customerId)
            ->getFirstItem();
        if ($collection->getData()) {
            return true;
        }
        return false;
    }

    /**
     * @param $orderId
     * @param $customerId
     * @return bool
     */
    public function isOrderExists($orderId, $customerId)
    {
        $collection = $this->ordersCollection
            ->addFieldToFilter('entity_id', $orderId)
            ->addFieldToFilter('customer_id', $customerId)
            ->load();

        if ($collection->getData()) {
            return true;
        } else {
            return false;
        }
    }
}