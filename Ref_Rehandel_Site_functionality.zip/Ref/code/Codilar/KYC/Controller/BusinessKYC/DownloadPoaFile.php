<?php

namespace Codilar\KYC\Controller\BusinessKYC;

use Magento\Framework\App\Action\Context;
use Magento\Framework\View\Result\PageFactory;
use Magento\Store\Model\StoreManagerInterface;
use Magento\Framework\Filesystem\DirectoryList;
use \Codilar\KYC\Helper\Data as KycHelper;
use Codilar\KYC\Model\KYCManager;

/**
 * Class DownloadPoaFile
 * @package Codilar\KYC\Controller\BusinessKYC
 */
class DownloadPoaFile extends \Magento\Framework\App\Action\Action
{
    /**
     * @var PageFactory
     */
    protected $resultPageFactory;
    /**
     * @var StoreManagerInterface
     */
    private $storeManager;
    /**
     * @var DirectoryList
     */
    private $directoryList;
    /**
     * @var KycHelper
     */
    private $kycHelper;
    /**
     * @var KYCManager
     */
    private $KYCManager;

    /**
     * DownloadPoaFile constructor.
     * @param Context $context
     * @param PageFactory $resultPageFactory
     * @param StoreManagerInterface $storeManager
     * @param DirectoryList $directoryList
     * @param KycHelper $kycHelper
     * @param KYCManager $KYCManager
     */
    public function __construct(
        Context $context,
        PageFactory $resultPageFactory,
        StoreManagerInterface $storeManager,
        DirectoryList $directoryList,
        KycHelper $kycHelper,
        KYCManager $KYCManager
    )
    {
        $this->resultPageFactory = $resultPageFactory;
        parent::__construct($context);
        $this->storeManager = $storeManager;
        $this->directoryList = $directoryList;
        $this->kycHelper = $kycHelper;
        $this->KYCManager = $KYCManager;
    }

    public function execute()
    {
        $kycId = $this->getRequest()->getParam('kyc_id');
        $rootPath = $this->directoryList->getRoot();
        try{
            $kycData = $this->KYCManager->getKycDataByKycId($kycId);
            $base64 = $kycData->getPoa();
            $fileDecodedData = base64_decode($base64);
            $filename = $kycData->getPoaFilename();
            $oldFileDir = $rootPath."/pub/media/codilar/kyc_documents/business/";
            $files = glob($oldFileDir."*"); // get all file names
            foreach($files as $unlinkFile){ // iterate files
                if(is_file($unlinkFile))
                    unlink($unlinkFile); // delete file
            }
            if (!file_exists($oldFileDir)) {
                if (!mkdir($oldFileDir, 0777, true)) {
                    die('Failed to create folders...');
                }
            }
            file_put_contents($oldFileDir.$filename, $fileDecodedData);
            $filepath = $oldFileDir.$filename;
            if (file_exists($filepath)) {

                header('Content-Description: File Transfer');
                header('Content-Type: application/octet-stream');
                header('Content-Disposition: attachment; filename="'.basename($filepath).'"' );
                header('Expires: 0');
                header('Cache-Control: must-revalidate, post-check=0, pre-check=0');
                header('Pragma: public');
                header('Content-Length: ' . filesize($filepath));
                ob_clean();
                flush();
                readfile($filepath);
//                echo $filepath;
//                return;
            }
        }
        catch (\Exception $e){

        }
        return;
        //$this->downloadFile("vat_certificate");
    }

    /**
     * @param $fileId
     * @return null|string
     */
    protected function downloadFile($fileId)
    {
        $rootPath = $this->directoryList->getRoot();
        $filePath = $this->kycHelper->getScopeConfigValues("kyc/general/".$fileId);
        $file = $rootPath . "/pub/media/codilar/kyc_documents/".$filePath;
        if (file_exists($file)) {
            header('Content-Description: File Transfer');
            header('Content-Type: application/octet-stream');
            header('Content-Disposition: attachment; filename="'.basename($file).'"');
            header('Expires: 0');
            header('Cache-Control: must-revalidate');
            header('Pragma: public');
            header('Content-Length: ' . filesize($file));
            readfile($file);
//            echo $file;
//            return;
        }
        return;
    }

    /**
     * @return int
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function getWebsiteId(){
        return $this->storeManager->getWebsite()->getId();
    }

}