<?php

namespace Codilar\KYC\Controller\BusinessKYC;

use Magento\Customer\Model\Session;
use Magento\Framework\App\Action\Context;

/**
 * Class Index
 * @package Codilar\KYC\Controller\KYC
 */
class Documents extends \Magento\Framework\App\Action\Action
{
    /**
     * @var Session
     */
    private $customerSession;

    /**
     * Index constructor.
     * @param Context $context
     * @param Session $customerSession
     */
    public function __construct(
        Context $context,
        Session $customerSession
    )
    {
        parent::__construct($context);
        $this->customerSession = $customerSession;
    }

    /**
     * @return \Magento\Framework\App\ResponseInterface|\Magento\Framework\Controller\ResultInterface|void
     */
    public function execute()
    {
        /** @var \Magento\Backend\Model\View\Result\Redirect $resultRedirect */
        $resultRedirect = $this->resultRedirectFactory->create();
        if ($this->customerSession->isLoggedIn()) {
            $this->_view->loadLayout();
            $this->_view->renderLayout();
        } else {
            $this->messageManager->addErrorMessage(__("Please login to upload KYC Documents"));
            return $resultRedirect->setPath('/');
        }
    }
}