<?php

namespace Codilar\KYC\Controller\BusinessKYC;

use Magento\Framework\App\Action\Context;
use Magento\Framework\View\Result\PageFactory;
use Magento\Store\Model\StoreManagerInterface;
use Magento\Framework\Filesystem\DirectoryList;
use \Codilar\KYC\Helper\Data as KycHelper;
use Magento\Framework\Registry;

/**
 * Class Vat
 * @package Codilar\KYC\Controller\BusinessKYC
 */
class Vat extends \Magento\Framework\App\Action\Action
{
    /**
     * @var PageFactory
     */
    protected $resultPageFactory;
    /**
     * @var StoreManagerInterface
     */
    private $storeManager;
    /**
     * @var DirectoryList
     */
    private $directoryList;
    /**
     * @var KycHelper
     */
    private $kycHelper;
    /**
     * @var Registry
     */
    private $registry;

    /**
     * Vat constructor.
     * @param Context $context
     * @param PageFactory $resultPageFactory
     * @param StoreManagerInterface $storeManager
     * @param DirectoryList $directoryList
     * @param KycHelper $kycHelper
     * @param Registry $registry
     */
    public function __construct(
        Context $context,
        PageFactory $resultPageFactory,
        StoreManagerInterface $storeManager,
        DirectoryList $directoryList,
        KycHelper $kycHelper,
        Registry $registry
    )
    {
        $this->resultPageFactory = $resultPageFactory;
        parent::__construct($context);
        $this->storeManager = $storeManager;
        $this->directoryList = $directoryList;
        $this->kycHelper = $kycHelper;
        $this->registry = $registry;
    }

    public function execute()
    {
        $rootPath = $this->directoryList->getRoot();
        $kycData = $this->getKYCData();
        $this->downloadFile($kycData->getVatCertificate());
        $base64 = $kycData->getVatCertificate();
        $fileDecodedData = base64_decode($base64);
        $file = $kycData->getVatCertificateFilename();
        file_put_contents($rootPath."/pub/media/codilar/".$file, $fileDecodedData);
        $filepath = $rootPath."pub/media/codilar/".$file;
        if (file_exists($filepath)) {
            header('Content-Description: File Transfer');
            header('Content-Type: application/octet-stream');
            header('Content-Disposition: attachment; filename="'.basename($filepath).'"');
            header('Expires: 0');
            header('Cache-Control: must-revalidate');
            header('Pragma: public');
            header('Content-Length: ' . filesize($filepath));
            readfile($filepath);
//            echo $filepath;
            unlink($filepath);
            return;
        }
        return;
    }

    /**
     * @param $base64
     */
    protected function downloadFile($base64)
    {

    }

    /**
     * @return int
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function getWebsiteId(){
        return $this->storeManager->getWebsite()->getId();
    }

    /**
     * @return mixed
     */
    public function getKYCData()
    {
        $kyc = $this->registry->registry("ws_kyc_registry");
        if ($kyc) {
            return $kyc;
        } else {
            return null;
        }
    }
}