<?php

namespace Codilar\KYC\Controller\Adminhtml\BusinessKYC;

use Magento\Backend\App\Action;
use Magento\Framework\View\Result\PageFactory;
use Magento\Framework\Filesystem\DirectoryList;
use Magento\Framework\Registry;
use Codilar\KYC\Model\KYCManager;

/**
 * Class Poa
 * @package Codilar\KYC\Controller\Adminhtml\BusinessKYC
 */
class Poa extends Action
{
    /**
     * @var PageFactory
     */
    protected $_pageFactory;
    /**
     * @var DirectoryList
     */
    private $directoryList;
    /**
     * @var Registry
     */
    private $registry;
    /**
     * @var KYCManager
     */
    private $KYCManager;

    /**
     * Poa constructor.
     * @param Action\Context $context
     * @param PageFactory $pageFactory
     * @param DirectoryList $directoryList
     * @param Registry $registry
     * @param KYCManager $KYCManager
     */
    public function __construct(
        Action\Context $context,
        PageFactory $pageFactory,
        DirectoryList $directoryList,
        Registry $registry,
        KYCManager $KYCManager
    )
    {
        $this->_pageFactory = $pageFactory;
        $this->directoryList = $directoryList;
        $this->registry = $registry;
        parent::__construct($context);
        $this->KYCManager = $KYCManager;
    }

    /**
     * @return \Magento\Framework\App\ResponseInterface|\Magento\Framework\Controller\ResultInterface|void
     */
    public function execute()
    {
        $kycId = $this->getRequest()->getParam('kyc_id');
        $rootPath = $this->directoryList->getRoot();
        try{
            $kycData = $this->KYCManager->getKycDataByKycId($kycId);
            $base64 = $kycData->getPoa();
            $fileDecodedData = base64_decode($base64);
            $file = $kycData->getPoaFilename();
            $oldFileDir = $rootPath."/pub/media/codilar/kyc_documents/business/";
            $files = glob($oldFileDir."*"); // get all file names
            foreach($files as $unlinkFile){ // iterate files
                if(is_file($unlinkFile))
                    unlink($unlinkFile); // delete file
            }
            if (!file_exists($oldFileDir)) {
                if (!mkdir($oldFileDir, 0777, true)) {
                    die('Failed to create folders...');
                }
            }
            file_put_contents($oldFileDir.$file, $fileDecodedData);
            $filepath = $oldFileDir.$file;
            if (file_exists($filepath)) {
                header('Content-Description: File Transfer');
                header('Content-Type: application/octet-stream');
                header('Content-Disposition: attachment; filename="'.basename($filepath).'"' );
                header('Expires: 0');
                header('Cache-Control: must-revalidate, post-check=0, pre-check=0');
                header('Pragma: public');
                header('Content-Length: ' . filesize($filepath));
                ob_clean();
                flush();
                readfile($filepath);
//                echo $filepath;
//                return;
            }
        }
        catch (\Exception $e){

        }
        return;
    }
}
