<?php

namespace Codilar\KYC\Controller\Adminhtml\KYC;

use Codilar\KYC\Model\KYCFactory;
use Codilar\KYC\Model\KYCManager;
use Magento\Backend\App\Action;

/**
 * Class Delete
 * @package Codilar\KYC\Controller\Adminhtml\KYC
 */
class Delete extends Action
{
    /**
     * @var KYCFactory
     */
    protected $_kycFactory;
    /**
     * @var KYCManager
     */
    private $kycManager;

    /**
     * Delete constructor.
     * @param Action\Context $context
     * @param KYCFactory     $kycFactory
     * @param KYCManager     $kycManager
     */
    public function __construct(
        Action\Context $context,
        KYCFactory $kycFactory,
        KYCManager $kycManager
    )
    {
        $this->_kycFactory = $kycFactory;
        parent::__construct($context);
        $this->kycManager = $kycManager;
    }

    /**
     * Delete action
     *
     * @return \Magento\Framework\Controller\ResultInterface
     */
    public function execute()
    {
        $id = $this->getRequest()->getParam('id');
        /** @var \Magento\Backend\Model\View\Result\Redirect $resultRedirect */
        $resultRedirect = $this->resultRedirectFactory->create();
        if ($id) {
            try {
                $isIdProofUploaded = false;
                $isAddressProofUploaded = false;
                $kyc = $this->_kycFactory->create()->load($id);
                $kyc->delete();
                $this->messageManager->addSuccess(__('The KYC has been deleted.'));
                return $resultRedirect->setPath('*/*/');
            } catch (\Exception $e) {
                $this->messageManager->addError($e->getMessage());
                return $resultRedirect->setPath('*/*/edit', ['id' => $id]);
            }
        }
        $this->messageManager->addError(__('We can\'t find the KYC to delete.'));
        return $resultRedirect->setPath('*/*/');
    }
        /**
     * @return bool
     */
    protected function _isAllowed()
    {
        return $this->_authorization->isAllowed("Codilar_KYC::kyc_delete");
    }
}
