<?php

namespace Codilar\KYC\Controller\Adminhtml\KYC;

use Codilar\KYC\Model\KYCFactory;
use Codilar\KYC\Model\KYCManager;
use Codilar\KYC\Model\ResourceModel\KYC\CollectionFactory;
use Magento\Backend\App\Action\Context;
use Magento\Framework\App\ResponseInterface;
use Magento\Framework\Controller\ResultFactory;
use Magento\Ui\Component\MassAction\Filter;

/**
 * Class MassDelete
 * @package Codilar\KYC\Controller\Adminhtml\KYC
 */
class MassDelete extends \Magento\Backend\App\Action
{
    /**
     * Massactions filter
     *
     * @var Filter
     */
    protected $filter;

    /**
     * @var CollectionFactory
     */
    protected $collectionFactory;
    /**
     * @var KYCFactory
     */
    protected $_kycFactory;
    /**
     * @var KYCManager
     */
    private $kycManager;

    /**
     * MassDelete constructor.
     * @param Context           $context
     * @param Filter            $filter
     * @param CollectionFactory $collectionFactory
     * @param KYCFactory        $kycFactory
     * @param KYCManager        $kycManager
     */
    public function __construct(
        Context $context,
        Filter $filter,
        CollectionFactory $collectionFactory,
        KYCFactory $kycFactory,
        KYCManager $kycManager
    )
    {
        $this->filter = $filter;
        $this->collectionFactory = $collectionFactory;
        $this->_kycFactory = $kycFactory;
        parent::__construct($context);
        $this->kycManager = $kycManager;
    }

    /**
     * @return ResponseInterface|\Magento\Framework\Controller\ResultInterface
     * @throws \Exception
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function execute()
    {
        $collection = $this->filter->getCollection($this->collectionFactory->create());
        $collectionSize = 0;
        foreach ($collection->getItems() as $kycItem) {
            $isIdProofUploaded = false;
            $isAddressProofUploaded = false;
            $kyc = $this->_kycFactory->create()->load($kycItem->getId());
            $kyc->delete();
            $collectionSize++;
        }
        $this->messageManager->addSuccess(
            __('A total of %1 kyc(s) have been deleted.', $collectionSize)
        );
        return $this->resultFactory->create(ResultFactory::TYPE_REDIRECT)->setPath('kyc/kyc/index');
    }

    protected function _isAllowed()
    {
        return $this->_authorization->isAllowed("Codilar_KYC::kyc_delete");
    }
}
