<?php

namespace Codilar\KYC\Controller\Adminhtml\KYC;

use Codilar\KYC\Model\KYCFactory;
use Codilar\KYC\Model\KYCManager;
use Magento\Backend\App\Action;
use Magento\Customer\Api\CustomerRepositoryInterface;
use Magento\Framework\App\Request\DataPersistorInterface;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Filesystem;
use Magento\MediaStorage\Model\File\UploaderFactory;
use Magento\Sales\Model\ResourceModel\Order\Collection;
use Magento\Store\Model\StoreManagerInterface;
use Magento\Framework\App\Config\ScopeConfigInterface;
use Psr\Log\LoggerInterface;
use Magento\Framework\Mail\Template\TransportBuilder;

use Magento\Framework\App\PageCache\Version;
use Magento\Framework\App\Cache\TypeListInterface;
use Magento\Framework\App\Cache\Frontend\Pool;
/**
 * Class Save
 * @package Codilar\KYC\Controller\Adminhtml\KYC
 */
class Save extends \Magento\Backend\App\Action
{
    /**
     * @var DataPersistorInterface
     */
    protected $dataPersistor;
    /**
     * @var KYCFactory
     */
    protected $_kycModel;
    /**
     * @var Filesystem\Directory\WriteInterface
     */
    protected $_mediaDirectory;
    /**
     * @var UploaderFactory
     */
    protected $_fileUploaderFactory;
    /**
     * @var StoreManagerInterface
     */
    private $storeManager;
    /**
     * @var CustomerRepositoryInterface
     */
    private $customerRepository;
    /**
     * @var Collection
     */
    private $ordersCollection;
    /**
     * @var KYCManager
     */
    private $KYCManager;
    /**
     * @var ScopeConfigInterface
     */
    private $_scopeConfig;
    /**
     * @var LoggerInterface
     */
    private $logger;
    /**
     * @var _transportbuilder
     */
    private $_transportbuilder;
    /**
     * @var _cacheTypeList
     */
    protected $cacheTypeList;
    /**
     * @var _cacheFrontendPool
     */
    protected $cacheFrontendPool;

    /**
     * Save constructor.
     * @param Action\Context              $context
     * @param DataPersistorInterface      $dataPersistor
     * @param KYCFactory                  $feedsFactory
     * @param StoreManagerInterface       $storeManager
     * @param CustomerRepositoryInterface $customerRepository
     * @param Collection                  $ordersCollection
     * @param Filesystem                  $filesystem
     * @param UploaderFactory             $fileUploaderFactory
     * @param KYCManager                  $KYCManager
     * @throws \Magento\Framework\Exception\FileSystemException
     */
    public function __construct(
        Action\Context $context,
        DataPersistorInterface $dataPersistor,
        KYCFactory $feedsFactory,
        StoreManagerInterface $storeManager,
        CustomerRepositoryInterface $customerRepository,
        Collection $ordersCollection,
        Filesystem $filesystem,
        LoggerInterface $logger,
        TransportBuilder $_transportbuilder,
        ScopeConfigInterface $_scopeConfig,
        UploaderFactory $fileUploaderFactory,
        KYCManager $KYCManager,
        TypeListInterface $cacheTypeList,
        Pool $cacheFrontendPool
    )
    {
        $this->_kycModel = $feedsFactory;
        $this->dataPersistor = $dataPersistor;
        parent::__construct($context);
        $this->storeManager = $storeManager;
        $this->customerRepository = $customerRepository;
        $this->ordersCollection = $ordersCollection;
        $this->_mediaDirectory = $filesystem->getDirectoryWrite(\Magento\Framework\App\Filesystem\DirectoryList::MEDIA);
        $this->logger = $logger;
        $this->_scopeConfig = $_scopeConfig;
        $this->_transportbuilder = $_transportbuilder;
        $this->_fileUploaderFactory = $fileUploaderFactory;
        $this->KYCManager = $KYCManager;
        $this->cacheTypeList = $cacheTypeList;
        $this->cacheFrontendPool = $cacheFrontendPool;
    }

    /**
     * @return $this|\Magento\Framework\App\ResponseInterface|\Magento\Framework\Controller\ResultInterface
     */
    public function execute()
    {
        $data = $this->getRequest()->getPostValue();
        /** @var \Magento\Backend\Model\View\Result\Redirect $resultRedirect */
        $resultRedirect = $this->resultRedirectFactory->create();
        if ($data) {
            if(!isset($data['customer_id'])){
                $temp = $data;
                $websiteId = $this->storeManager->getWebsite()->getId();
                $data = [];
                $cust = $this->customerRepository->get($temp['customer_email'],$websiteId);
                $customer = $this->customerRepository->getById($cust->getId());
                $customer->setCustomAttribute('abn',$temp['abn'])
                         ->setCustomAttribute('gst_number',$temp['gst_number']);
                $this->customerRepository->save($customer);

                $data['customer_id'] = $cust->getId();
                $data['kyc_type'] = 2;
                $data['customer_email'] = $temp['customer_email'];
                $data['gst_number'] = $temp['gst_number'];
                $data['is_kyc_verify'] = $temp['is_kyc_verify'];
                $data['website_id'] = $temp['website_id'];
                $data['company_registration'] = base64_encode(file_get_contents($temp['company_registration'][0]['url']));
                $data['company_registration_filename'] = $temp['company_registration'][0]['name'];
                $data['vat_certificate'] = base64_encode(file_get_contents($temp['vat_certificate'][0]['url']));
                $data['vat_certificate_filename'] = $temp['vat_certificate'][0]['name'];
            }
            /** @var \Codilar\KYC\Model\KYC $model */
            $model = $this->_kycModel->create();
            if (!$this->checkCustomerExistsById($data['customer_id'])) {
                $this->messageManager->addErrorMessage(__($data['customer_id'] . " - Customer Id Doesn't Exists."));
                return $resultRedirect->setPath('*/*/');
            }
            if (empty($data['id'])) {
                $data['id'] = null;
            }
            $id = $this->getRequest()->getParam('id');
            if ($id) {
                $model->getResource()->load($model, $id);
            }
            $data['id_proof'] = "";
            $data['address_proof'] = "";
            $path = "/codilar/kyc_documents/" . $data['customer_id'] . "/";
            $model->setData($data);
            try {
                $model->getResource()->save($model);
                $this->KYCManager->setKycUploaded($data['customer_id']);
                $this->dataPersistor->clear('codilar_kyc_documents');
                $this->messageManager->addSuccessMessage(__('You saved the KYC Documents.'));
                if($data['is_kyc_verify']){
                    $customer = $this->customerRepository->getById($data['customer_id']);
                    $data['customername'] = $customer->getFirstname().' '.$customer->getLastname();
                    $customertemplateid = $this->_scopeConfig->getValue('kyc/general/kyc_confirm', \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
                    $customerreceiver = $customer->getEmail();
                    $this->sendMail($customertemplateid,$customerreceiver,$data);
                }
                $this->flushCache();
                if ($this->getRequest()->getParam('back')) {
                    return $resultRedirect->setPath('*/*/edit', ['id' => $model->getId(), '_current' => true]);
                }
                return $resultRedirect->setPath('*/*/');
            } catch (LocalizedException $e) {
                $this->messageManager->addErrorMessage($e->getMessage());
            } catch (\Exception $e) {
                $this->messageManager->addExceptionMessage($e, __($e->getMessage()));
            }
            $this->dataPersistor->set('codilar_kyc_documents', $data);
            return $resultRedirect->setPath('*/*/edit', ['id' => $this->getRequest()->getParam('id')]);
        }
        return $resultRedirect->setPath('*/*/');
    }

    public function flushCache()
    {
        $type = 'block_html';
        $this->cacheTypeList->cleanType($type);
        foreach ($this->cacheFrontendPool as $cacheFrontend) {
            $cacheFrontend->getBackend()->clean();
        }
    }
    /**
     * @param $id
     * @return bool
     */
    public function checkCustomerExistsById($id)
    {
        try {
            $customer = $this->customerRepository->getById($id);
            if ($customer->getId()) {
                return true;
            }
        } catch (\Exception $e) {
            return false;
        }
    }

    /**
     * @param $orderId
     * @param $customerId
     * @return bool
     */

    /**
     * @param $path
     * @param $fileId
     * @return null|string
     */
    protected function uploadFile($path, $fileId)
    {
        try {
            $target = $this->_mediaDirectory->getAbsolutePath($path);
            /** @var $uploader \Magento\MediaStorage\Model\File\Uploader */
            $uploader = $this->_fileUploaderFactory->create(['fileId' => $fileId]);
            /** Allowed extension types */
            $uploader->setAllowedExtensions(['jpg', 'jpeg', 'png', 'pdf']);
            /** rename file name if already exists */
            $uploader->setAllowRenameFiles(true);
            /** upload file in folder "$path" */
            $result = $uploader->save($target);
            if ($result['file']) {
                return $path . $result['file'];
            }
        } catch (\Exception $e) {
            $this->messageManager->addError($e->getMessage());
            return null;
        }
    }

    /**
     * @return bool
     */
    protected function _isAllowed()
    {
        return $this->_authorization->isAllowed("Codilar_KYC::kyc_save");
    }

    public function sendMail($template,$receiver,$data){

        try {
            $storeid = $this->storeManager->getStore()->getId();
            $templateId = $template;
            $customer_email = $receiver;

            $senderName = $this->_scopeConfig->getValue("trans_email/ident_general/name", \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
            $senderEmail = $this->_scopeConfig->getValue("trans_email/ident_general/email", \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
            $sender = [
                'name' => $senderName,
                'email' => $senderEmail,
            ];
            $vars = [
                'data' => $data
            ];
            if ($templateId && $senderEmail) {
                $transport = $this->_transportbuilder
                    ->setTemplateIdentifier($templateId)
                    ->setTemplateOptions(['area' => \Magento\Framework\App\Area::AREA_FRONTEND, 'store' => $storeid])
                    ->setTemplateVars($vars)
                    ->setFrom($sender)
                    ->addTo($customer_email, "Rehandel")
                    ->getTransport();
                $transport->sendMessage();
            }
        }
        catch (\Exception $e){
            $this->logger->debug($e->getMessage());
        }
    }
}
