<?php

namespace Codilar\KYC\Controller\Adminhtml\Uploader;

use Codilar\KYC\Model\KYCManager;
use Magento\Backend\App\Action;
use Magento\Framework\File\Csv;

/**
 * Class Save
 * @package Codilar\KYC\Controller\Adminhtml\Uploader
 */
class Save extends Action
{
    /**
     * @var \Magento\Store\Model\StoreManagerInterface
     */
    protected $_storeManager;

    /**
     * @var Csv
     */
    protected $_csvProcessor;
    /**
     * @var KYCManager
     */
    private $kycManager;


    /**
     * Save constructor.
     * @param \Magento\Store\Model\StoreManagerInterface $storeManager
     * @param Action\Context                             $context
     * @param KYCManager                                 $kycManager
     * @param Csv                                        $csvProcessor
     */
    public function __construct(
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        Action\Context $context,
        KYCManager $kycManager,
        Csv $csvProcessor
    )
    {
        $this->_storeManager = $storeManager;
        parent::__construct($context);
        $this->_csvProcessor = $csvProcessor;
        $this->kycManager = $kycManager;
    }

    /**
     * @desc Get the csv file, read the contents and insert to the database if not inserted.
     */
    public function execute()
    {
        $file = $_FILES['csv'];
        if (!$file) {
            $this->messageManager->addError(__('Invalid file upload attempt!'));
            $this->_redirect('*/*/index');
        } else {
            $importRawData = $this->_csvProcessor->getData($file['tmp_name']);
            $headerNames = $importRawData[0];
            unset($importRawData[0]);
            $kycData = [];
            foreach ($importRawData as $kyc) {
                try {
                    $this->kycManager->saveFeedbackReviewMagentoOne($kyc);
                } catch (\Exception $e) {
                    $this->messageManager->addError($e->getMessage());
                }
            }
            $this->messageManager->addSuccess('Feedbacks has been uploaded successfully!');
            $this->_redirect('kyc/uploader/newcsv');
        }
    }

    /**
     * Get store identifier
     *
     * @return  int
     */
    public function getStoreId()
    {
        return $this->_storeManager->getStore()->getId();
    }

}