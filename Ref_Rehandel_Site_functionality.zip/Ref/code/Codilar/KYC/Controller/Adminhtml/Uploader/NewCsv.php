<?php

namespace Codilar\KYC\Controller\Adminhtml\Uploader;

use Magento\Backend\App\Action;
use Magento\Framework\View\Result\PageFactory;

/**
 * Class NewCsv
 * @package Codilar\KYC\Controller\Adminhtml\Uploader
 */
class NewCsv extends Action
{
    /**
     * @var PageFactory
     */
    protected $_pageFactory;

    /**
     * NewCsv constructor.
     * @param Action\Context $context
     * @param PageFactory    $pageFactory
     */
    public function __construct(
        Action\Context $context,
        PageFactory $pageFactory
    )
    {
        $this->_pageFactory = $pageFactory;
        parent::__construct($context);
    }

    /**
     * @return \Magento\Framework\View\Result\Page
     */
    public function execute()
    {
        return $this->_pageFactory->create();
    }
}
