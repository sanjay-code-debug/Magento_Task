<?php

namespace Codilar\KYC\Controller\KYC;

use Codilar\KYC\Model\KYCManager;
use Magento\Customer\Model\Session;
use Magento\Framework\App\Action\Context;
use Magento\Framework\Data\Form\FormKey\Validator;
use Magento\Framework\Filesystem;
use Magento\Framework\View\Result\PageFactory;
use Magento\MediaStorage\Model\File\UploaderFactory;
use Magento\Sales\Api\OrderRepositoryInterface;
use Magento\Store\Model\StoreManagerInterface;

/**
 * Class KYCPost
 * @package Codilar\KYC\Controller\KYC
 */
class KYCPost extends \Magento\Framework\App\Action\Action
{
    /**
     * @var PageFactory
     */
    protected $resultPageFactory;
    /**
     * @var Validator
     */
    protected $_formKeyValidator;
    /**
     * @var Filesystem\Directory\WriteInterface
     */
    protected $_mediaDirectory;
    /**
     * @var UploaderFactory
     */
    protected $_fileUploaderFactory;
    /**
     * @var OrderRepositoryInterface
     */
    private $orderRepository;
    /**
     * @var Session
     */
    private $session;
    /**
     * @var KYCManager
     */
    private $kycManager;
    /**
     * @var StoreManagerInterface
     */
    private $storeManager;

    /**
     * KYCPost constructor.
     * @param Context                  $context
     * @param PageFactory              $resultPageFactory
     * @param OrderRepositoryInterface $orderRepository
     * @param Session                  $session
     * @param Validator                $formKeyValidator
     * @param KYCManager               $kycManager
     * @param StoreManagerInterface    $storeManager
     * @param Filesystem               $filesystem
     * @param UploaderFactory          $fileUploaderFactory
     * @throws \Magento\Framework\Exception\FileSystemException
     */
    public function __construct(
        Context $context,
        PageFactory $resultPageFactory,
        OrderRepositoryInterface $orderRepository,
        Session $session,
        Validator $formKeyValidator,
        KYCManager $kycManager,
        StoreManagerInterface $storeManager,
        Filesystem $filesystem,
        UploaderFactory $fileUploaderFactory
    )
    {
        $this->resultPageFactory = $resultPageFactory;
        parent::__construct($context);
        $this->orderRepository = $orderRepository;
        $this->session = $session;
        $this->_formKeyValidator = $formKeyValidator;
        $this->kycManager = $kycManager;
        $this->storeManager = $storeManager;
        $this->_mediaDirectory = $filesystem->getDirectoryWrite(\Magento\Framework\App\Filesystem\DirectoryList::MEDIA);
        $this->_fileUploaderFactory = $fileUploaderFactory;
    }

    /**
     * @return $this|\Magento\Framework\App\ResponseInterface|\Magento\Framework\Controller\ResultInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function execute()
    {
        /** @var \Magento\Backend\Model\View\Result\Redirect $resultRedirect */
        $resultRedirect = $this->resultRedirectFactory->create();
        if (!$this->_formKeyValidator->validate($this->getRequest())) {
            $this->messageManager->addErrorMessage(__("Form key is invalid"));
            return $resultRedirect->setPath('kyc/businesskyc/documents');
        }
        $data = $this->getRequest()->getParams();
        $data['id_proof'] = "";
        $data['address_proof'] = "";
        $data['kyc_type'] = 1;
        if ($this->session->isLoggedIn()) {
            $customerId = $this->session->getCustomerId();
            $websiteId = $this->storeManager->getWebsite()->getId();
            $path = "/codilar/kyc_documents/" . $data['order_id'] . "/";
            if (strlen($data['indian_id_proof_field']) > 1) {
                if (array_key_exists($data['indian_id_proof_field'], $_FILES)) {
                    if (array_key_exists('size', $_FILES[$data['indian_id_proof_field']])) {
                        if ($_FILES[$data['indian_id_proof_field']]['size'] > 0) {
                            $resultPath = $this->uploadFile($path, $data['indian_id_proof_field']);
                            if ($resultPath) {
                                $data['id_proof'] = $resultPath;
                            } else {
                                $this->messageManager->addErrorMessage(__("Error while uploading the document, please try again"));
                                return $resultRedirect->setPath('kyc/kyc/uploadform/order_id/' . $data['order_id'] . "/customer_id/" . $data['customer_id']);
                            }
                        }
                    }
                }
                if ($data['indian_id_proof_field'] == "file_pan") {
                    if (strlen($data['indian_address_proof_field']) > 0) {
                        if (array_key_exists($data['indian_address_proof_field'], $_FILES)) {
                            if (array_key_exists('size', $_FILES[$data['indian_address_proof_field']])) {
                                if ($_FILES[$data['indian_address_proof_field']]['size'] > 0) {
                                    $resultPath = $this->uploadFile($path, $data['indian_address_proof_field']);
                                    if ($resultPath) {
                                        $data['address_proof'] = $resultPath;
                                    } else {
                                        $this->messageManager->addErrorMessage(__("Error while uploading the document, please try again"));
                                        return $resultRedirect->setPath('kyc/kyc/uploadform/order_id/' . $data['order_id'] . "/customer_id/" . $data['customer_id']);
                                    }
                                } else {
                                    $this->messageManager->addErrorMessage(__("Address need to be uploaded for Pan card"));
                                    return $resultRedirect->setPath('kyc/kyc/uploadform/order_id/' . $data['order_id'] . "/customer_id/" . $data['customer_id']);
                                }
                            } else {
                                $this->messageManager->addErrorMessage(__("Address need to be uploaded for Pan card"));
                                return $resultRedirect->setPath('kyc/kyc/uploadform/order_id/' . $data['order_id'] . "/customer_id/" . $data['customer_id']);
                            }
                        } else {
                            $this->messageManager->addErrorMessage(__("Address need to be uploaded for Pan card"));
                            return $resultRedirect->setPath('kyc/kyc/uploadform/order_id/' . $data['order_id'] . "/customer_id/" . $data['customer_id']);
                        }
                    } else {
                        $this->messageManager->addErrorMessage(__("Address need to be uploaded for Pan card"));
                        return $resultRedirect->setPath('kyc/kyc/uploadform/order_id/' . $data['order_id'] . "/customer_id/" . $data['customer_id']);
                    }
                } else {
                    if (strlen($data['indian_address_proof_field']) > 0) {
                        if (array_key_exists($data['indian_address_proof_field'], $_FILES)) {
                            if (array_key_exists('size', $_FILES[$data['indian_address_proof_field']])) {
                                if ($_FILES[$data['indian_address_proof_field']]['size'] > 0) {
                                    $resultPath = $this->uploadFile($path, $data['indian_address_proof_field']);
                                    if ($resultPath) {
                                        $data['address_proof'] = $resultPath;
                                    } else {
                                        $this->messageManager->addErrorMessage(__("Error while uploading the document, please try again"));
                                        return $resultRedirect->setPath('kyc/kyc/uploadform/order_id/' . $data['order_id'] . "/customer_id/" . $data['customer_id']);
                                    }
                                }
                            }
                        }
                    }
                }
                $data['kyc_type'] = 1;
            } elseif (strlen($data['foreign_id_proof_field']) > 0 && strlen($data['foreign_address_proof_field']) > 0) {
                if (array_key_exists('size', $_FILES[$data['foreign_id_proof_field']])) {
                    if ($_FILES[$data['foreign_id_proof_field']]['size'] > 0) {
                        $resultPath = $this->uploadFile($path, $data['foreign_id_proof_field']);
                        if ($resultPath) {
                            $data['id_proof'] = $resultPath;
                        } else {
                            $this->messageManager->addErrorMessage(__("Error while uploading the document, please try again"));
                            return $resultRedirect->setPath('kyc/kyc/uploadform/order_id/' . $data['order_id'] . "/customer_id/" . $data['customer_id']);
                        }
                    }
                }
                if (array_key_exists($data['foreign_address_proof_field'], $_FILES)) {
                    if (array_key_exists('size', $_FILES[$data['foreign_address_proof_field']])) {
                        if ($_FILES[$data['foreign_address_proof_field']]['size'] > 0) {
                            $resultPath = $this->uploadFile($path, $data['foreign_address_proof_field']);
                            if ($resultPath) {
                                $data['address_proof'] = $resultPath;
                            } else {
                                $this->messageManager->addErrorMessage(__("Error while uploading the document, please try again"));
                                return $resultRedirect->setPath('kyc/kyc/uploadform/order_id/' . $data['order_id'] . "/customer_id/" . $data['customer_id']);
                            }
                        }
                    }
                }
                $data['kyc_type'] = 0;
            } else {
                $this->messageManager->addErrorMessage(__("Both Id and Address Proof need to be uploaded"));
                return $resultRedirect->setPath('kyc/kyc/uploadform/order_id/' . $data['order_id'] . "/customer_id/" . $data['customer_id']);
            }
            if (strlen($data['id_proof']) < 1 && strlen($data['address_proof']) < 1) {
                $this->messageManager->addErrorMessage(__("Choose files to upload"));
                return $resultRedirect->setPath('kyc/kyc/uploadform/order_id/' . $data['order_id'] . "/customer_id/" . $data['customer_id']);
            } elseif ((strlen($data['id_proof']) < 1 || strlen($data['address_proof']) < 1) && $data['kyc_type'] == "0") {
                $this->messageManager->addErrorMessage(__("Both Id and Address Proof need to be uploaded"));
                return $resultRedirect->setPath('kyc/kyc/uploadform/order_id/' . $data['order_id'] . "/customer_id/" . $data['customer_id']);
            } else {
                $kycType = $data['kyc_type'];
                $idProof = $data['id_proof'];
                $addressProof = $data['address_proof'];
                $this->kycManager->saveKycInformation($data['order_id'], $customerId, $kycType, $idProof, $addressProof, $websiteId);
                $this->messageManager->addSuccessMessage(__("KYC Documents saved successfully"));
                return $resultRedirect->setPath('kyc/businesskyc/documents');
            }
        } else {
            $this->messageManager->addErrorMessage(__("Customer not logged in"));
            return $resultRedirect->setPath('customer/account/');
        }
    }

    /**
     * @param $path
     * @param $fileId
     * @return null|string
     */
    protected function uploadFile($path, $fileId)
    {
        try {
            $target = $this->_mediaDirectory->getAbsolutePath($path);
            /** @var $uploader \Magento\MediaStorage\Model\File\Uploader */
            $uploader = $this->_fileUploaderFactory->create(['fileId' => $fileId]);
            /** Allowed extension types */
            $uploader->setAllowedExtensions(['jpg', 'jpeg', 'png', 'pdf']);
            /** rename file name if already exists */
            $uploader->setAllowRenameFiles(true);
            /** upload file in folder "$path" */
            $result = $uploader->save($target);
            if ($result['file']) {
                //$this->messageManager->addSuccess(__('File has been successfully uploaded'));
                return $path . $result['file'];
            }
        } catch (\Exception $e) {
            $this->messageManager->addError($e->getMessage());
            return null;
        }
    }
}