<?php

namespace Codilar\KYC\Setup;

use Magento\Framework\DB\Ddl\Table;
use Magento\Framework\Setup\InstallSchemaInterface;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\SchemaSetupInterface;
use Magento\Sales\Model\Order\Status;

/**
 * Class InstallSchema
 * @package Codilar\KYC\Setup
 */
class InstallSchema implements InstallSchemaInterface
{
    /**
     * @var Status
     */
    protected $orderStatus;

    /**
     * InstallSchema constructor.
     * @param Status $orderStatus
     */
    public function __construct
    (
        Status $orderStatus
    )
    {
        $this->orderStatus = $orderStatus;
    }

    /**
     * {@inheritdoc}
     */
    public function install(SchemaSetupInterface $setup, ModuleContextInterface $context)
    {
        $installer = $setup;

        $installer->startSetup();


        try {
            // To add referer column into sales_order_grid table
            $setup->getConnection()->addColumn(
                $setup->getTable('sales_order_grid'),
                'kyc_uploaded',
                [
                    'default' => "0",
                    'type' => Table::TYPE_INTEGER,
                    'length' => 2,
                    'comment' => 'KYC Uploaded ?'
                ]
            );
            // To add referer column into sales_order table
            $setup->getConnection()->addColumn(
                $setup->getTable('sales_order'),
                'kyc_uploaded',
                [
                    'default' => "0",
                    'type' => Table::TYPE_INTEGER,
                    'length' => 2,
                    'comment' => 'KYC Uploaded ?'
                ]
            );
            /*
            * Create table codilar_kyc_documents
            */
            $table = $installer->getConnection()->newTable(
                $installer->getTable('codilar_kyc_documents')
            )
                ->addColumn(
                    'id',
                    Table::TYPE_INTEGER,
                    null,
                    ['identity' => true, 'unsigned' => true, 'nullable' => false, 'primary' => true],
                    'ID'
                )
                ->addColumn(
                    'order_id',
                    Table::TYPE_INTEGER,
                    null,
                    ['unsigned' => true, 'nullable' => true,],
                    'Order Id'
                )
                ->addColumn(
                    'customer_id',
                    Table::TYPE_INTEGER,
                    null,
                    ['nullable' => true],
                    'Customer Id'
                )
                ->addColumn(
                    'kyc_type',
                    Table::TYPE_INTEGER,
                    null,
                    ['nullable' => true],
                    'KYC Type'
                )
                ->addColumn(
                    'id_proof',
                    Table::TYPE_TEXT,
                    null,
                    ['nullable' => true],
                    'ID Proof'
                )
                ->addColumn(
                    'address_proof',
                    Table::TYPE_TEXT,
                    null,
                    ['nullable' => true],
                    'Address Proof'
                )
                ->addColumn(
                    'website_id',
                    Table::TYPE_INTEGER,
                    2,
                    ['nullable' => true],
                    'Website Id  '
                )
                ->addColumn(
                    'uploaded_at',
                    Table::TYPE_TIMESTAMP,
                    null,
                    ['nullable' => false, 'default' => \Magento\Framework\DB\Ddl\Table::TIMESTAMP_INIT],
                    'Uploaded At'
                )
                ->addIndex(
                    $installer->getIdxName('codilar_kyc_documents', ['id']),
                    ['id']
                )
                ->addIndex(
                    $installer->getIdxName('codilar_kyc_documents', ['order_id']),
                    ['order_id']
                )
                ->addForeignKey(
                    $installer->getFkName('codilar_kyc_documents', 'order_id', 'sales_order', 'entity_id'),
                    'order_id',
                    $installer->getTable('sales_order'),
                    'entity_id',
                    \Magento\Framework\DB\Ddl\Table::ACTION_CASCADE
                );
            $installer->getConnection()->createTable($table);
            /*
             * End create table codilar_kyc_documents
             */
        } catch (\Exception $e) {
            print_r($e->getMessage());
        }

        $installer->endSetup();
    }
}
