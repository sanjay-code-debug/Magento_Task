<?php
 
namespace Codilar\KYC\Setup;

use Magento\Framework\DB\Ddl\Table;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\SchemaSetupInterface;
use Magento\Framework\Setup\UpgradeSchemaInterface;

/**
 * Class UpgradeSchema
 * @package Codilar\KYC\Setup
 */
class UpgradeSchema implements UpgradeSchemaInterface
{

    /**
     * {@inheritdoc}
     */
    public function upgrade(
        SchemaSetupInterface $setup,
        ModuleContextInterface $context
    )
    {
        $installer = $setup;

        $installer->startSetup();
        if (version_compare($context->getVersion(), '1.0.1', '<')) {
            /**
             * remove foreign key in codilar_kyc_documents table
             */

            $tableName = $setup->getTable('codilar_kyc_documents');
            $installer->getConnection()->addColumn(
                $installer->getTable($tableName),
                'vat_certificate',
                [
                    'type' => Table::TYPE_TEXT,
                    'comment' => 'VAT Certificate'
                ]
            );
            $installer->getConnection()->addColumn(
                $installer->getTable($tableName),
                'vat_certificate_filename',
                [
                    'type' => Table::TYPE_TEXT,
                    'comment' => 'VAT Certificate Filename'
                ]
            );
            $installer->getConnection()->addColumn(
                $installer->getTable($tableName),
                'company_registration',
                [
                    'type' => Table::TYPE_TEXT,
                    'comment' => 'Company Registration'
                ]
            );
            $installer->getConnection()->addColumn(
                $installer->getTable($tableName),
                'company_registration_filename',
                [
                    'type' => Table::TYPE_TEXT,
                    'comment' => 'Company Registration Filename'
                ]
            );
            $installer->getConnection()->addColumn(
                $installer->getTable($tableName),
                'poa',
                [
                    'type' => Table::TYPE_TEXT,
                    'comment' => 'Power of Attorney'
                ]
            );
            $installer->getConnection()->addColumn(
                $installer->getTable($tableName),
                'poa_filename',
                [
                    'type' => Table::TYPE_TEXT,
                    'comment' => 'Power of Attorney Filename'
                ]
            );
        }

        if (version_compare($context->getVersion(), '1.0.2', '<')) {
            $tableName = $setup->getTable('codilar_kyc_documents');
            $connection = $setup->getConnection();
            $connection->changeColumn(
                $tableName,
                'vat_certificate',
                'vat_certificate',
                [
                    'type' => Table::TYPE_TEXT,
                    'length' => '2M'
                ],
                'VAT Certificate'
            );
            $connection->changeColumn(
                $tableName,
                'company_registration',
                'company_registration',
                [
                    'type' => Table::TYPE_TEXT,
                    'length' => '2M'
                ],
                'Company Registration'
            );
            $connection->changeColumn(
                $tableName,
                'poa',
                'poa',
                [
                    'type' => Table::TYPE_TEXT,
                    'length' => '2M'
                ],
                'Power of Attorney'
            );
        }
        if (version_compare($context->getVersion(), '1.0.3', '<')) {
            $tableName = $setup->getTable('codilar_kyc_documents');
            $installer->getConnection()->addColumn(
                $installer->getTable($tableName),
                'gst_number',
                [
                    'type' => Table::TYPE_TEXT,
                    'comment' => 'GST Number'
                ]
            );   
        }
        if (version_compare($context->getVersion(), '1.0.4', '<')) {
            $tableName = $setup->getTable('sales_order');
            $installer->getConnection()->addColumn(
                $installer->getTable($tableName),
                'tier_discount',
                [
                    'type' => Table::TYPE_TEXT,
                    'comment' => 'Tier Price Discount'
                ]
            );   
        }
        if (version_compare($context->getVersion(), '1.0.5', '<')) {
            $tableName = $setup->getTable('quote');
            $installer->getConnection()->addColumn(
                $installer->getTable($tableName),
                'tier_discount',
                [
                    'type' => Table::TYPE_TEXT,
                    'comment' => 'Tier Price Discount'
                ]
            );   
        }
        if (version_compare($context->getVersion(), '1.0.6', '<')) {
            $tableName = $setup->getTable('codilar_kyc_documents');
            
            $installer->getConnection()->dropForeignKey(
                $setup->getTable('codilar_kyc_documents'),
                $setup->getFkName(
                    'codilar_kyc_documents',
                    'order_id',
                    'sales_order',
                    'entity_id'
                )
            );
            
            $installer->getConnection()->dropColumn($setup->getTable('codilar_kyc_documents'), 'order_id');

            $installer->getConnection()->addColumn(
                $installer->getTable($tableName),
                'is_kyc_verify',
                [
                    'type' => Table::TYPE_INTEGER,
                    'comment' => 'Is Kyc Verified',
                    'default' => 0,                    
                ]
            );   
        }
        if (version_compare($context->getVersion(), '1.0.7', '<')) {
            $tableName = $setup->getTable('codilar_kyc_documents');
            $installer->getConnection()->addColumn(
                $installer->getTable($tableName),
                'customer_email',
                [
                    'type' => Table::TYPE_TEXT,
                    'comment' => 'Customer Email'
                ]
            );   
        }
        $installer->endSetup();
    }
}