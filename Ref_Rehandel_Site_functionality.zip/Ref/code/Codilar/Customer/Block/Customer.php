<?php

namespace Codilar\Customer\Block;

use Magento\Customer\Api\CustomerRepositoryInterface;
use Magento\Framework\View\Element\Template;

/**
 * Class Customer
 * @package Codilar\Customer\Block
 */
class Customer extends Template
{
    /**
     * @var \Magento\Customer\Model\Session
     */
    protected $customerSession;
    /**
     * @var \Magento\Customer\Model\ResourceModel\CustomerRepository
     */
    protected $_customerModel;

    /**
     * @var \Codilar\SmsModule\Helper\Data
     */
    private $smsHelper;
    /**
     * @var CustomerRepositoryInterface
     */
    private $customerRepository;

    /**
     * Customer constructor.
     * @param \Magento\Customer\Model\Session                          $customerSession
     * @param \Magento\Customer\Model\ResourceModel\CustomerRepository $customerModel
     * @param Template\Context                                         $context
     * @param \Codilar\SmsModule\Helper\Data                           $smsHelper
     * @param CustomerRepositoryInterface                              $customerRepository
     * @param array                                                    $data
     */
    public function __construct(
        \Magento\Customer\Model\Session $customerSession,
        \Magento\Customer\Model\ResourceModel\CustomerRepository $customerModel,
        Template\Context $context,
        \Codilar\SmsModule\Helper\Data $smsHelper,
        CustomerRepositoryInterface $customerRepository,
        array $data = []
    )
    {
        $this->customerSession = $customerSession;
        $this->_customerModel = $customerModel;
        parent::__construct($context, $data);
        $this->smsHelper = $smsHelper;
        $this->customerRepository = $customerRepository;
    }

    /**
     * @return bool
     */
    public function isCustomerLoggedIn()
    {
        return $this->customerSession->isLoggedIn();
    }

    /**
     * @return string
     */
    public function getCustomerName()
    {
        return $this->customerSession->getCustomer()->getName();
    }

    /**
     * @return string
     */
    public function getMobileNumber()
    {
        $websiteId = $this->getWebsiteId();
        $customerId = $this->customerSession->getCustomerId();
        $customerEmail = $this->customerSession->getCustomer()->getEmail();
        try {
            $customer = $this->_customerModel->get($customerEmail, $websiteId);
            if ($customer->getCustomAttribute("mobile_number")) {
                return $customer->getCustomAttribute("mobile_number")->getValue();
            } else {
                return "";
            }
        } catch (\Exception $e) {
            return "";
        }
    }

    /**
     * @return bool|int
     */
    public function getWebsiteId()
    {
        try {
            return $this->_storeManager->getWebsite()->getId();
        } catch (\Exception $e) {
            return false;
        }
    }

    /**
     * @return int|mixed
     */
    public function getCountryCode()
    {
        $websiteId = $this->getWebsiteId();
        $customerEmail = $this->customerSession->getCustomer()->getEmail();
        try {
            $customer = $this->_customerModel->get($customerEmail, $websiteId);
            if ($customer->getCustomAttribute("country_code")) {
                return $customer->getCustomAttribute("country_code")->getValue();
            } else {
                return $this->smsHelper->getCountryCode();
            }
        } catch (\Exception $e) {
            return 61;
        }
    }

    /**
     * @return string
     */
    public function getCountryCodeFromStoreView()
    {
        return $this->smsHelper->getCountryCode();
    }

    /**
     * @return \Magento\Customer\Model\Customer
     */
    public function getCustomer(){
        return $this->customerSession->getCustomer();
    }
}
