<?php
namespace Codilar\Customer\Block;
use Magento\Framework\View\Element\Template;

class TrackingDetails extends \Magento\Framework\View\Element\Template
{
   public function __construct(Template\Context $context, array $data = [])
   {
       parent::__construct($context, $data);
   }
   public function getTrackingLink(){

       $link='https://www.uparcel.sg/track';
       return $link;
   }
}