<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */

namespace Codilar\Customer\Controller\Account;

use Codilar\Customer\Helper\Data as CustomerHelper;
use Codilar\Customer\Model\PasswordManager;
use Magento\Customer\Api\AccountManagementInterface;
use Magento\Customer\Api\Data\AddressInterface;
use Magento\Customer\Api\Data\AddressInterfaceFactory;
use Magento\Customer\Api\Data\CustomerInterfaceFactory;
use Magento\Customer\Api\Data\RegionInterfaceFactory;
use Magento\Customer\Helper\Address;
use Magento\Customer\Model\Account\Redirect as AccountRedirect;
use Magento\Customer\Model\CustomerExtractor;
use Magento\Customer\Model\CustomerFactory;
use Magento\Customer\Model\Metadata\FormFactory;
use Magento\Customer\Model\Registration;
use Magento\Customer\Model\Session;
use Magento\Customer\Model\Url as CustomerUrl;
use Magento\Framework\Api\DataObjectHelper;
use Magento\Framework\App\Action\Context;
use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Framework\App\ObjectManager;
use Magento\Framework\Data\Form\FormKey\Validator;
use Magento\Framework\Escaper;
use Magento\Framework\Exception\InputException;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Exception\StateException;
use Magento\Framework\UrlFactory;
use Magento\Newsletter\Model\SubscriberFactory;
use Magento\Store\Model\StoreManagerInterface;
use Magento\Framework\Controller\ResultFactory;
/**
 * @SuppressWarnings(PHPMD.TooManyFields)
 * @SuppressWarnings(PHPMD.CouplingBetweenObjects)
 */
class Createpostajax extends \Magento\Framework\App\Action\Action
{
    /**
     * @var \Magento\Customer\Api\AccountManagementInterface
     */
    protected $accountManagement;

    /**
     * @var \Magento\Customer\Helper\Address
     */
    protected $addressHelper;

    /**
     * @var \Magento\Customer\Model\Metadata\FormFactory
     */
    protected $formFactory;

    /**
     * @var \Magento\Newsletter\Model\SubscriberFactory
     */
    protected $subscriberFactory;

    /**
     * @var \Magento\Customer\Api\Data\RegionInterfaceFactory
     */
    protected $regionDataFactory;

    /**
     * @var \Magento\Customer\Api\Data\AddressInterfaceFactory
     */
    protected $addressDataFactory;

    /**
     * @var \Magento\Customer\Model\Registration
     */
    protected $registration;

    /**
     * @var \Magento\Customer\Api\Data\CustomerInterfaceFactory
     */
    protected $customerDataFactory;

    /**
     * @var \Magento\Customer\Model\Url
     */
    protected $customerUrl;

    /**
     * @var \Magento\Framework\Escaper
     */
    protected $escaper;

    /**
     * @var \Magento\Customer\Model\CustomerExtractor
     */
    protected $customerExtractor;

    /**
     * @var \Magento\Framework\UrlInterface
     */
    protected $urlModel;

    /**
     * @var \Magento\Framework\Api\DataObjectHelper
     */
    protected $dataObjectHelper;

    /**
     * @var Session
     */
    protected $session;
    /**
     * @var CustomerFactory
     */
    protected $_customerFactory;
    /**
     * @var CustomerHelper
     */
    protected $_customerHelper;
    /**
     * @var PasswordManager
     */
    protected $_passwordManager;
    /**
     * @var StoreManagerInterface
     */
    protected $_storeManager;
    /**
     * @var \Magento\Customer\Api\GroupRepositoryInterface
     */
    protected $groupRepo;
    /**
     * @var \Magento\Customer\Model\GroupFactory
     */
    protected $groupFactory;
    /**
     * @var AccountRedirect
     */
    private $accountRedirect;
    /**
     * @var \Magento\Framework\Stdlib\Cookie\CookieMetadataFactory
     */
    private $cookieMetadataFactory;
    /**
     * @var \Magento\Framework\Stdlib\Cookie\PhpCookieManager
     */
    private $cookieMetadataManager;
    /**
     * @var Validator
     */
    private $formKeyValidator;
    
    /**
     * @var SmsLogger
     */
    protected $_smsLogger;

    /**
     * CreatePost constructor.
     * @param Context                                        $context
     * @param Session                                        $customerSession
     * @param ScopeConfigInterface                           $scopeConfig
     * @param StoreManagerInterface                          $storeManager
     * @param AccountManagementInterface                     $accountManagement
     * @param Address                                        $addressHelper
     * @param UrlFactory                                     $urlFactory
     * @param FormFactory                                    $formFactory
     * @param SubscriberFactory                              $subscriberFactory
     * @param RegionInterfaceFactory                         $regionDataFactory
     * @param AddressInterfaceFactory                        $addressDataFactory
     * @param CustomerInterfaceFactory                       $customerDataFactory
     * @param CustomerUrl                                    $customerUrl
     * @param Registration                                   $registration
     * @param Escaper                                        $escaper
     * @param CustomerExtractor                              $customerExtractor
     * @param DataObjectHelper                               $dataObjectHelper
     * @param AccountRedirect                                $accountRedirect
     * @param Validator|null                                 $formKeyValidator
     * @param CustomerFactory                                $customerFactory
     * @param CustomerHelper                                 $customerHelper
     * @param PasswordManager                                $passwordManager
     * @param \Magento\Customer\Api\GroupRepositoryInterface $groupRepository
     * @param \Magento\Customer\Model\GroupFactory           $groupFactory
     */
    public function __construct(
        Context $context,
        Session $customerSession,
        ScopeConfigInterface $scopeConfig,
        StoreManagerInterface $storeManager,
        AccountManagementInterface $accountManagement,
        Address $addressHelper,
        UrlFactory $urlFactory,
        FormFactory $formFactory,
        SubscriberFactory $subscriberFactory,
        RegionInterfaceFactory $regionDataFactory,
        AddressInterfaceFactory $addressDataFactory,
        CustomerInterfaceFactory $customerDataFactory,
        CustomerUrl $customerUrl,
        Registration $registration,
        Escaper $escaper,
        CustomerExtractor $customerExtractor,
        DataObjectHelper $dataObjectHelper,
        AccountRedirect $accountRedirect,
        Validator $formKeyValidator = null,
        CustomerFactory $customerFactory,
        CustomerHelper $customerHelper,
        PasswordManager $passwordManager,
        \Magento\Customer\Api\GroupRepositoryInterface $groupRepository,
        \Magento\Customer\Model\GroupFactory $groupFactory,
        \Codilar\SmsModule\Model\SmsLogger $smsLogger
    )
    {
        $this->_customerFactory = $customerFactory;
        $this->groupRepo = $groupRepository;
        $this->groupFactory = $groupFactory;
        $this->_customerHelper = $customerHelper;
        $this->_passwordManager = $passwordManager;
        $this->_storeManager = $storeManager;
        
        $this->session = $customerSession;
        $this->scopeConfig = $scopeConfig;
        $this->storeManager = $storeManager;
        $this->accountManagement = $accountManagement;
        $this->addressHelper = $addressHelper;
        $this->formFactory = $formFactory;
        $this->subscriberFactory = $subscriberFactory;
        $this->regionDataFactory = $regionDataFactory;
        $this->addressDataFactory = $addressDataFactory;
        $this->customerDataFactory = $customerDataFactory;
        $this->customerUrl = $customerUrl;
        $this->registration = $registration;
        $this->escaper = $escaper;
        $this->customerExtractor = $customerExtractor;
        $this->urlModel = $urlFactory->create();
        $this->dataObjectHelper = $dataObjectHelper;
        $this->accountRedirect = $accountRedirect;
        $this->formKeyValidator = $formKeyValidator ?: ObjectManager::getInstance()->get(Validator::class);
        $this->_smsLogger = $smsLogger;
        parent::__construct($context);
    }

    /**
     * Create customer account action
     *
     * @return \Magento\Framework\Controller\Result\Forward|\Magento\Framework\Controller\Result\Redirect|void
     * @throws LocalizedException
     */
    public function execute()
    {
        $resultJson = $this->resultFactory->create(ResultFactory::TYPE_JSON);
        $data['error']=0;
        $isBusinessWebsite = in_array($this->_storeManager->getWebsite()->getCode(), \Shopmonk\Stores\Helper\Business\Data::BUSINESS_WEBSITES_WITH_AU);
        if ($this->session->isLoggedIn() || !$this->registration->isAllowed()) {
            $data['error'] = 1;
            $data['message'] ='you are already login or register not allowed';
            $resultJson->setData($data);
            return $resultJson;
            
        }

        if (!$this->getRequest()->isPost() || !$this->_customerHelper->formKeyValidator($this->getRequest())) {
            $data['error'] = 1;
            $data['message'] ='Something went Wrong Please try again';
            $resultJson->setData($data);
            return $resultJson;
        }

        if ($isBusinessWebsite) {
            $abn = $this->getRequest()->getParam('abn') ? $this->getRequest()->getParam('abn') : '';
            $businessName = $this->getRequest()->getParam('business_name') ? $this->getRequest()->getParam('business_name') : '';
            try {
                $existingCustomer = $this->_customerHelper->getCustomerByEmail($this->getRequest()->getParam('email'), 0);
                if ($existingCustomer->getId() && $this->groupRepo->getById($existingCustomer->getGroupId())->getCode() != \Shopmonk\Stores\Helper\Business\Data::BUSINESS_GROUP) {
                    $existingEmail = $this->getRequest()->getParam('email');
                    $toBusiness = $this->_url->getUrl('customer/account/login', ['tobusiness' => 1, 'referer' => base64_encode($this->_url->getUrl('codilar_customer/account/tobusiness',
                        [
                            'email' => $existingEmail,
                            'abn' => $abn,
                            'business_name' => $businessName
                        ]
                    ))]);
                    $toBusiness = "<a href='$toBusiness'>Click here</a>";
                    $message = sprintf('Your email id is associated with personal account. %s to convert it into a business account', $toBusiness);
                    $this->session->setCustomerFormData($this->getRequest()->getPostValue());
                    $data['error'] = 1;
                    $data['message'] = $message;
                    $resultJson->setData($data);
                    return $resultJson;
                }
            } catch (\Exception $e) {
                $data['error'] = 1;
                    $data['message'] = $e->getMessage();
                    $resultJson->setData($data);
                    return $resultJson;
            }
        }
        if (array_key_exists("mobile_number", $this->getRequest()->getParams())) {
            $mobile = $this->getRequest()->getParam("mobile_number") ? $this->getRequest()->getParam("mobile_number") :
                $this->getRequest()->getParam("mobile_number_reg");
            $country_code = $this->getRequest()->getParam("country_code");
            $mobile_number = str_replace($country_code,"",$mobile);
            $this->getRequest()->setPostValue('mobile_number',$mobile_number);
        }
        if (array_key_exists("country_id", $this->getRequest()->getParams())) {
            $country = $this->getRequest()->getParam("country_id");
            $this->getRequest()->setPostValue('base_country',$country);
        }
        $emailValue = $this->getRequest()->getParam("email") ? $this->getRequest()->getParam("email") :
             $this->getRequest()->getParam("email_reg");
        $this->getRequest()->setPostValue('email',$emailValue);
        $emailExists = $this->_customerFactory->create()->getCollection()
                ->addFieldToFilter("email", $emailValue)
                ->getFirstItem()->getEmail();
            if (strlen($emailExists)) {
                $data['error'] = 1;
                $emailMessage = __('Email already exists');
                $data['message'] = $emailMessage;
                $resultJson->setData($data);
                return $resultJson;
            }
        $mobileExists = $this->_customerFactory->create()->getCollection()
                ->addFieldToFilter("mobile_number", $mobile_number)
                ->getFirstItem()->getEmail();
            if (strlen($mobileExists)) {
                $data['error'] = 1;
                $mobileMessage = __('Mobile number already exists');
                $data['message'] = $mobileMessage;
                $resultJson->setData($data);
                return $resultJson;
            }

        $this->session->regenerateId();

        try {
            $address = $this->extractAddress();
            $addresses = $address === null ? [] : [$address];

            $customer = $this->customerExtractor->extract('customer_account_create', $this->_request);
            $customer->setAddresses($addresses);

            $password = $this->getRequest()->getParam('password');
            $confirmation = $this->getRequest()->getParam('password_confirmation');
            $redirectUrl = $this->session->getBeforeAuthUrl();
            if(!$password){
                $password = $this->generateRandomString();
                $confirmation = $password;
            }
            if(!$confirmation){
                $confirmation = $password;
            }
            $this->checkPasswordConfirmation($password, $confirmation);
            if ($isBusinessWebsite) {
                $newGroupId = $this->groupFactory->create()->load(\Shopmonk\Stores\Helper\Business\Data::BUSINESS_GROUP, 'customer_group_code')->getId();
                $customer->setGroupId($newGroupId);
            }
            $customer = $this->accountManagement
                ->createAccount($customer, $password, $redirectUrl);

            $this->_passwordManager->setPassword($customer->getId(), $password);

            if ($this->getRequest()->getParam('is_subscribed', false)) {
                $this->subscriberFactory->create()->subscribeCustomerById($customer->getId());
            }

            $this->_eventManager->dispatch(
                'customer_register_success',
                ['account_controller' => $this, 'customer' => $customer]
            );
            $confirmationStatus = $this->accountManagement->getConfirmationStatus($customer->getId());
                $this->session->setCustomerDataAsLoggedIn($customer);
                $this->messageManager->addSuccess($this->getSuccessMessage());
                $mobileNumber = $country_code.$mobile;
                $sms_data_log = $this->_smsLogger->setLatestSmsLogUntrackked($mobileNumber,$emailValue);
                
                $requestedRedirect = $this->_customerHelper->getRedirectCookie();
                if($this->scopeConfig->getValue('customer/startup/redirect_home')){
                    $data['error'] = 0;
                    $data['url'] = $this->urlModel->getUrl();
                    $resultJson->setData($data);
                    return $resultJson;
                }
                if (!$this->scopeConfig->getValue('customer/startup/redirect_dashboard') && $requestedRedirect) {
                    $data['error'] = 0;
                    $data['url'] = $this->_redirect->success($requestedRedirect);
                    $resultJson->setData($data);
                    return $resultJson;
                }
                $data['url'] = $this->_customerHelper->getRedirect();
            if ($this->getCookieManager()->getCookie('mage-cache-sessid')) {
                $metadata = $this->getCookieMetadataFactory()->createCookieMetadata();
                $metadata->setPath('/');
                $this->getCookieManager()->deleteCookie('mage-cache-sessid', $metadata);
            }
            $data['error'] = 0;
            $resultJson->setData($data);

            return $resultJson;
        } catch (StateException $e) {
            $url = $this->urlModel->getUrl('customer/account/forgotpassword');
            $message = __('Email already exists');
            $data['message'] = $message;
        } catch (LocalizedException $e) {
            $data['message'] = $this->escaper->escapeHtml($e->getMessage());
        } catch (\Exception $e) {
            $data['message'] = $this->escaper->escapeHtml($e->getMessage());
        }
        $data['error'] = 1;
        $resultJson->setData($data);
        return $resultJson;
    }

    /**
     * Add address to customer during create account
     *
     * @return AddressInterface|null
     */
    protected function extractAddress()
    {
        if (!$this->getRequest()->getPost('create_address')) {
            return null;
        }

        $addressForm = $this->formFactory->create('customer_address', 'customer_register_address');
        $allowedAttributes = $addressForm->getAllowedAttributes();

        $addressData = [];

        $regionDataObject = $this->regionDataFactory->create();
        foreach ($allowedAttributes as $attribute) {
            $attributeCode = $attribute->getAttributeCode();
            $value = $this->getRequest()->getParam($attributeCode);
            if ($value === null) {
                continue;
            }
            switch ($attributeCode) {
                case 'region_id':
                    $regionDataObject->setRegionId($value);
                    break;
                case 'region':
                    $regionDataObject->setRegion($value);
                    break;
                default:
                    $addressData[$attributeCode] = $value;
            }
        }
        $addressDataObject = $this->addressDataFactory->create();
        $this->dataObjectHelper->populateWithArray(
            $addressDataObject,
            $addressData,
            \Magento\Customer\Api\Data\AddressInterface::class
        );
        $addressDataObject->setRegion($regionDataObject);

        $addressDataObject->setIsDefaultBilling(
            $this->getRequest()->getParam('default_billing', false)
        )->setIsDefaultShipping(
            $this->getRequest()->getParam('default_shipping', false)
        );
        return $addressDataObject;
    }

    /**
     * Make sure that password and password confirmation matched
     *
     * @param string $password
     * @param string $confirmation
     * @return void
     * @throws InputException
     */
    protected function checkPasswordConfirmation($password, $confirmation)
    {
        if ($password != $confirmation) {
            throw new InputException(__('Please make sure your passwords match.'));
        }
    }

    /**
     * Retrieve success message
     *
     * @return string
     */
    protected function getSuccessMessage()
    {
        if ($this->addressHelper->isVatValidationEnabled()) {
            if ($this->addressHelper->getTaxCalculationAddressType() == Address::TYPE_SHIPPING) {
                // @codingStandardsIgnoreStart
                $message = __(
                    'If you are a registered VAT customer, please <a href="%1">click here</a> to enter your shipping address for proper VAT calculation.',
                    $this->urlModel->getUrl('customer/address/edit')
                );
                // @codingStandardsIgnoreEnd
            } else {
                // @codingStandardsIgnoreStart
                $message = __(
                    'If you are a registered VAT customer, please <a href="%1">click here</a> to enter your billing address for proper VAT calculation.',
                    $this->urlModel->getUrl('customer/address/edit')
                );
                // @codingStandardsIgnoreEnd
            }
        } else {
            $message = __('Thank you for registering with %1', $this->storeManager->getStore()->getFrontendName());
        }
        return $message;
    }

    /**
     * Retrieve cookie manager
     *
     * @deprecated 100.1.0
     * @return \Magento\Framework\Stdlib\Cookie\PhpCookieManager
     */
    private function getCookieManager()
    {
        if (!$this->cookieMetadataManager) {
            $this->cookieMetadataManager = ObjectManager::getInstance()->get(
                \Magento\Framework\Stdlib\Cookie\PhpCookieManager::class
            );
        }
        return $this->cookieMetadataManager;
    }

    /**
     * Retrieve cookie metadata factory
     *
     * @deprecated 100.1.0
     * @return \Magento\Framework\Stdlib\Cookie\CookieMetadataFactory
     */
    private function getCookieMetadataFactory()
    {
        if (!$this->cookieMetadataFactory) {
            $this->cookieMetadataFactory = ObjectManager::getInstance()->get(
                \Magento\Framework\Stdlib\Cookie\CookieMetadataFactory::class
            );
        }
        return $this->cookieMetadataFactory;
    }
    
    public function generateRandomString($length = 10) {
        $randomString = substr(str_shuffle(str_repeat($x='0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ', ceil($length-1/strlen($x)) )),1,$length-1);
        return $randomString."@";
    }
}
