<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */

namespace Codilar\Customer\Controller\Account;

use Codilar\Customer\Helper\Data as CustomerHelper;
use Magento\Customer\Api\AccountManagementInterface;
use Magento\Customer\Model\Account\Redirect as AccountRedirect;
use Magento\Customer\Model\CustomerFactory;
use Magento\Customer\Model\Session;
use Magento\Customer\Model\Url as CustomerUrl;
use Magento\Framework\App\Action\Context;
use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Framework\Data\Form\FormKey\Validator;
use Magento\Framework\Exception\AuthenticationException;
use Magento\Framework\Exception\EmailNotConfirmedException;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Exception\State\UserLockedException;
use Magento\Store\Model\StoreManagerInterface;

/**
 * @SuppressWarnings(PHPMD.CouplingBetweenObjects)
 */
class LoginPost extends \Magento\Customer\Controller\Account\LoginPost
{
    /**
     * @var \Magento\Customer\Api\AccountManagementInterface
     */
    protected $customerAccountManagement;

    /**
     * @var \Magento\Framework\Data\Form\FormKey\Validator
     */
    protected $formKeyValidator;

    /**
     * @var AccountRedirect
     */
    protected $accountRedirect;

    /**
     * @var Session
     */
    protected $session;
    /**
     * @var CustomerFactory
     */
    protected $_customerFactory;
    /**
     * @var StoreManagerInterface
     */
    protected $_storeManager;
    /**
     * @var CustomerHelper
     */
    protected $_customerHelper;
    /**
     * @var \Magento\Customer\Api\GroupRepositoryInterface
     */
    protected $groupRepo;
    /**
     * @var ScopeConfigInterface
     */
    private $scopeConfig;
    /**
     * @var \Magento\Framework\Stdlib\Cookie\CookieMetadataFactory
     */
    private $cookieMetadataFactory;
    /**
     * @var \Magento\Framework\Stdlib\Cookie\PhpCookieManager
     */
    private $cookieMetadataManager;

    /**
     * LoginPost constructor.
     * @param Context                                        $context
     * @param Session                                        $customerSession
     * @param AccountManagementInterface                     $customerAccountManagement
     * @param CustomerUrl                                    $customerHelperData
     * @param Validator                                      $formKeyValidator
     * @param AccountRedirect                                $accountRedirect
     * @param CustomerFactory                                $customerFactory
     * @param StoreManagerInterface                          $storeManager
     * @param CustomerHelper                                 $customerHelper
     * @param \Magento\Customer\Api\GroupRepositoryInterface $groupRepository
     */
    public function __construct(
        Context $context,
        Session $customerSession,
        AccountManagementInterface $customerAccountManagement,
        CustomerUrl $customerHelperData,
        Validator $formKeyValidator,
        AccountRedirect $accountRedirect,
        CustomerFactory $customerFactory,
        StoreManagerInterface $storeManager,
        CustomerHelper $customerHelper,
        \Magento\Customer\Api\GroupRepositoryInterface $groupRepository
    )
    {
        $this->_customerFactory = $customerFactory;
        $this->_storeManager = $storeManager;
        $this->_customerHelper = $customerHelper;
        $this->groupRepo = $groupRepository;
        parent::__construct($context, $customerSession, $customerAccountManagement, $customerHelperData, $formKeyValidator, $accountRedirect);
    }

    /**
     * Login post action
     *
     * @return \Magento\Framework\Controller\Result\Redirect
     * @throws LocalizedException
     * @SuppressWarnings(PHPMD.CyclomaticComplexity)
     */
    public function execute()
    {
        $isBusinessWebsite = in_array($this->_storeManager->getWebsite()->getCode(), \Shopmonk\Stores\Helper\Business\Data::BUSINESS_WEBSITES_WITH_AU);
        $toBusiness = $this->getRequest()->getParam('tobusiness') ? $this->getRequest()->getParam('tobusiness') : false;
        if ($this->session->isLoggedIn() || !$this->formKeyValidator->validate($this->getRequest())) {
            /** @var \Magento\Framework\Controller\Result\Redirect $resultRedirect */
            $resultRedirect = $this->resultRedirectFactory->create();
            $resultRedirect->setPath('*/*/');
            return $resultRedirect;
        }

        if ($this->getRequest()->isPost()) {
            $login = $this->getRequest()->getPost('login');
            $mobile = "";
            $username = "";
            if (array_key_exists("username", $login)) {
                $username = $login['username']; 
            }
            if (array_key_exists("mobile_number", $login)) {
                $mobile = $login['mobile_number'];
            }

            $email = "";
            $resultRedirect = $this->resultRedirectFactory->create();
            $resultRedirect->setUrl($this->_redirect->success($this->_url->getUrl('*/*/login', ['_secure' => true,'loginpass'=>1])));
            if (is_numeric($mobile)) {
                $country_code = $this->getRequest()->getParam("country_code");
                $mobile_number = str_replace($country_code,"",$mobile);
                $email = $this->getEmailFromMobile($mobile_number);
                $login['username'] = $email;
                $username = $email;
            }
            $emailExists = $this->_customerFactory->create()->getCollection()
                ->addFieldToFilter("email", $username)
                ->getFirstItem()->getEmail();
            if (!strlen($emailExists) > 0) {
                $errorMessage = __(
                    'This email or Mobile number is not registered with us. Please sign up.'
                );
                $this->messageManager->addError($errorMessage);
                $this->session->setUsername($username);
                return $resultRedirect;
            }
            if (!empty($login['username']) && !empty($login['password'])) {
                try {
                    $customer = $this->customerAccountManagement->authenticate($login['username'], $login['password']);
                    if ($isBusinessWebsite && !$toBusiness && $this->groupRepo->getById($customer->getGroupId())->getCode() != \Shopmonk\Stores\Helper\Business\Data::BUSINESS_GROUP) {
                        $toBusiness = $this->_url->getUrl('customer/account/login', ['tobusiness' => 1, 'referer' => base64_encode($this->_url->getUrl('codilar_customer/account/tobusiness',
                            [
                                'email' => $login['username'],
                            ]
                        ))]);
                        $toBusinessCreate = $this->_url->getUrl('customer/account/create', ['d' => 1]);
                        $toBusiness = "<div class='business-convert'><a href='$toBusiness'>Yes</a></div>";
                        $toBusinessCreate = "<div class='business-create'><a href='$toBusinessCreate'>No</a></div>";
                        $message = sprintf('<div class="customer-warning">Your email Id is associated with personal account. Do you want to convert your account into a business account?</div> %1s %2s', $toBusiness, $toBusinessCreate);
                        $this->messageManager->addNotice($message);
                        $resultRedirect = $this->resultRedirectFactory->create();
                        $resultRedirect->setUrl($this->_redirect->success($this->_url->getUrl('*/*/login', ['_secure' => true,'loginpass'=>1])));
                        return $resultRedirect;
                    }
                    $this->session->setCustomerDataAsLoggedIn($customer);
                    $this->session->regenerateId();
                    if ($this->getCookieManager()->getCookie('mage-cache-sessid')) {
                        $metadata = $this->getCookieMetadataFactory()->createCookieMetadata();
                        $metadata->setPath('/');
                        $this->getCookieManager()->deleteCookie('mage-cache-sessid', $metadata);
                    }
                    $redirectUrl = $this->accountRedirect->getRedirectCookie();
                    if (!$this->getScopeConfig()->getValue('customer/startup/redirect_dashboard') && $redirectUrl) {
                        $this->accountRedirect->clearRedirectCookie();
                        $resultRedirect = $this->resultRedirectFactory->create();
                        // URL is checked to be internal in $this->_redirect->success()
                        $resultRedirect->setUrl($this->_redirect->success($redirectUrl));
                        return $resultRedirect;
                    }
                } catch (EmailNotConfirmedException $e) {
                    $value = $this->customerUrl->getEmailConfirmationUrl($login['username']);
                    $message = __(
                        'This account is not confirmed. <a href="%1">Click here</a> to resend confirmation email.',
                        $value
                    );
                    $this->messageManager->addError($message);
                    $this->session->setUsername($username);
                } catch (UserLockedException $e) {
                    $message = __(
                        'Invalid login or password.'
                    );
                    $this->messageManager->addError($message);
                    $this->session->setUsername($username);
                    return $resultRedirect;
                } catch (AuthenticationException $e) {
                    $message = __('Invalid login or password.');
                    $this->messageManager->addError($message);
                    $this->session->setUsername($username);
                    return $resultRedirect;
                } catch (LocalizedException $e) {
                    $message = $e->getMessage();
                    $this->messageManager->addError($message);
                    $this->session->setUsername($username);
                    return $resultRedirect;
                } catch (\Exception $e) {
                    $this->messageManager->addError(
                        __('An unspecified error occurred. Please contact us for assistance.')
                    );
                    return $resultRedirect;
                }
            } else {
                $this->messageManager->addError(__('A login and a password are required.'));
            }
        }
        $resultRedirect = $this->resultRedirectFactory->create();
        return $resultRedirect->setUrl("/");
        //return $this->accountRedirect->getRedirect();
    }

    /**
     * @param $mobileNumber
     * @return mixed
     */
    public function getEmailFromMobile($mobileNumber)
    {
        $websiteId = $this->getWebsiteId();
        if ($this->_customerHelper->getAccountSharingOptions()) {
            $email = $this->_customerFactory->create()->getCollection()
                ->addFieldToFilter("website_id", $websiteId)
                ->addFieldToFilter('mobile_number', $mobileNumber)
                ->getFirstItem()
                ->getEmail();
        } else {
            $email = $this->_customerFactory->create()->getCollection()
                ->addFieldToFilter('mobile_number', $mobileNumber)
                ->getFirstItem()
                ->getEmail();
        }
        return $email;
    }

    /**
     * @return bool|int
     */
    public function getWebsiteId()
    {
        try {
            return $this->_storeManager->getWebsite()->getId();
        } catch (\Exception $e) {
            return false;
        }

    }

    /**
     * Retrieve cookie manager
     *
     * @deprecated 100.1.0
     * @return \Magento\Framework\Stdlib\Cookie\PhpCookieManager
     */
    private function getCookieManager()
    {
        if (!$this->cookieMetadataManager) {
            $this->cookieMetadataManager = \Magento\Framework\App\ObjectManager::getInstance()->get(
                \Magento\Framework\Stdlib\Cookie\PhpCookieManager::class
            );
        }
        return $this->cookieMetadataManager;
    }

    /**
     * Retrieve cookie metadata factory
     *
     * @deprecated 100.1.0
     * @return \Magento\Framework\Stdlib\Cookie\CookieMetadataFactory
     */
    private function getCookieMetadataFactory()
    {
        if (!$this->cookieMetadataFactory) {
            $this->cookieMetadataFactory = \Magento\Framework\App\ObjectManager::getInstance()->get(
                \Magento\Framework\Stdlib\Cookie\CookieMetadataFactory::class
            );
        }
        return $this->cookieMetadataFactory;
    }

    /**
     * Get scope config
     *
     * @return ScopeConfigInterface
     * @deprecated 100.0.10
     */
    private function getScopeConfig()
    {
        if (!($this->scopeConfig instanceof \Magento\Framework\App\Config\ScopeConfigInterface)) {
            return \Magento\Framework\App\ObjectManager::getInstance()->get(
                \Magento\Framework\App\Config\ScopeConfigInterface::class
            );
        } else {
            return $this->scopeConfig;
        }
    }
}
