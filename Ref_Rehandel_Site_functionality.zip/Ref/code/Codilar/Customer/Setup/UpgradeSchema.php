<?php

namespace Codilar\Customer\Setup;

use Magento\Framework\DB\Ddl\Table;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\SchemaSetupInterface;
use Magento\Framework\Setup\UpgradeSchemaInterface;

/**
 * Class UpgradeSchema
 * @package Codilar\Customer\Setup
 */
class UpgradeSchema implements UpgradeSchemaInterface
{
    /**
     *
     * @param SchemaSetupInterface $setup
     * @param ModuleContextInterface $context
     */
    public function upgrade(
        SchemaSetupInterface $setup,
        ModuleContextInterface $context
    )
    {
        $installer = $setup;

        $installer->startSetup();
        if (version_compare($context->getVersion(), '1.1.3', '<')) {
            $tableName = $setup->getTable('codilar_otp');
            $installer->getConnection()->addColumn(
                $installer->getTable($tableName),
                'email',
                [
                    'type' => Table::TYPE_TEXT,
                    'comment' => 'Email'
                ]
            );
        }
        if (version_compare($context->getVersion(), '1.1.4', '<')) {
            $tableName = $setup->getTable('codilar_otp');
            $installer->getConnection()->addColumn(
                $installer->getTable($tableName),
                'timeout',
                [
                    'type' => Table::TYPE_TEXT,
                    'comment' => 'Timeout',
                    'nullable' => false,
                    'default' =>0,
                    'length' => 20
                ]
            );
        }
        if (version_compare($context->getVersion(), '1.1.5', '<')) {
            $tableName = $setup->getTable('codilar_otp');
            $installer->getConnection()->addColumn(
                $installer->getTable($tableName),
                'count_requests',
                [
                    'type' => Table::TYPE_INTEGER,
                    'comment' => 'Count Requests',
                    'nullable' => false,
                    'default' =>0,
                    'length' => 11
                ]
            );
        }
        if (version_compare($context->getVersion(), '1.1.6', '<')) {
            $tableName = $setup->getTable('codilar_otp');
            $installer->getConnection()->addColumn(
                $installer->getTable($tableName),
                'ip_address',
                [
                    'type' => Table::TYPE_TEXT,
                    'comment' => 'IP Address',
                    'nullable' => false,
                    'default' =>0,
                    'length' => 100
                ]
            );
        }
        if (version_compare($context->getVersion(), '1.1.7', '<')) {
            $tableName = $setup->getTable('codilar_otp');
            $installer->getConnection()->addColumn(
                $installer->getTable($tableName),
                'ip_count_requests',
                [
                    'type' => Table::TYPE_INTEGER,
                    'comment' => 'IP Address Count',
                    'nullable' => false,
                    'default' =>0,
                    'length' => 11
                ]
            );
        }

        $installer->endSetup();
    }
}
