<?php

namespace Codilar\Customer\Model\ResourceModel;
/**
 * Class PasswordLogger
 * @package Codilar\Customer\Model\ResourceModel
 */
class PasswordLogger extends \Magento\Framework\Model\ResourceModel\Db\AbstractDb
{
    /**
     * @var string
     */
    protected $_idFieldName = 'log_id';

    protected function _construct()
    {
        $this->_init('codilar_customer_password_log', 'log_id');
    }
}