<?php

namespace Codilar\Customer\Model\ResourceModel;
/**
 * Class Otp
 * @package Codilar\Customer\Model\ResourceModel
 */
class Otp extends \Magento\Framework\Model\ResourceModel\Db\AbstractDb
{
    protected function _construct()
    {
        $this->_init('codilar_otp', 'id');
    }
}
