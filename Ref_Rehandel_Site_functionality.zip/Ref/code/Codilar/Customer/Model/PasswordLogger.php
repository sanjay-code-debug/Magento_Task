<?php

namespace Codilar\Customer\Model;

/**
 * Class PasswordLogger
 * @package Codilar\Customer\Model
 */
class PasswordLogger extends \Magento\Framework\Model\AbstractModel
{

    protected function _construct()
    {
        $this->_init('Codilar\Customer\Model\ResourceModel\PasswordLogger');
    }
}