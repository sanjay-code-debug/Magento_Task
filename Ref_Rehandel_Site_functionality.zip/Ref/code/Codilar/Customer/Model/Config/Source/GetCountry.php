<?php

namespace Codilar\Customer\Model\Config\Source;

use Magento\Eav\Model\Entity\Attribute\Source\AbstractSource;
use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Store\Model\ScopeInterface;
use Magento\Directory\Model\Config\Source\Country;

use Magento\Customer\Ui\Component\Listing\Address\Column\Countries;

class GetCountry extends AbstractSource {

    /**
     * @var Country
     */
    private $country;
    /**
     * @var ScopeConfigInterface
     */
    private $scopeConfig;

    const COUNTRY_CODE_PATH = 'general/country/default';
    /**
     * @var Countries
     */
    private $countries;

    public function __construct(
        ScopeConfigInterface $scopeConfig,
        Country $country,
        Countries $countries
    )
    {
        $this->country = $country;
        $this->scopeConfig = $scopeConfig;
        $this->countries = $countries;
    }

    public function getBaseCountry()
    {
        return $this->scopeConfig->getValue(
            self::COUNTRY_CODE_PATH,
            ScopeInterface::SCOPE_WEBSITES
        );
    }

    public function getAllCountry() {
        $data = $this->country->toOptionArray();
        return $data;
    }

//    public  function getCountryData() {
//        $data = $this->countries->toOptionArray();
//        return $data;
//    }

//    public function getAllOptions() {
//        $data = $this->getCountryData();
//        return $data;
//    }

    public function getAllOptions() {
         $data = $this->getAllCountry();
         return $data;
    }

}
