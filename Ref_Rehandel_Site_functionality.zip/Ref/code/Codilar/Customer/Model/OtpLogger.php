<?php

namespace Codilar\Customer\Model;

use Magento\Customer\Api\CustomerRepositoryInterface;
use Magento\Framework\Encryption\EncryptorInterface as Encryptor;
use Magento\Framework\Model\Context;
use Magento\Framework\Registry;
use Codilar\SmsModule\Model\SmsLogger;
use Magento\Framework\Stdlib\DateTime\DateTimeFactory;
use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Framework\HTTP\PhpEnvironment\RemoteAddress;

/**
 * Class OtpLogger
 * @package Codilar\Customer\Model
 */
class OtpLogger extends \Magento\Framework\Model\AbstractModel
{
    /**
     * @var \Codilar\Customer\Model\Otp
     */
    protected $_otpLogger;
    /**
     * @var Encryptor
     */
    protected $encryptor;
    /**
     * @var CustomerRepositoryInterface
     */
    private $customerRepository;

    /**
     * @var SmsLogger
     */
    protected $_smsLogger;
    /**
     * @var $_scopeConfigInterface
     */
    protected $scopeConfig;
    /**
     * @var $RemoteAddress
     */
    protected $remoteAddress;


    /**
     * OtpLogger constructor.
     * @param Context                     $context
     * @param Registry                    $registry
     * @param Encryptor                   $encryptor
     * @param \Codilar\Customer\Model\Otp $otpLogger
     * @param CustomerRepositoryInterface $customerRepository
     */
    public function __construct(
        Context $context,
        Registry $registry,
        Encryptor $encryptor,
        Otp $otpLogger,
        SmsLogger $smsLogger,
        CustomerRepositoryInterface $customerRepository,
        DateTimeFactory $dateTimeFactory,
        ScopeConfigInterface $scopeConfig,
        RemoteAddress $remoteAddress
    )
    {
        $this->encryptor = $encryptor;
        $this->_otpLogger = $otpLogger;
        $this->_smsLogger = $smsLogger;
        $this->customerRepository = $customerRepository;
        $this->dateTimeFactory = $dateTimeFactory;
        $this->_scopeConfig = $scopeConfig;
        $this->remoteAddress = $remoteAddress;
        parent::__construct($context, $registry);
    }

    /**
     * @param $customerId
     * @param $otp
     * @param $mobileNumber
     * @param $token
     * @return bool
     */
    public function setCustomerOtp($customerId, $otp, $mobileNumber, $token,$current_timeout)
    {
        $ip = $this->remoteAddress->getRemoteAddress();
        $ip_data = $this->_otpLogger->getCollection()
            ->addFieldToFilter("ip_address", $ip);
            
        if(count($ip_data)==0){
            $ip_count_requests=1;    
        }
        else{
            $ip_count_requests=count($ip_data); 
        }
        foreach($ip_data as $ip_value){
            $ip_value->setIpAddress($ip);
            $ip_value->setIpCountRequests($ip_count_requests);
            $ip_value->save();
        }

        if(!$customerId){
            $customerId = null;
        }
        $count_requests=1; 
        $loggerId = $this->_otpLogger->getCollection()
            ->addFieldToFilter("mobile_number", $mobileNumber)
            ->getLastItem()
            ->getId();
        $logData['id'] = null;

        $otp_data = $this->_otpLogger->getCollection()
            ->addFieldToFilter("mobile_number", $mobileNumber)
            ->getLastItem();

        $ip_data_last = $this->_otpLogger->getCollection()
            ->addFieldToFilter("ip_address", $ip)
            ->getLastItem();

        $otpEncrypted = $otp;
        $email = null;
        if (!is_numeric($mobileNumber)) {
            $email = $mobileNumber;
            $mobileNumber = null;
        }
        $otp_request_count = $this->_scopeConfig->getValue('customer/startup/otp_request_count', \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
        $timeout_duration = $this->_scopeConfig->getValue('customer/startup/otp_request_timeout', \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
        $enable_ip_validation = $this->_scopeConfig->getValue('customer/startup/enable_ip_validation', \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
        $enable_mobile_validation = $this->_scopeConfig->getValue('customer/startup/enable_mobile_validation', \Magento\Store\Model\ScopeInterface::SCOPE_STORE);

        $current_date = date("Y-m-d H:i:s");
        
        //ip condition start
        if($enable_ip_validation){
            if($ip_count_requests < $otp_request_count){
            foreach($ip_data as $ip_value){
                    $ip_value->setIpCountRequests($ip_count_requests);
                    $ip_value->setCreatedTime($current_date);
                    $ip_value->save();
                }
            }
            else{
                $created_date = $ip_data_last->getCreatedTime();
                $updated_date = date("Y-m-d H:i:s" , strtotime($created_date. ' +'.$timeout_duration.' hours'));
                
                $dateModel = $this->dateTimeFactory->create();
                $created_date = $dateModel->gmtDate('Y-m-d H:i:s', $created_date);
                $updated_date = $dateModel->gmtDate('Y-m-d H:i:s', $updated_date);
                if($current_date < $updated_date){
                    return false;
                }
                else{
                    $ip_count_requests = 0; 
                    foreach($ip_data as $ip_value){
                        $ip_value->setIpAddress("");
                        $ip_value->setIpCountRequests($ip_count_requests);
                        $ip_value->setCreatedTime($updated_date);
                        $ip_value->setCountRequests($ip_count_requests);
                        $ip_value->save();
                    }
                }
            }
        }      
        //ip condition end

        if ($loggerId) {
            // mobile condition start
            if($enable_mobile_validation){
                $otp_data = $this->_otpLogger->getCollection()
                ->addFieldToFilter("id", $loggerId)
                ->getFirstItem();
                
                if($otp_data->getCountRequests() < $otp_request_count){
                    $count_requests= $otp_data->getCountRequests()+1;
                    $otp_data->setCreatedTime($current_date);
                    $otp_data->save();
                }
                else{
                    $count_requests= $otp_data->getCountRequests();
                    $created_date = $otp_data->getCreatedTime();
                    $updated_date = date("Y-m-d H:i:s" , strtotime($created_date. ' +'.$timeout_duration.' hours'));
                    
                    $dateModel = $this->dateTimeFactory->create();
                    $created_date = $dateModel->gmtDate('Y-m-d H:i:s', $created_date);
                    $updated_date = $dateModel->gmtDate('Y-m-d H:i:s', $updated_date);
                    if($current_date < $updated_date){
                        return false;
                    }
                    else{
                        $otp_data->setCreatedTime($updated_date);
                        $otp_data->save();      
                        $count_requests=0;      
                        
                    }
                }
            }
            // mobile condition end

            $logData = [
                "id" => $loggerId,
                "customer_id" => $customerId,
                "mobile_number" => $mobileNumber,
                "otp" => $otpEncrypted,
                "rp_token" => $token,
                "timeout" => $current_timeout,
                "count_requests" => $count_requests,
                "email" => $email,
                "ip_address" => $ip,
                "ip_count_requests" => $ip_count_requests
            ];
        } else {
            $logData = [
                "customer_id" => $customerId,
                "mobile_number" => $mobileNumber,
                "otp" => $otpEncrypted,
                "rp_token" => $token,
                "timeout" => $current_timeout,
                "count_requests" => $count_requests,
                "email" => $email,
                "ip_address" => $ip,
                "ip_count_requests" => $ip_count_requests
            ];
        }
        $model = $this->_otpLogger;
        $model->setData($logData);
        try {
            $model->getResource()->save($model);
            return true;
        } catch (\Exception $e) {
            return false;
        }
    }

    /**
     * @param $customerId
     * @param $otp
     * @param $mobileNumber
     * @return bool
     */
    public function validateOtp($customerId, $otp, $mobileNumber)
    {
        $email = null;
        if (!is_numeric($mobileNumber)) {
            $otp_data = $this->_otpLogger->getCollection()
                ->addFieldToFilter("email", $mobileNumber)
                ->getLastItem();
        } else {
            $otp_data = $this->_otpLogger->getCollection()
                ->addFieldToFilter("mobile_number", $mobileNumber)
                ->getLastItem();
        }
        $mins = 5;
            $timeout = $otp_data->getTimeout();
            $new_time = $timeout + $mins * 60;
            if ($new_time < time()) {
                return false;
            }
            $otpData = $otp_data->getOtp();

        if ($otpData) {
            if ($otp == $otpData) {
                if($customerId){
                    
                    $sms_data_log = $this->_smsLogger->setLatestSmsLog($mobileNumber);
                }
                return true;
            }
        }
        \Magento\Framework\App\ObjectManager::getInstance()
    ->get(\Psr\Log\LoggerInterface::class)->debug(json_encode($otpData).$customerId.$mobileNumber.$otp);
        return false;
    }

    /**
     * @param $customerId
     * @param $mobileNumber
     * @return bool|\Magento\Framework\DataObject
     */
    public function getOtpData($customerId, $mobileNumber)
    {
        $otpData = $this->_otpLogger->getCollection()
            ->addFieldToFilter("customer_id", $customerId)
            ->addFieldToFilter("mobile_number", $mobileNumber)
            ->getFirstItem();
        if ($otpData) {
            return $otpData;
        }
        return false;
    }

}