<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Codilar\MultiStoreInventory\Model;

use Codilar\MultiStoreInventory\Helper\Data;
use Magento\CatalogInventory\Api\Data\StockItemInterface;
use Magento\CatalogInventory\Api\StockConfigurationInterface;
use Magento\CatalogInventory\Api\StockManagementInterface;
use Magento\CatalogInventory\Model\ResourceModel\QtyCounterInterface;
use Magento\CatalogInventory\Model\ResourceModel\Stock as QuantityCounterStock;
use Magento\CatalogInventory\Model\Spi\StockRegistryProviderInterface;
use Magento\Catalog\Api\ProductRepositoryInterface;
use Magento\CatalogInventory\Model\ResourceModel\Stock as ResourceStock;
use Magento\CatalogInventory\Model\StockState;

/**
 * Class StockManagement
 */
class StockManagement extends \Magento\CatalogInventory\Model\StockManagement
{
    /**
     * @var StockRegistryProviderInterface
     */
    protected $stockRegistryProvider;

    /**
     * @var StockState
     */
    protected $stockState;

    /**
     * @var StockConfigurationInterface
     */
    protected $stockConfiguration;

    /**
     * @var ProductRepositoryInterface
     */
    protected $productRepository;

    /**
     * @var ResourceStock
     */
    protected $resource;

    /**
     * @var QtyCounterInterface
     */
    private $qtyCounter;
    /**
     * @var Data
     */
    private $stockHelper;
    /**
     * @var ResourceStock
     */
    private $quantityCounterStock;

    /**
     * StockManagement constructor.
     * @param ResourceStock $stockResource
     * @param StockRegistryProviderInterface $stockRegistryProvider
     * @param StockState $stockState
     * @param StockConfigurationInterface $stockConfiguration
     * @param ProductRepositoryInterface $productRepository
     * @param QtyCounterInterface $qtyCounter
     * @param ResourceStock $quantityCounterStock
     * @param Data $stockHelper
     */
    public function __construct(
        ResourceStock $stockResource,
        StockRegistryProviderInterface $stockRegistryProvider,
        StockState $stockState,
        StockConfigurationInterface $stockConfiguration,
        ProductRepositoryInterface $productRepository,
        QtyCounterInterface $qtyCounter,
        QuantityCounterStock $quantityCounterStock,
        Data $stockHelper
    )
    {
        parent::__construct($stockResource, $stockRegistryProvider, $stockState, $stockConfiguration, $productRepository, $qtyCounter);
        $this->stockHelper = $stockHelper;
        $this->quantityCounterStock = $quantityCounterStock;
    }

    /**
     * @param $items
     * @param null $websiteId
     * @param null $storeId
     * @return array
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     */
    public function registerStoreProductsSale($items, $websiteId = null,$storeId = null)
    {
        if(!$storeId){
            $storeId = $this->stockHelper->getStoreId();
        }
        //if (!$websiteId) {
        $websiteId = $this->stockConfiguration->getDefaultScopeId();
        //}
        $this->getResource()->beginTransaction();
        $lockedItems = $this->getResource()->lockProductsStock(array_keys($items), $websiteId);
        $fullSaveItems = $registeredItems = [];
        foreach ($lockedItems as $lockedItemRecord) {
            $productId = $lockedItemRecord['product_id'];
            $product = $this->productRepository->getById($productId, true, $storeId);
            /** @var StockItemInterface $stockItem */
            $orderedQty = $items[$productId];
            $stockItem = $this->stockRegistryProvider->getStockItem($productId, $websiteId);
            $canSubtractQty = $stockItem->getItemId() && $this->canSubtractQty($stockItem);
            if (!$canSubtractQty || !$this->stockConfiguration->isQty($lockedItemRecord['type_id'])) {
                continue;
            }
            if ($this->canSubtractQty($stockItem)) {
                //$stockItem->setQty($stockItem->getQty() - $orderedQty);
                $newQuantity = $product->getStoreQuantity() - $orderedQty;
                $product->setStoreQuantity($newQuantity);
                if($newQuantity < 1){
                    $product->setStoreStockStatus(0);
                }
            }
            $registeredItems[$productId] = $orderedQty;
            if (!$this->verifyStoreStock($stockItem, $product)) {
                $fullSaveItems[] = $stockItem;
            }
            $product->save();
        }
        //$this->quantityCounterStock->correctItemsQty($registeredItems, $websiteId, '-');
        $this->getResource()->commit();
        return $fullSaveItems;
    }

    /**
     * @param string[] $items
     * @param int $websiteId
     * @return bool
     */
    public function revertStoreProductsSale($items, $websiteId = null,$storeId)
    {
        if(!$storeId){
            $storeId = $this->stockHelper->getStoreId();
        }
        //if (!$websiteId) {
        $websiteId = $this->stockConfiguration->getDefaultScopeId();
        //}
        //$this->quantityCounterStock->correctItemsQty($items, $websiteId, '+');
        foreach ($items as $productId => $qty) {
            try{
                $product = $this->productRepository->getById($productId,true, $storeId);
                $oldStoreQuantity = $product->getStoreQuantity();
                $newQty = intval($oldStoreQuantity) + intval($qty);
                $product->setStoreQuantity($newQty);
                if($newQty < 1){
                    $product->setStoreStockStatus(0);
                }
                $product->save();
            }
            catch (\Exception $e){

            }
        }
        return true;
    }

    /**
     * Get back to stock (when order is canceled or whatever else)
     *
     * @param int $productId
     * @param float $qty
     * @param int $scopeId
     * @return bool
     */
    public function backStoreItemQty($productId, $qty, $scopeId = null, $storeId)
    {
        if(!$storeId){
            $storeId = $this->stockHelper->getStoreId();
        }
        $product = $this->productRepository->getById($productId,true,$storeId);
        //if (!$scopeId) {
        $scopeId = $this->stockConfiguration->getDefaultScopeId();
        //}
        $stockItem = $this->stockRegistryProvider->getStockItem($productId, $scopeId);
        if ($stockItem->getItemId() && $this->stockConfiguration->isQty($this->getProductType($productId))) {
            if ($this->canSubtractQty($stockItem)) {
                $product->setStoreQuantity($product->getStoreQuantity() + $qty);
                //$stockItem->setQty($stockItem->getQty() + $qty);
            }
            if ($this->stockConfiguration->getCanBackInStock($stockItem->getStoreId()) && $stockItem->getQty()
                > $stockItem->getMinQty()
            ) {;
                $product->setStoreStockStatus(1);
            }
            $stockItem->save();
        }
        $product->save();
        return true;
    }

    /**
     * Get Product type
     *
     * @param int $productId
     * @return string
     */
    protected function getProductType($productId)
    {
        return $this->productRepository->getById($productId)->getTypeId();
    }

    /**
     * @return ResourceStock
     */
    protected function getResource()
    {
        return $this->resource;
    }

    /**
     * Check if is possible subtract value from item qty
     *
     * @param StockItemInterface $stockItem
     * @return bool
     */
    protected function canSubtractQty(StockItemInterface $stockItem)
    {
        return $stockItem->getManageStock() && $this->stockConfiguration->canSubtractQty();
    }

    /**
     * @param StockItemInterface $stockItem
     * @return bool
     */
    public function verifyStoreStock(StockItemInterface $stockItem,$product)
    {
        if ($product->getStoreQuantity() === null && $stockItem->getManageStock()) {
            return false;
        }
        if ($stockItem->getBackorders() == StockItemInterface::BACKORDERS_NO
            && $product->getStoreQuantity() <= $stockItem->getMinQty()
        ) {
            return false;
        }
        return true;
    }
}
