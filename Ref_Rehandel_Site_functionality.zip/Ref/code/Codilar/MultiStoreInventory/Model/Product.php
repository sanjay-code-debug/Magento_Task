<?php
/**
 * Copyright Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Codilar\MultiStoreInventory\Model;
use Magento\Catalog\Api\CategoryRepositoryInterface;
use Magento\Catalog\Api\ProductRepositoryInterface;
use Magento\Catalog\Model\Product\Attribute\Backend\Media\EntryConverterPool;
use Magento\Framework\Api\AttributeValueFactory;
use Psr\Log\LoggerInterface;

/**
 * Catalog product model
 *
 * @api
 * @method Product setHasError(bool $value)
 * @method null|bool getHasError()
 * @method array getAssociatedProductIds()
 * @method Product setNewVariationsAttributeSetId(int $value)
 * @method int getNewVariationsAttributeSetId()
 * @method int getPriceType()
 * @method string getUrlKey()
 * @method Product setUrlKey(string $urlKey)
 * @method Product setRequestPath(string $requestPath)
 * @method Product setWebsiteIds(array $ids)
 *
 * @SuppressWarnings(PHPMD.LongVariable)
 * @SuppressWarnings(PHPMD.ExcessivePublicCount)
 * @SuppressWarnings(PHPMD.TooManyFields)
 * @SuppressWarnings(PHPMD.ExcessiveClassComplexity)
 * @SuppressWarnings(PHPMD.CouplingBetweenObjects)
 * @since 100.0.2
 */
class Product extends \Magento\Catalog\Model\Product
{
    const STORE_QUANTITY = 'store_quantity';

    const MIN_SALE_STORE_QUANTITY = 'min_sale_store_quantity';

    const MAX_SALE_STORE_QUANTITY = 'max_sale_store_quantity';

    const STORE_STOCK_STATUS = 'store_stock_status';
    /**
     * @var \Codilar\MultiStoreInventory\Helper\Data
     */
    private $stockHelper;
    /**
     * @var ProductRepositoryInterface
     */
    private $productRepository;
    /**
     * @var LoggerInterface
     */
    private $logger;

    /**
     * Product constructor.
     * @param \Magento\Framework\Model\Context $context
     * @param \Magento\Framework\Registry $registry
     * @param \Magento\Framework\Api\ExtensionAttributesFactory $extensionFactory
     * @param AttributeValueFactory $customAttributeFactory
     * @param \Magento\Store\Model\StoreManagerInterface $storeManager
     * @param \Magento\Catalog\Api\ProductAttributeRepositoryInterface $metadataService
     * @param \Magento\Catalog\Model\Product\Url $url
     * @param \Magento\Catalog\Model\Product\Link $productLink
     * @param \Magento\Catalog\Model\Product\Configuration\Item\OptionFactory $itemOptionFactory
     * @param \Magento\CatalogInventory\Api\Data\StockItemInterfaceFactory $stockItemFactory
     * @param \Magento\Catalog\Model\Product\OptionFactory $catalogProductOptionFactory
     * @param \Magento\Catalog\Model\Product\Visibility $catalogProductVisibility
     * @param \Magento\Catalog\Model\Product\Attribute\Source\Status $catalogProductStatus
     * @param \Magento\Catalog\Model\Product\Media\Config $catalogProductMediaConfig
     * @param \Magento\Catalog\Model\Product\Type $catalogProductType
     * @param \Magento\Framework\Module\Manager $moduleManager
     * @param \Magento\Catalog\Helper\Product $catalogProduct
     * @param \Magento\Catalog\Model\ResourceModel\Product $resource
     * @param \Magento\Catalog\Model\ResourceModel\Product\Collection $resourceCollection
     * @param \Magento\Framework\Data\CollectionFactory $collectionFactory
     * @param \Magento\Framework\Filesystem $filesystem
     * @param \Magento\Framework\Indexer\IndexerRegistry $indexerRegistry
     * @param \Magento\Catalog\Model\Indexer\Product\Flat\Processor $productFlatIndexerProcessor
     * @param \Magento\Catalog\Model\Indexer\Product\Price\Processor $productPriceIndexerProcessor
     * @param \Magento\Catalog\Model\Indexer\Product\Eav\Processor $productEavIndexerProcessor
     * @param CategoryRepositoryInterface $categoryRepository
     * @param \Magento\Catalog\Model\Product\Image\CacheFactory $imageCacheFactory
     * @param \Magento\Catalog\Model\ProductLink\CollectionProvider $entityCollectionProvider
     * @param \Magento\Catalog\Model\Product\LinkTypeProvider $linkTypeProvider
     * @param \Magento\Catalog\Api\Data\ProductLinkInterfaceFactory $productLinkFactory
     * @param \Magento\Catalog\Api\Data\ProductLinkExtensionFactory $productLinkExtensionFactory
     * @param EntryConverterPool $mediaGalleryEntryConverterPool
     * @param \Magento\Framework\Api\DataObjectHelper $dataObjectHelper
     * @param \Magento\Framework\Api\ExtensionAttribute\JoinProcessorInterface $joinProcessor
     * @param \Codilar\MultiStoreInventory\Helper\Data $stockHelper
     * @param ProductRepositoryInterface $productRepository
     * @param LoggerInterface $logger
     * @param array $data
     */
    public function __construct(
        \Magento\Framework\Model\Context $context,
        \Magento\Framework\Registry $registry,
        \Magento\Framework\Api\ExtensionAttributesFactory $extensionFactory,
        AttributeValueFactory $customAttributeFactory,
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        \Magento\Catalog\Api\ProductAttributeRepositoryInterface $metadataService,
        \Magento\Catalog\Model\Product\Url $url,
        \Magento\Catalog\Model\Product\Link $productLink,
        \Magento\Catalog\Model\Product\Configuration\Item\OptionFactory $itemOptionFactory,
        \Magento\CatalogInventory\Api\Data\StockItemInterfaceFactory $stockItemFactory,
        \Magento\Catalog\Model\Product\OptionFactory $catalogProductOptionFactory,
        \Magento\Catalog\Model\Product\Visibility $catalogProductVisibility,
        \Magento\Catalog\Model\Product\Attribute\Source\Status $catalogProductStatus,
        \Magento\Catalog\Model\Product\Media\Config $catalogProductMediaConfig,
        \Magento\Catalog\Model\Product\Type $catalogProductType,
        \Magento\Framework\Module\Manager $moduleManager,
        \Magento\Catalog\Helper\Product $catalogProduct,
        \Magento\Catalog\Model\ResourceModel\Product $resource,
        \Magento\Catalog\Model\ResourceModel\Product\Collection $resourceCollection,
        \Magento\Framework\Data\CollectionFactory $collectionFactory,
        \Magento\Framework\Filesystem $filesystem,
        \Magento\Framework\Indexer\IndexerRegistry $indexerRegistry,
        \Magento\Catalog\Model\Indexer\Product\Flat\Processor $productFlatIndexerProcessor,
        \Magento\Catalog\Model\Indexer\Product\Price\Processor $productPriceIndexerProcessor,
        \Magento\Catalog\Model\Indexer\Product\Eav\Processor $productEavIndexerProcessor,
        CategoryRepositoryInterface $categoryRepository,
        \Magento\Catalog\Model\Product\Image\CacheFactory $imageCacheFactory,
        \Magento\Catalog\Model\ProductLink\CollectionProvider $entityCollectionProvider,
        \Magento\Catalog\Model\Product\LinkTypeProvider $linkTypeProvider,
        \Magento\Catalog\Api\Data\ProductLinkInterfaceFactory $productLinkFactory,
        \Magento\Catalog\Api\Data\ProductLinkExtensionFactory $productLinkExtensionFactory,
        EntryConverterPool $mediaGalleryEntryConverterPool,
        \Magento\Framework\Api\DataObjectHelper $dataObjectHelper,
        \Magento\Framework\Api\ExtensionAttribute\JoinProcessorInterface $joinProcessor,
        \Codilar\MultiStoreInventory\Helper\Data $stockHelper,
        ProductRepositoryInterface $productRepository,
        LoggerInterface $logger,
        array $data = [])
    {
        parent::__construct($context, $registry, $extensionFactory, $customAttributeFactory, $storeManager, $metadataService, $url, $productLink, $itemOptionFactory, $stockItemFactory, $catalogProductOptionFactory, $catalogProductVisibility, $catalogProductStatus, $catalogProductMediaConfig, $catalogProductType, $moduleManager, $catalogProduct, $resource, $resourceCollection, $collectionFactory, $filesystem, $indexerRegistry, $productFlatIndexerProcessor, $productPriceIndexerProcessor, $productEavIndexerProcessor, $categoryRepository, $imageCacheFactory, $entityCollectionProvider, $linkTypeProvider, $productLinkFactory, $productLinkExtensionFactory, $mediaGalleryEntryConverterPool, $dataObjectHelper, $joinProcessor, $data);
        $this->stockHelper = $stockHelper;
        $this->productRepository = $productRepository;
        $this->logger = $logger;
    }

    /**
     * Check is product available for sale
     *
     * @return bool
     */
    public function isSalable()
    {
        if($this->stockHelper->getMultiStoreInventoryModuleStatus()){
            if ($this->_catalogProduct->getSkipSaleableCheck()) {
                return true;
            }

            $this->_eventManager->dispatch('catalog_product_is_salable_before', ['product' => $this]);

            $salable = $this->isAvailable();

            $object = new \Magento\Framework\DataObject(['product' => $this, 'is_salable' => $salable]);
            $this->_eventManager->dispatch(
                'catalog_product_is_salable_after',
                ['product' => $this, 'salable' => $object]
            );
            $this->setData('salable', $object->getIsSalable());
            if($this->getTypeId() == "configurable"){
                $this->setData('salable', 1);
                return 1;
            }
            if($this->getTypeId() == "grouped"){
                $this->setData('salable', 1);
                return 1;
            }
            elseif($this->getAttributeValueUsingAttributeCode(self::STORE_STOCK_STATUS) == "0"){
                $this->setData('salable', 0);
                return 0;
            }
            elseif(!(int)$this->getAttributeValueUsingAttributeCode(self::STORE_QUANTITY) && (int)$this->getAttributeValueUsingAttributeCode(self::STORE_STOCK_STATUS) == "1"){
                $this->setData('salable', 1);
                return 1;
            }
            elseif((int)$this->getAttributeValueUsingAttributeCode(self::STORE_QUANTITY) < 1){
                $this->setData('salable', 1);
                return 1;
            }
            else{
                $this->setData('salable', 1);
                return 1;
            }
            return $this->getData('salable');
        }
        else{
            if ($this->_catalogProduct->getSkipSaleableCheck()) {
                return true;
            }
            if (($this->getOrigData('status') != $this->getData('status'))
                || $this->isStockStatusChanged()) {
                $this->unsetData('salable');
            }

            if ($this->hasData('salable')) {
                return $this->getData('salable');
            }
            $this->_eventManager->dispatch('catalog_product_is_salable_before', ['product' => $this]);

            $salable = $this->isAvailable();

            $object = new \Magento\Framework\DataObject(['product' => $this, 'is_salable' => $salable]);
            $this->_eventManager->dispatch(
                'catalog_product_is_salable_after',
                ['product' => $this, 'salable' => $object]
            );
            $this->setData('salable', $object->getIsSalable());

            return $this->getData('salable');
        }
    }

    /**
     * Check whether stock status changed
     *
     * @return bool
     */
    private function isStockStatusChanged()
    {
        $stockItem = null;
        $extendedAttributes = $this->getExtensionAttributes();
        if ($extendedAttributes !== null) {
            $stockItem = $extendedAttributes->getStockItem();
        }
        $stockData = $this->getStockData();
        return (
            (is_array($stockData))
            && array_key_exists('is_in_stock', $stockData)
            && (null !== $stockItem)
            && ($stockItem->getIsInStock() != $stockData['is_in_stock'])
        );
    }


    public function getAttributeValueUsingAttributeCode($attribute_code)
    {
        $storeid = $this->getStoreId();
        try{
            $_product = $this->productRepository->get($this->getSku(),false,$storeid);
            $_attribute = $_product->getResource()->getAttribute($attribute_code);
            if($_attribute){
                $_attribute_value = $_attribute->getFrontend()->getValue($_product);
                if($_attribute_value){
                    return $_attribute_value;
                }
            }
        }
        catch (\Exception $e){
            return 0;
        }
        return 0;
    }

}