<?php
namespace Codilar\MultiStoreInventory\Model\Config\Source;
/**
 * Class StockStatusOptions
 * @package Codilar\MultiStoreInventory\Model\Config\Source
 */
class StockStatusOptions extends \Magento\Eav\Model\Entity\Attribute\Source\AbstractSource
{
    /**
     * Get all options
     *
     * @return array
     */
    public function getAllOptions()
    {
        $this->_options = [
            ['label'=>'In Stock', 'value'=>'1'],
            ['label'=>'Out of Stock', 'value'=>'0']
        ];
        return $this->_options;
    }

    /**
     * Get a text for option value
     *
     * @param string|integer $value
     * @return string|bool
     */
    public function getOptionText($value)
    {
        foreach ($this->getAllOptions() as $option) {
            if ($option['value'] == $value) {
                return $option['label'];
            }
        }
        return false;
    }
}