<?php

namespace Codilar\MultiStoreInventory\Helper;
use Magento\Catalog\Model\Indexer\Product\Price\Processor as PriceIndexProcessor;
use Magento\CatalogInventory\Model\Indexer\Stock\Processor;
use Magento\Framework\App\Helper\Context;
use Magento\Sales\Api\OrderItemRepositoryInterface;
use Psr\Log\LoggerInterface;
use Magento\Catalog\Api\ProductRepositoryInterface;
use Magento\Customer\Model\Session;
use Magento\Sales\Api\OrderRepositoryInterface;
use Magento\Sales\Model\ResourceModel\Order\CollectionFactory;
use Magento\Store\Model\StoreManager;
/**
 * Class Data
 * @package Codilar\MultiStoreInventory\Helper
 */
class Data extends \Magento\Framework\App\Helper\AbstractHelper
{
    const STORE_STOCK_STATUS = 'store_stock_status';

    const STORE_QUANTITY = 'store_quantity';

    const MAX_SALE_STORE_QUANTITY = 'max_sale_store_quantity';

    const MIN_SALE_STORE_QUANTITY = 'min_sale_store_quantity';
    /**
     * @var $_scopeConfigInterface
     */
    protected $_scopeConfig;
    /**
     * @var LoggerInterface
     */
    protected $_logger;
    /**
     * @var CollectionFactory
     */
    protected $_orderCollectionFactory;
    /**
     * @var OrderRepositoryInterface
     */
    private $orderRepository;
    /**
     * @var ProductRepositoryInterface
     */
    private $productRepository;
    /**
     * @var StoreManager
     */
    private $storeManager;
    /**
     * @var Session
     */
    private $customerSession;
    /**
     * @var OrderItemRepositoryInterface
     */
    private $orderItemRepository;
    /**
     * @var Processor
     */
    private $processor;
    /**
     * @var PriceIndexProcessor
     */
    private $priceIndexer;

    /**
     * Data constructor.
     * @param Context $context
     * @param LoggerInterface $loggerInterface
     * @param OrderRepositoryInterface $orderRepository
     * @param ProductRepositoryInterface $productRepository
     * @param StoreManager $storeManager
     * @param Session $customerSession
     * @param CollectionFactory $orderCollectionFactory
     * @param OrderItemRepositoryInterface $orderItemRepository
     * @param PriceIndexProcessor $priceIndexer
     * @param Processor $processor
     */
    public function __construct(
        Context $context,
        LoggerInterface $loggerInterface,
        OrderRepositoryInterface $orderRepository,
        ProductRepositoryInterface $productRepository,
        StoreManager $storeManager,
        Session $customerSession,
        CollectionFactory $orderCollectionFactory,
        OrderItemRepositoryInterface $orderItemRepository,
        PriceIndexProcessor $priceIndexer,
        Processor $processor
    )
    {
        parent::__construct($context);
        $this->_scopeConfig = $context->getScopeConfig();
        $this->_logger = $loggerInterface;
        $this->orderRepository = $orderRepository;
        $this->productRepository = $productRepository;
        $this->storeManager = $storeManager;
        $this->_orderCollectionFactory = $orderCollectionFactory;
        $this->customerSession = $customerSession;
        $this->orderItemRepository = $orderItemRepository;
        $this->processor = $processor;
        $this->priceIndexer = $priceIndexer;
    }

    /**
     * This function will return module status 0/1
     * @param null
     * @return boolean
     */
    public function getMultiStoreInventoryModuleStatus()
    {
        return $this->_scopeConfig->getValue('multistore/inventory/module_status', \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
    }

    /**
     * This function will return store id
     * @return int
     */
    public function getStoreId()
    {
        $this->storeManager->getWebsite()->getStoreId();
        return $this->storeManager->getStore()->getId();
    }

    /**
     * This function will return whether max_purchase module is enabled/disabled
     * @param null
     * @return boolean
     */
    public function isMaxPurchaseModuleEnabled()
    {
        return $this->_scopeConfig->getValue('multistore/product_inventory/max_sale_qty_status', \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
    }

    /**
     * @param $productId
     * @param $fromDate
     * @param $toDate
     * @return int
     */
    public function getProductCountInPreviousOrders($productId, $fromDate, $toDate)
    {
        try {
            if ($this->customerSession->isLoggedIn()) {
                $customerId = $this->customerSession->getCustomerId();
                $time = strtotime($toDate);
                if ($fromDate && $toDate) {
                    $toDate = date('Y-m-d 23:59:59', $time);
                    $orders = $this->_orderCollectionFactory->create()
                        ->addFieldToFilter('customer_id', $customerId)
                        ->addAttributeToFilter('created_at', ['from' => $fromDate, 'to' => $toDate]);
                    if (count($orders)) {
                        $itemCount = 0;
                        foreach ($orders as $order) {
                            $allItems = $order->getAllVisibleItems();
                            foreach ($allItems as $item) {
                                $itemProductId = $item->getProductId();
                                if ($itemProductId == $productId) {
                                    $qty = $item->getQtyOrdered();
                                    $itemCount = $itemCount + $qty;
                                }
                            }
                        }
                        return $itemCount;
                    }
                }
            } else {
                return 0;
            }
            return 0;
        } catch (\Exception $e) {
            return 0;
        }
    }

    /**
     * @param $itemId
     * @return \Magento\Sales\Api\Data\OrderItemInterface
     */
    public function getOrderItem($itemId){
        $orderItem = $this->orderItemRepository->get($itemId);
        return $orderItem;
    }

    /**
     * @param $storeId
     * @return \Magento\Store\Api\Data\StoreInterface|null|string
     */
    public function getStore($storeId){
        return $this->storeManager->getStore($storeId);
    }

    /**
     * @param $updatedItemIds
     */
    public function reindexList($updatedItemIds){
        $this->processor->reindexList($updatedItemIds);
    }

    /**
     * @param $updatedItemIds
     */
    public function reindexPriceList($updatedItemIds){
        $this->priceIndexer->reindexList($updatedItemIds);
    }

    /**
     * @param $message
     */
    public function logMessage($message){
        $this->_logger->debug($message);
    }
}