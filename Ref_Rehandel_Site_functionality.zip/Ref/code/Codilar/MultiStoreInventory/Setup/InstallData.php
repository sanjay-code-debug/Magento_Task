<?php

namespace Codilar\MultiStoreInventory\Setup;

use Magento\Framework\Setup\InstallDataInterface;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\ModuleDataSetupInterface;
use Magento\Eav\Setup\EavSetupFactory;

/**
 * Class InstallData
 * @package Codilar\MultiStoreInventory\Setup
 */
class InstallData implements InstallDataInterface
{
    /**
     * @var EavSetupFactory
     */
    private $eavSetupFactory;

    /**
     * InstallData constructor.
     * @param EavSetupFactory $eavSetupFactory
     */
    public function __construct(EavSetupFactory $eavSetupFactory)
    {
        $this->eavSetupFactory = $eavSetupFactory;
    }

    /**
     * @param ModuleDataSetupInterface $setup
     * @param ModuleContextInterface $context
     */
    public function install(ModuleDataSetupInterface $setup, ModuleContextInterface $context)
    {
        $setup->startSetup();
        $this->createProductStoreQtyAtrribute($setup);
        $this->createProductMinSaleStoreQtyAtrribute($setup);
        $this->createProductMaxSaleStoreQtyAtrribute($setup);
        $this->createProductStoreStockStatusAtrribute($setup);
    }

    /**
     * @param $setup
     */
    private function createProductStoreQtyAtrribute($setup)
    {
        $eavSetup = $this->eavSetupFactory->create(['setup' => $setup]);

        $eavSetup->addAttribute(
            \Magento\Catalog\Model\Product::ENTITY,
            'store_quantity',/* Custom Attribute Code */
            [
                'group' => 'MultiStore Inventory',
                'type' => 'int',/* Data type in which formate your value save in database*/
                'backend' => '',
                'frontend' => '',
                'label' => 'Store Quantity', /* lable of your attribute*/
                'input' => 'text',
                'class' => '',
                'source' => '',
                /* Source of your select type custom attribute options*/
                'global' => \Magento\Eav\Model\Entity\Attribute\ScopedAttributeInterface::SCOPE_STORE,
                /*Scope of your attribute */
                'visible' => true,
                'required' => false,
                'user_defined' => true,
                'default' => '',
                'searchable' => false,
                'filterable' => false,
                'comparable' => false,
                'visible_on_front' => false,
                'used_in_product_listing' => false,
                'unique' => false,
                'is_used_in_grid' => true,
                'is_visible_in_grid' => true,
                'is_searchable_in_grid' => true,
                'is_filterable_in_grid' => true,
            ]
        );

    }

    /**
     * @param $setup
     */
    private function createProductMinSaleStoreQtyAtrribute($setup)
    {
        $eavSetup = $this->eavSetupFactory->create(['setup' => $setup]);

        /**
         * Add attributes to the eav/attribute
         */
        $eavSetup->addAttribute(
            \Magento\Catalog\Model\Product::ENTITY,
            'min_sale_store_quantity',/* Custom Attribute Code */
            [
                'group' => 'MultiStore Inventory',
                'type' => 'int',/* Data type in which formate your value save in database*/
                'backend' => '',
                'frontend' => '',
                'label' => 'Minimum Qty Allowed in Shopping Cart', /* lable of your attribute*/
                'input' => 'text',
                'class' => '',
                'source' => '',
                /* Source of your select type custom attribute options*/
                'global' => \Magento\Eav\Model\Entity\Attribute\ScopedAttributeInterface::SCOPE_STORE,
                /*Scope of your attribute */
                'visible' => true,
                'required' => false,
                'user_defined' => true,
                'default' => '1',
                'searchable' => false,
                'filterable' => false,
                'comparable' => false,
                'visible_on_front' => false,
                'used_in_product_listing' => false,
                'unique' => false,
                'is_used_in_grid' => false,
                'is_visible_in_grid' => false,
                'is_searchable_in_grid' => false,
                'is_filterable_in_grid' => false,
            ]
        );

    }

    /**
     * @param $setup
     */
    private function createProductMaxSaleStoreQtyAtrribute($setup)
    {
        $eavSetup = $this->eavSetupFactory->create(['setup' => $setup]);

        /**
         * Add attributes to the eav/attribute
         */
        $eavSetup->addAttribute(
            \Magento\Catalog\Model\Product::ENTITY,
            'max_sale_store_quantity',/* Custom Attribute Code */
            [
                'group' => 'MultiStore Inventory',
                'type' => 'int',/* Data type in which formate your value save in database*/
                'backend' => '',
                'frontend' => '',
                'label' => 'Maximum Qty Allowed in Shopping Cart', /* lable of your attribute*/
                'input' => 'text',
                'class' => '',
                'source' => '',
                /* Source of your select type custom attribute options*/
                'global' => \Magento\Eav\Model\Entity\Attribute\ScopedAttributeInterface::SCOPE_STORE,
                /*Scope of your attribute */
                'visible' => true,
                'required' => false,
                'user_defined' => true,
                'default' => '100',
                'searchable' => false,
                'filterable' => false,
                'comparable' => false,
                'visible_on_front' => false,
                'used_in_product_listing' => false,
                'unique' => false,
                'is_used_in_grid' => false,
                'is_visible_in_grid' => false,
                'is_searchable_in_grid' => false,
                'is_filterable_in_grid' => false,
            ]
        );
    }

    /**
     * @param $setup
     */
    private function createProductStoreStockStatusAtrribute($setup)
    {
        $eavSetup = $this->eavSetupFactory->create(['setup' => $setup]);

        /**
         * Add attributes to the eav/attribute
         */
        $eavSetup->addAttribute(
            \Magento\Catalog\Model\Product::ENTITY,
            'store_stock_status',/* Custom Attribute Code */
            [
                'group' => 'MultiStore Inventory',
                'type' => 'text',
                'backend' => 'Magento\Eav\Model\Entity\Attribute\Backend\ArrayBackend',
                'frontend' => '',
                'label' => 'Store Stock Status',
                'input' => 'select',
                'class' => '',
                'source' => 'Codilar\MultiStoreInventory\Model\Config\Source\StockStatusOptions',
                'option' => [
                    'values' => [],
                ],
                /* Source of your select type custom attribute options*/
                'global' => \Magento\Eav\Model\Entity\Attribute\ScopedAttributeInterface::SCOPE_STORE,
                /*Scope of your attribute */
                'visible' => true,
                'required' => false,
                'user_defined' => true,
                'default' => '',
                'searchable' => false,
                'filterable' => false,
                'comparable' => false,
                'visible_on_front' => false,
                'used_in_product_listing' => true,
                'unique' => false,
                'is_searchable' => true,
                'is_used_in_grid' => true,
                'is_visible_in_grid' => true,
                'is_searchable_in_grid' => true,
                'is_filterable_in_grid' => true
            ]
        );
    }
}
