<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */

namespace Codilar\MultiStoreInventory\Observer;

use Magento\CatalogInventory\Observer\ProductQty;
use Magento\Framework\Event\ObserverInterface;
use Magento\CatalogInventory\Api\StockManagementInterface;
use Magento\Framework\Event\Observer as EventObserver;
use Codilar\MultiStoreInventory\Model\StockManagement;
use Codilar\MultiStoreInventory\Helper\Data;

/**
 * Catalog inventory module observer
 */
class RevertQuoteInventoryObserver extends \Magento\CatalogInventory\Observer\RevertQuoteInventoryObserver
{
    /**
     * @var ProductQty
     */
    protected $productQty;

    /**
     * @var StockManagementInterface
     */
    protected $stockManagement;

    /**
     * @var \Magento\CatalogInventory\Model\Indexer\Stock\Processor
     */
    protected $stockIndexerProcessor;

    /**
     * @var \Magento\Catalog\Model\Indexer\Product\Price\Processor
     */
    protected $priceIndexer;
    /**
     * @var Data
     */
    private $stockHelper;
    /**
     * @var StockManagement
     */
    private $codilarStockManagement;

    /**
     * RevertQuoteInventoryObserver constructor.
     * @param ProductQty $productQty
     * @param StockManagementInterface $stockManagement
     * @param \Magento\CatalogInventory\Model\Indexer\Stock\Processor $stockIndexerProcessor
     * @param \Magento\Catalog\Model\Indexer\Product\Price\Processor $priceIndexer
     * @param Data $stockHelper
     * @param StockManagement $codilarStockManagement
     */
    public function __construct(
        ProductQty $productQty,
        StockManagementInterface $stockManagement,
        \Magento\CatalogInventory\Model\Indexer\Stock\Processor $stockIndexerProcessor,
        \Magento\Catalog\Model\Indexer\Product\Price\Processor $priceIndexer,
        Data $stockHelper,
        StockManagement $codilarStockManagement
    )
    {
        parent::__construct($productQty, $stockManagement, $stockIndexerProcessor, $priceIndexer);
        $this->stockHelper = $stockHelper;
        $this->codilarStockManagement = $codilarStockManagement;
    }

    /**
     * Revert quote items inventory data (cover not success order place case)
     *
     * @param EventObserver $observer
     * @return void
     */
    public function execute(EventObserver $observer)
    {
        $quote = $observer->getEvent()->getQuote();
        $items = $this->productQty->getProductQty($quote->getAllItems());
        if($this->stockHelper->getMultiStoreInventoryModuleStatus()){
            $this->codilarStockManagement->revertStoreProductsSale($items, $quote->getStore()->getWebsiteId(),$quote->getStoreId());
        }
        else{
            $this->stockManagement->revertProductsSale($items, $quote->getStore()->getWebsiteId());
        }
        $productIds = array_keys($items);
        if (!empty($productIds)) {
            $this->stockIndexerProcessor->reindexList($productIds);
            $this->priceIndexer->reindexList($productIds);
        }
        // Clear flag, so if order placement retried again with success - it will be processed
        $quote->setInventoryProcessed(false);
    }
}
