<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */

namespace Codilar\MultiStoreInventory\Observer;

use Codilar\MultiStoreInventory\Model\StockManagement;
use Magento\CatalogInventory\Observer\ItemsForReindex;
use Magento\CatalogInventory\Observer\ProductQty;
use Magento\Framework\Event\ObserverInterface;
use Magento\CatalogInventory\Api\StockManagementInterface;
use Magento\Framework\Event\Observer as EventObserver;
use Codilar\MultiStoreInventory\Helper\Data;

/**
 * Catalog inventory module observer
 */
class SubtractQuoteInventoryObserver extends \Magento\CatalogInventory\Observer\SubtractQuoteInventoryObserver
{
    /**
     * @var StockManagementInterface
     */
    protected $stockManagement;

    /**
     * @var ProductQty
     */
    protected $productQty;

    /**
     * @var \Magento\CatalogInventory\Observer\ItemsForReindex
     */
    protected $itemsForReindex;
    /**
     * @var Data
     */
    private $stockHelper;
    /**
     * @var StockManagement
     */
    private $codilarStockManagement;

    /**
     * SubtractQuoteInventoryObserver constructor.
     * @param StockManagementInterface $stockManagement
     * @param ProductQty $productQty
     * @param ItemsForReindex $itemsForReindex
     * @param Data $stockHelper
     * @param StockManagement $codilarStockManagement
     */
    public function __construct(
        StockManagementInterface $stockManagement,
        ProductQty $productQty,
        ItemsForReindex $itemsForReindex,
        Data $stockHelper,
        StockManagement $codilarStockManagement
    )
    {
        parent::__construct($stockManagement, $productQty, $itemsForReindex);
        $this->stockHelper = $stockHelper;
        $this->codilarStockManagement = $codilarStockManagement;
    }

    /**
     * @param EventObserver $observer
     * @return $this
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function execute(EventObserver $observer)
    {
        /** @var \Magento\Quote\Model\Quote $quote */
        $quote = $observer->getEvent()->getQuote();

        // Maybe we've already processed this quote in some event during order placement
        // e.g. call in event 'sales_model_service_quote_submit_before' and later in 'checkout_submit_all_after'
        if ($quote->getInventoryProcessed()) {
            return $this;
        }
        $items = $this->productQty->getProductQty($quote->getAllItems());

        if($this->stockHelper->getMultiStoreInventoryModuleStatus()){
            /**
             * Remember items
             */
            $itemsForReindex = $this->codilarStockManagement->registerStoreProductsSale(
                $items,
                $quote->getStore()->getWebsiteId(),
                $quote->getStoreId()
            );
        }
        else{
            /**
             * Remember items
             */
            $itemsForReindex = $this->stockManagement->registerProductsSale(
                $items,
                $quote->getStore()->getWebsiteId()
            );
        }
        $this->itemsForReindex->setItems($itemsForReindex);

        $quote->setInventoryProcessed(true);
        return $this;
    }
}
