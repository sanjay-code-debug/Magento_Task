<?php

namespace Codilar\MultiStoreInventory\Observer;

use Magento\Framework\Event\Observer;
use Magento\Framework\Event\ObserverInterface;
use Psr\Log\LoggerInterface;
use Codilar\MultiStoreInventory\Helper\Data;
/**
 * Class ProductCollection
 * @package Codilar\MultiStoreInventory\Observer
 */
class ProductCollection implements ObserverInterface
{
    /**
     * @var LoggerInterface
     */
    private $logger;
    /**
     * @var Data
     */
    private $stockHelper;

    /**
     * ProductSaveAfter constructor.
     * @param LoggerInterface $logger
     * @param Data $stockHelper
     */
    public function __construct(
        LoggerInterface $logger,
        Data $stockHelper
    )
    {
        $this->logger = $logger;
        $this->stockHelper = $stockHelper;
    }

    public function execute(Observer $observer)
    {
        if($this->stockHelper->getMultiStoreInventoryModuleStatus()){
            $collection = $observer->getCollection();
            //$collection->addAttributeToFilter("store_stock_status",1);
            //$collection->addFieldToFilter("store_stock_status",1);

            return $collection;
        }
    }
}
