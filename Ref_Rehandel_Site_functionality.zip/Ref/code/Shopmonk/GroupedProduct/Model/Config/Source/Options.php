<?php
/**
 * Created by salman.
 * Date: 19/3/18
 * Time: 1:53 PM
 * Filename: Options.php
 */

namespace Shopmonk\GroupedProduct\Model\Config\Source;

use Magento\Eav\Model\ResourceModel\Entity\Attribute\OptionFactory;
use Magento\Framework\DB\Ddl\Table;

/**
 * Class Options
 * @package Shopmonk\GroupedProduct\Model\Config\Source
 */
class Options extends \Magento\Eav\Model\Entity\Attribute\Source\AbstractSource
{
    /**
     * @var OptionFactory
     */
    protected $optionFactory;

    /**
     * @param OptionFactory $optionFactory
     */
    /*public function __construct(OptionFactory $optionFactory)
    {
        $this->optionFactory = $optionFactory;
        //you can use this if you want to prepare options dynamically
    }*/

    /**
     * Get a text for option value
     *
     * @param string|integer $value
     * @return string|bool
     */
    public function getOptionText($value)
    {
        foreach ($this->getAllOptions() as $option) {
            if ($option['value'] == $value) {
                return $option['label'];
            }
        }
        return false;
    }

    /**
     * Get all options
     *
     * @return array
     */
    public function getAllOptions()
    {
        /* your Attribute options list*/
        $this->_options = [
            ['label' => 'storage A', 'value' => 'storage A'],
            ['label' => 'storage X', 'value' => 'storage X'],
            ['label' => 'storage Y', 'value' => 'storage Y'],
            ['label' => 'color A', 'value' => 'color A'],
            ['label' => 'color X', 'value' => 'color X'],
            ['label' => 'color Y', 'value' => 'color Y'],
            ['label' => 'size X', 'value' => 'size X'],
            ['label' => 'size Y', 'value' => 'size Y'],
            ['label' => 'manufacturer X', 'value' => 'manufacturer X'],
            ['label' => 'manufacturer Y', 'value' => 'manufacturer Y'],
            ['label' => 'ram X', 'value' => 'ram X'],
            ['label' => 'ram Y', 'value' => 'ram Y'],
            ['label' => 'grade A', 'value' => 'grade A'],
            ['label' => 'grade X', 'value' => 'grade X'],
            ['label' => 'grade Y', 'value' => 'grade Y']
        ];
        return $this->_options;
    }

    /**
     * Retrieve flat column definition
     *
     * @return array
     */
    public function getFlatColumns()
    {
        $attributeCode = $this->getAttribute()->getAttributeCode();
        return [
            $attributeCode => [
                'unsigned' => false,
                'default' => null,
                'extra' => null,
                'type' => Table::TYPE_TEXT,
                'nullable' => true,
                'comment' => 'Group Tier Attributes  ' . $attributeCode . ' column',
            ],
        ];
    }
}
