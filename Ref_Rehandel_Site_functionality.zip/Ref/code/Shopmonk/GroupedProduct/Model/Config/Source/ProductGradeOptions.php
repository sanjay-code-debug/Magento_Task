<?php

namespace Shopmonk\GroupedProduct\Model\Config\Source;

use Magento\Eav\Model\ResourceModel\Entity\Attribute\OptionFactory;

/**
 * Class ProductGradeOptions
 * @package Shopmonk\GroupedProduct\Model\Config\Source
 */
class ProductGradeOptions extends \Magento\Eav\Model\Entity\Attribute\Source\AbstractSource
{
    /**
     * @var OptionFactory
     */
    protected $optionFactory;

    /**
     * Get a text for option value
     *
     * @param string|integer $value
     * @return string|bool
     */
    public function getOptionText($value)
    {
        foreach ($this->getAllOptions() as $option) {
            if ($option['value'] == $value) {
                return $option['label'];
            }
        }
        return false;
    }

    /**
     * Get all options
     *
     * @return array
     */
    public function getAllOptions()
    {
        /* your Attribute options list*/
        $this->_options = [
            ['label' => 'A+', 'value' => 'A+'],
            ['label' => 'A', 'value' => 'A'],
            ['label' => 'B', 'value' => 'B'],
            ['label' => 'C', 'value' => 'C']
        ];
        return $this->_options;
    }
}
