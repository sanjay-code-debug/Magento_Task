<?php
/**
 * Created by salman.
 * Date: 15/3/18
 * Time: 5:31 PM
 * Filename: Grouped.php
 */

namespace Shopmonk\GroupedProduct\Model\Product\Type;

/**
 * Class Grouped
 * @package Shopmonk\GroupedProduct\Model\Product\Type
 */
class Grouped extends \Magento\GroupedProduct\Model\Product\Type\Grouped
{

    /**
     * Retrieve array of associated products
     *
     * @param \Magento\Catalog\Model\Product $product
     * @return array
     */
    public function getAssociatedProducts($product)
    {

        $frontend_attributes = array('name', 'ram', 'size', 'storage', 'color', 'price', 'special_price', 'special_from_date', 'special_to_date', 'tax_class_id', 'grade');

        if (!$product->hasData($this->_keyAssociatedProducts)) {
            $associatedProducts = [];

            $this->setSaleableStatus($product);

            $collection = $this->getAssociatedProductCollection(
                $product
            )->addAttributeToSelect(
                $frontend_attributes
            )->addFilterByRequiredOptions()->setPositionOrder()->addStoreFilter(
                $this->getStoreFilter($product)
            )->addAttributeToFilter(
                'status',
                ['in' => $this->getStatusFilters($product)]
            );
            foreach ($collection as $item) {
                foreach($frontend_attributes as $attribute){
                  $item[$attribute.'_value'] = $item->getResource()->getAttribute($attribute)->getFrontend()->getValue($item);
                }
             $associatedProducts[] = $item;
            }
            $product->setData($this->_keyAssociatedProducts, $associatedProducts);
        }
        return $product->getData($this->_keyAssociatedProducts);
    }

    /**
     * Retrieve collection of associated products
     *
     * @param \Magento\Catalog\Model\Product $product
     * @return \Magento\Catalog\Model\ResourceModel\Product\Link\Product\Collection
     */
    public function getAssociatedProductCollection($product)
    {
        /** @var \Magento\Catalog\Model\Product\Link $links */
        $links = $product->getLinkInstance();
        $links->setLinkTypeId(\Magento\GroupedProduct\Model\ResourceModel\Product\Link::LINK_TYPE_GROUPED);
        $collection = $links->getProductCollection()->setFlag(
            'product_children',
            true
        )->setIsStrongMode();
        $collection->setProduct($product);
        return $collection;
    }

    /**
     * @param $_associatedProducts
     * @return array
     */
    public function getAllStorageValues($_associatedProducts)
    {
        $values = [];
        foreach ($_associatedProducts as $data) {
            if ($data->getStorageValue()) {
                $values[] = $data->getStorageValue();
            }
        }
        return $values;
    }


}