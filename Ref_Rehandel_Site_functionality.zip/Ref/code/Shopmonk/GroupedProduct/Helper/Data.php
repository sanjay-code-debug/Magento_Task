<?php
/**
 * Created by salman.
 * Date: 15/3/18
 * Time: 3:48 PM
 * Filename: Data.php
 */

namespace Shopmonk\GroupedProduct\Helper;


use Magento\Catalog\Api\ProductRepositoryInterface;
use Magento\CatalogInventory\Api\StockRegistryInterface;
use Magento\Customer\Model\Session;
use Magento\Directory\Model\CurrencyFactory;
use Magento\Framework\App\Helper\AbstractHelper;
use Magento\Framework\App\Helper\Context;
use Magento\Store\Model\StoreManagerInterface;


/**
 * Class Data
 * @package Shopmonk\GroupedProduct\Helper
 */
class Data extends AbstractHelper
{

    /**
     * @var StoreManagerInterface
     */
    protected $storeconfig;
    /**
     * @var CurrencyFactory
     */
    protected $currencycode;
    /**
     * @var Session
     */
    protected $session;
    /**
     * @var
     */
    protected $tier_x;
    /**
     * @var
     */
    protected $tier_y;
    /**
     * @var
     */
    protected $tier_a;
    /**
     * @var StoreManagerInterface
     */
    private $storeManager;
    /**
     * @var ProductRepositoryInterface
     */
    private $productRepository;
    /**
     * @var \Codilar\MultiStoreInventory\Helper\Data
     */
    private $multiStoreInventoryHelper;
    /**
     * @var StockRegistryInterface
     */
    private $stockRegistry;

    /**
     * Data constructor.
     * @param StoreManagerInterface $storeconfig
     * @param CurrencyFactory $currencycode
     * @param Context $context
     * @param Session $session
     * @param StoreManagerInterface $storeManager
     * @param ProductRepositoryInterface $productRepository
     * @param \Codilar\MultiStoreInventory\Helper\Data $multiStoreInventoryHelper
     * @param StockRegistryInterface $stockRegistry
     */
    public function __construct(
        StoreManagerInterface $storeconfig,
        CurrencyFactory $currencycode,
        Context $context,
        Session $session,
        StoreManagerInterface $storeManager,
        ProductRepositoryInterface $productRepository,
        \Codilar\MultiStoreInventory\Helper\Data $multiStoreInventoryHelper,
        StockRegistryInterface $stockRegistry
    )
    {
        $this->storeconfig = $storeconfig;
        $this->session = $session;
        $this->currencycode = $currencycode;
        parent::__construct($context);
        $this->storeManager = $storeManager;
        $this->productRepository = $productRepository;
        $this->multiStoreInventoryHelper = $multiStoreInventoryHelper;
        $this->stockRegistry = $stockRegistry;
    }

    /**
     * @param $_product
     * @return bool
     */
    public function useSmkGroupedProductDesign($_product)
    {
        // $this->tier_x = $this->tier_y = null;
        $groupTierAttributes = $_product->getGroupTierAttributes();
        //print_r($groupTierAttributes);die;
        $groupTierAttributes = explode(",", $groupTierAttributes);
        $groupTierAttributes = is_array($groupTierAttributes) ? $groupTierAttributes : [$groupTierAttributes];
        if (!empty($groupTierAttributes)) {
            foreach ($groupTierAttributes as $value) {
                $data = explode(" ", $value);
                if (end($data) == 'X') {
                    $this->tier_x = reset($data);
                } elseif (end($data) == 'Y') {
                    $this->tier_y = reset($data);
                } elseif (end($data) == 'A') {
                    $this->tier_a = reset($data);
                }
            }
            if (empty($this->tier_x) || ($this->tier_x == $this->tier_y)) {
                $this->tier_x = $this->tier_y;
                $this->tier_y = NULL;
            }
            return !empty($this->tier_x);
        }
        return false;
    }

    /**
     * @param $_product
     * @return bool
     */
    public function isProductNew($_product)
    {
        try {
            $_attribute = $_product->getResource()->getAttribute("used_new");
            if ($_attribute) {
                $_attribute_value = $_attribute->getFrontend()->getValue($_product);
                if ($_attribute_value == "used") {
                    return false;
                }
            }

            return true;
        } catch (\Exception $e) {
            return true;
        }
    }

    /**
     * @param $_associatedProducts
     * @return array
     */
    public function getSmkGroupedProductTiers($_associatedProducts)
    {
        $tierY = [];
        $productData = [];
        $tierPrices = ['currency' => $this->getCurrencySymbol()];

        foreach ($_associatedProducts as $data) {
            if ($data->getData($this->tier_y . '_value') && !in_array($data->getData($this->tier_y . '_value'), $tierY)) {
                $tierY[] = $data->getData($this->tier_y . '_value');
            }
            if (!empty($data->getTierPrice())) {
                $lastTier = 1;
                $tierSize = count($data->getTierPrice());
                $tierSizeCount = 1;
                foreach ($data->getTierPrice() as $k => $tier) {
                    if ($lastTier != 1 && ($tier['price_qty'] - 1 != $lastTier['price_qty'])) {
                        for ($i = $lastTier['price_qty'] + 1; $i <= ($tier['price_qty'] - 1); $i++) {
                            $itemTierPrice = is_null($lastTier['percentage_value']) ? ($i * $lastTier['price']) : $lastTier['price'];
                            $tierPrices[$data->getId()][$i * 1] =
                                [
                                    'price' => round($itemTierPrice,2),
                                    'isPercent' => $lastTier['percentage_value']
                                ];
                        }
                    }
                    $itemTierPrice = is_null($tier['percentage_value']) ? ($tier['price_qty'] * $tier['price']) : $tier['price'];
                    $tierPrices[$data->getId()][$tier['price_qty'] * 1] =
                        [
                            'price' => round($itemTierPrice,2),
                            'isPercent' => $tier['percentage_value']
                        ];
                    $lastTier = $tier;
                    if($tierSizeCount == $tierSize && is_null($tier['percentage_value'])){
                        for ($i = $tier['price_qty'] + 1; $i <= 100; $i++) {
                            $itemTierPrice = is_null($tier['percentage_value']) ? ($i * $tier['price']) : $tier['price'];
                            $tierPrices[$data->getId()][$i * 1] =
                                [
                                    'price' => round($itemTierPrice,2),
                                    'isPercent' => $tier['percentage_value']
                                ];
                        }
                    }
                    $tierSizeCount += 1;
                }
            }
            $productStock = $this->getProductInventoryByProductSku($data->getSku());
            $data['inventory'] = $productStock;
            $productDataPush = $data->__toArray($data->getTierPrice());
            if (empty($this->tier_y)) {
                $productData[$data->getData($this->tier_x . '_value')][$data->getData($this->tier_x . '_value')] = $productDataPush;
            } else {
                $productData[$data->getData($this->tier_x . '_value')][$data->getData($this->tier_y . '_value')] = $productDataPush;
            }
            ksort($productData[$data->getData($this->tier_x . '_value')]);
        }
        sort($tierY);
        return [
            'tier_prices' => $tierPrices,
            'tier_y' => !empty($tierY) && $this->tier_y ? $tierY : array_keys($productData),
            'tier_y_labels' => !empty($tierY) && $this->tier_y ? $tierY : [],
            'tier_x' => $productData
        ];
    }

    /**
     * @return string
     */
    public function getCurrencySymbol()
    {
        $currentCurrency = $this->storeconfig->getStore()->getCurrentCurrencyCode();
        $currency = $this->currencycode->create()->load($currentCurrency);
        if($currency->getCurrencySymbol()) {
            return $currency->getCurrencySymbol();
        }
        return $currency->getCode();
    }

    /**
     * @param $_associatedProducts
     * @return array
     */
    public function getSmkGroupedProductTiersUsed($_associatedProducts)
    {
        $tierY = [];
        $tierA = [];
        $productData = [];
        $tierPrices = ['currency' => $this->getCurrencySymbol()];
        $tierOriginalPrices = [];
        foreach ($_associatedProducts as $data) {
            $tierOriginalPrices[$data->getId()] = ($data->getFinalPrice()) ? $data->getFinalPrice() : '0';
            if ($data->getData($this->tier_y . '_value') && !in_array($data->getData($this->tier_y . '_value'), $tierY)) {
                $tierY[] = $data->getData($this->tier_y . '_value');
            }
            if ($data->getData($this->tier_a . '_value') && !in_array($data->getData($this->tier_a . '_value'), $tierA)) {
                $tierA[] = $data->getData($this->tier_a . '_value');
            }
            if (!empty($data->getTierPrice())) {
                $lastTier = 1;
                $tierSize = count($data->getTierPrice());
                $tierSizeCount = 1;
                foreach ($data->getTierPrice() as $k => $tier) {
                    if ($lastTier != 1 && ($tier['price_qty'] - 1 != $lastTier['price_qty'])) {
                        for ($i = $lastTier['price_qty'] + 1; $i <= ($tier['price_qty'] - 1); $i++) {
                            $itemTierPrice = is_null($lastTier['percentage_value']) ? ($i * $lastTier['price']) : $lastTier['price'];
                            $tierPrices[$data->getId()][$i * 1] =
                                [
                                    'price' => round($itemTierPrice,2),
                                    'isPercent' => $lastTier['percentage_value']
                                ];
                        }
                    }
                    $itemTierPrice = is_null($tier['percentage_value']) ? ($tier['price_qty'] * $tier['price']) : $tier['price'];
                    $tierPrices[$data->getId()][$tier['price_qty'] * 1] =
                        [
                            'price' => round($itemTierPrice,2),
                            'isPercent' => $tier['percentage_value']
                        ];
                    $lastTier = $tier;
                    if($tierSizeCount == $tierSize && is_null($tier['percentage_value'])){
                        for ($i = $tier['price_qty'] + 1; $i <= 100; $i++) {
                            $itemTierPrice = is_null($tier['percentage_value']) ? ($i * $tier['price']) : $tier['price'];
                            $tierPrices[$data->getId()][$i * 1] =
                                [
                                    'price' => round($itemTierPrice,2),
                                    'isPercent' => $tier['percentage_value']
                                ];
                        }
                    }
                    $tierSizeCount += 1;
                }
            }
            $productStock = $this->getProductInventoryByProductSku($data->getSku());
            $data['inventory'] = $productStock;
            $productDataPush = $data->__toArray($data->getTierPrice());
            if (empty($this->tier_y)) {
                $productData[$data->getData($this->tier_a . '_value')][$data->getData($this->tier_x . '_value')][$data->getData($this->tier_x . '_value')] = $productDataPush;
            } else {
                $productData[$data->getData($this->tier_a . '_value')][$data->getData($this->tier_x . '_value')][$data->getData($this->tier_y . '_value')] = $productDataPush;
            }
        }
	$tierY = ['Very Good', 'Good','Fair', 'Broken Glass'];
        return [
            'tier_prices' => $tierPrices,
            'tier_y' => !empty($tierY) && $this->tier_y ? $tierY : array_keys($productData),
            'tier_a' => !empty($tierA) && $this->tier_a ? $tierA : array_keys($productData),
            'tier_y_labels' => !empty($tierY) && $this->tier_y ? $tierY : [],
            'tier_x' => $productData,
            'tier_original_prices' => $tierOriginalPrices
        ];
    }

    /**
     * @return int
     */
    public function getStoreId(){
        return $this->storeManager->getStore()->getId();
    }

    /**
     * @param $productSku
     * @return array
     */
    public function getProductInventoryByProductSku($productSku){
        $storeId = $this->getStoreId();
        $inventory = [];
        try{
            if($this->multiStoreInventoryHelper->getMultiStoreInventoryModuleStatus()){
                $product = $this->productRepository->get($productSku,false,$storeId);
                $inventory = [
                    'quantity' => $product->getStoreQuantity(),
                    'min_qty' => ($product->getMinSaleStoreQuantity()) ? $product->getMinSaleStoreQuantity() : 1,
                    'max_qty' => ($product->getMaxSaleStoreQuantity()) ? $product->getMaxSaleStoreQuantity() : 100,
                    'stock_status' => $product->getStoreStockStatus()
                ];
            }
            else{
                $stockItem = $this->stockRegistry->getStockItemBySku($productSku,$storeId);
                $inventory = [
                    'quantity' => $stockItem->getQty(),
                    'min_qty' => $stockItem->getMinSaleQty(),
                    'max_qty' => $stockItem->getMaxSaleQty(),
                    'stock_status' => $stockItem->getIsInStock()
                ];
            }
        }
        catch (\Exception $e){

        }
        return $inventory;
    }

}
