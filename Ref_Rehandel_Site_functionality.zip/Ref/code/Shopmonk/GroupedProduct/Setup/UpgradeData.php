<?php

namespace Shopmonk\GroupedProduct\Setup;

use Magento\Customer\Model\GroupFactory as CustomerGroupFactory;
use Magento\Eav\Model\Config;
use Magento\Eav\Model\Entity\Attribute\SetFactory;
use Magento\Eav\Setup\EavSetupFactory;
use Magento\Framework\App\DeploymentConfig;
use Magento\Framework\Event\ManagerInterface;
use Magento\Framework\Registry;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\ModuleDataSetupInterface;
use Magento\Framework\Setup\UpgradeDataInterface;
use Magento\Store\Model\Group as GroupModel;
use Magento\Store\Model\GroupFactory;
use Magento\Store\Model\ResourceModel\Group;
use Magento\Store\Model\ResourceModel\Store;
use Magento\Store\Model\ResourceModel\Website;
use Magento\Store\Model\ScopeInterface;
use Magento\Store\Model\Store as StoreModel;
use Magento\Store\Model\StoreFactory;
use Magento\Store\Model\Website as WebsiteModel;
use Magento\Store\Model\WebsiteFactory;
use Magento\Tax\Model\ClassModel;
use Magento\Tax\Model\ClassModelFactory;
use Psr\Log\LoggerInterface;

/**
 * Class UpgradeData
 * @package Shopmonk\GroupedProduct\Setup
 */
class UpgradeData implements UpgradeDataInterface
{
    /**
     *
     */
    CONST BUSINESS_WEBSITE = 'business';
    /**
     * @var array
     */
    protected $_businessWebsitesData = [
        'business' => [
            'is_default' => 0,
            'label' => 'Business Website',
            'group' => 'Business Store',
            'store_views' => ['business' => 'Business Store view']
        ]
    ];
    /**
     * @var array
     */
    protected $dummyStore = [
        'dumy' => [
            'is_default' => 1,
            'label' => 'dumy',
            'group' => 'dumy',
            'store_views' => [
                'dumy' => 'dumy'
            ]
        ]
    ];
    /**
     * @var array
     */
    protected $_websitesData = [
        'global' => [
            'is_default' => 1,
            'label' => 'Global Website',
            'group' => 'Global Store',
            'store_views' => [
                'default' => 'Default'
            ]
        ],
        'india' => [
            'is_default' => 0,
            'label' => 'India Website',
            'group' => 'India Store',
            'store_views' => ['india' => 'India Default Store View']
        ],
        'singapore' => [
            'is_default' => 0,
            'label' => 'Singapore Website',
            'group' => 'Singapore Store',
            'store_views' => ['singapore' => 'Singapore Default Store View']
        ],
        'australia' => [
            'is_default' => 0,
            'label' => 'Australia Website',
            'group' => 'Australia Store',
            'store_views' => ['australia' => 'Australia Default Store View']
        ],
        'uae' => [
            'is_default' => 0,
            'label' => 'UAE Website',
            'group' => 'UAE Store',
            'store_views' => [
                'uae_en' => 'English',
                'uae_ar' => 'Arabic'
            ]
        ],
        'china' => [
            'is_default' => 0,
            'label' => 'China Website',
            'group' => 'China Store',
            'store_views' => [
                'china_en' => 'English',
                'china_cn' => 'Chinese'
            ]
        ],
        'usa' => [
            'is_default' => 0,
            'label' => 'USA Website',
            'group' => 'USA Store',
            'store_views' => ['usa' => 'USA Default Store View']
        ]
    ];
    /**
     * @var \Magento\Framework\App\Config\ConfigResource\ConfigInterface
     */
    /**
     * @var \Magento\Framework\App\Config\ConfigResource\ConfigInterface
     */
    /**
     * @var \Magento\Framework\App\Config\ConfigResource\ConfigInterface
     */
    protected $resourceConfig;
    /**
     * @var CustomerGroupFactory
     */
    /**
     * @var CustomerGroupFactory
     */
    /**
     * @var CustomerGroupFactory
     */
    protected $customerGroupFactory;
    /**
     * @var ClassModelFactory
     */
    /**
     * @var ClassModelFactory
     */
    /**
     * @var ClassModelFactory
     */
    protected $taxClass;
    /**
     * @var WebsiteFactory
     */
    private $websiteFactory;
    /**
     * @var Website
     */
    private $websiteResourceModel;
    /**
     * @var StoreFactory
     */
    private $storeFactory;
    /**
     * @var GroupFactory
     */
    private $groupFactory;
    /**
     * @var Group
     */
    private $groupResourceModel;
    /**
     * @var Store
     */
    private $storeResourceModel;
    /**
     * @var ManagerInterface
     */
    private $storeModel;
    /**
     * @var GroupModel
     */
    /**
     * @var GroupModel
     */
    /**
     * @var GroupModel
     */
    private $groupModel;
    /**
     * @var WebsiteModel
     */
    /**
     * @var WebsiteModel
     */
    /**
     * @var WebsiteModel
     */
    private $websiteModel;
    /**
     * @var ManagerInterface
     */
    /**
     * @var ManagerInterface
     */
    /**
     * @var ManagerInterface
     */
    private $eventManager;
    /**
     * @var LoggerInterface
     */
    /**
     * @var LoggerInterface
     */
    /**
     * @var LoggerInterface
     */
    private $logger;
    /**
     * @var Registry
     */
    /**
     * @var Registry
     */
    /**
     * @var Registry
     */
    private $registry;
    /**
     * @var DeploymentConfig
     */
    /**
     * @var DeploymentConfig
     */
    /**
     * @var DeploymentConfig
     */
    private $deployConfig;
    /**
     * @var array
     */
    /**
     * @var array
     */
    /**
     * @var array
     */
    private $customerAttributeData = [
        'abn' => [
            'label' => 'ABN Number',
            'type' => 'varchar',
            'input' => 'text'
        ],
        'business_name' => [
            'label' => 'Business Name',
            'type' => 'varchar',
            'input' => 'text'
        ]
    ];
    /**
     * @var EavSetupFactory
     */
    /**
     * @var EavSetupFactory
     */
    /**
     * @var EavSetupFactory
     */
    private $eavSetupFactory;
    /**
     * @var Config
     */
    /**
     * @var Config
     */
    /**
     * @var Config
     */
    private $eavConfig;
    /**
     * @var SetFactory
     */
    /**
     * @var SetFactory
     */
    /**
     * @var SetFactory
     */
    private $attributeSetFactory;

    /**
     * UpgradeData constructor.
     * @param Config                                                       $eavConfig
     * @param EavSetupFactory                                              $eavSetupFactory
     * @param WebsiteFactory                                               $websiteFactory
     * @param Website                                                      $websiteResourceModel
     * @param Store                                                        $storeResourceModel
     * @param Group                                                        $groupResourceModel
     * @param StoreFactory                                                 $storeFactory
     * @param GroupFactory                                                 $groupFactory
     * @param ManagerInterface                                             $eventManager
     * @param LoggerInterface                                              $loggerInterface
     * @param Registry                                                     $registry
     * @param StoreModel                                                   $storeModel
     * @param WebsiteModel                                                 $websiteModel
     * @param GroupModel                                                   $groupModel
     * @param DeploymentConfig                                             $deployConfig
     * @param \Magento\Framework\App\Config\ConfigResource\ConfigInterface $resourceConfig
     * @param CustomerGroupFactory                                         $customerGroupFactory
     * @param ClassModelFactory                                            $taxClass
     * @param SetFactory                                                   $attributeSetFactory
     */
    /**
     * UpgradeData constructor.
     * @param Config                                                       $eavConfig
     * @param EavSetupFactory                                              $eavSetupFactory
     * @param WebsiteFactory                                               $websiteFactory
     * @param Website                                                      $websiteResourceModel
     * @param Store                                                        $storeResourceModel
     * @param Group                                                        $groupResourceModel
     * @param StoreFactory                                                 $storeFactory
     * @param GroupFactory                                                 $groupFactory
     * @param ManagerInterface                                             $eventManager
     * @param LoggerInterface                                              $loggerInterface
     * @param Registry                                                     $registry
     * @param StoreModel                                                   $storeModel
     * @param WebsiteModel                                                 $websiteModel
     * @param GroupModel                                                   $groupModel
     * @param DeploymentConfig                                             $deployConfig
     * @param \Magento\Framework\App\Config\ConfigResource\ConfigInterface $resourceConfig
     * @param CustomerGroupFactory                                         $customerGroupFactory
     * @param ClassModelFactory                                            $taxClass
     * @param SetFactory                                                   $attributeSetFactory
     */
    /**
     * UpgradeData constructor.
     * @param Config                                                       $eavConfig
     * @param EavSetupFactory                                              $eavSetupFactory
     * @param WebsiteFactory                                               $websiteFactory
     * @param Website                                                      $websiteResourceModel
     * @param Store                                                        $storeResourceModel
     * @param Group                                                        $groupResourceModel
     * @param StoreFactory                                                 $storeFactory
     * @param GroupFactory                                                 $groupFactory
     * @param ManagerInterface                                             $eventManager
     * @param LoggerInterface                                              $loggerInterface
     * @param Registry                                                     $registry
     * @param StoreModel                                                   $storeModel
     * @param WebsiteModel                                                 $websiteModel
     * @param GroupModel                                                   $groupModel
     * @param DeploymentConfig                                             $deployConfig
     * @param \Magento\Framework\App\Config\ConfigResource\ConfigInterface $resourceConfig
     * @param CustomerGroupFactory                                         $customerGroupFactory
     * @param ClassModelFactory                                            $taxClass
     * @param SetFactory                                                   $attributeSetFactory
     */
    public function __construct(
        Config $eavConfig,
        EavSetupFactory $eavSetupFactory,
        WebsiteFactory $websiteFactory,
        Website $websiteResourceModel,
        Store $storeResourceModel,
        Group $groupResourceModel,
        StoreFactory $storeFactory,
        GroupFactory $groupFactory,
        ManagerInterface $eventManager,
        LoggerInterface $loggerInterface,
        Registry $registry,
        StoreModel $storeModel,
        WebsiteModel $websiteModel,
        GroupModel $groupModel,
        DeploymentConfig $deployConfig,
        \Magento\Framework\App\Config\ConfigResource\ConfigInterface $resourceConfig,
        CustomerGroupFactory $customerGroupFactory,
        ClassModelFactory $taxClass,
        SetFactory $attributeSetFactory
    )
    {
        $this->eavConfig = $eavConfig;
        $this->attributeSetFactory = $attributeSetFactory;
        $this->eavSetupFactory = $eavSetupFactory;
        $this->websiteFactory = $websiteFactory;
        $this->websiteResourceModel = $websiteResourceModel;
        $this->storeFactory = $storeFactory;
        $this->groupFactory = $groupFactory;
        $this->groupResourceModel = $groupResourceModel;
        $this->storeResourceModel = $storeResourceModel;
        $this->eventManager = $eventManager;
        $this->logger = $loggerInterface;
        $this->registry = $registry;
        $this->storeModel = $storeModel;
        $this->groupModel = $groupModel;
        $this->websiteModel = $websiteModel;
        $this->deployConfig = $deployConfig;
        $this->resourceConfig = $resourceConfig;
        $this->customerGroupFactory = $customerGroupFactory;
        $this->taxClass = $taxClass;
    }

    /**
     * @param ModuleDataSetupInterface $setup
     * @param ModuleContextInterface   $context
     * @throws \Exception
     * @throws \Magento\Framework\Exception\AlreadyExistsException
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    /**
     * @param ModuleDataSetupInterface $setup
     * @param ModuleContextInterface   $context
     * @throws \Exception
     * @throws \Magento\Framework\Exception\AlreadyExistsException
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    /**
     * @param ModuleDataSetupInterface $setup
     * @param ModuleContextInterface   $context
     * @throws \Exception
     * @throws \Magento\Framework\Exception\AlreadyExistsException
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function upgrade(ModuleDataSetupInterface $setup, ModuleContextInterface $context)
    {
        $setup->startSetup();
        if (version_compare($context->getVersion(), '1.0.1') < 0) {
            $exists = $this->websiteModel->load($this::BUSINESS_WEBSITE);
            if (!$exists->getId()) {
                $this->addSmkBusinessWebsite($setup);
                /* @TODO afer this
                 * Select the design configuration in Admin->Content->Theme/Design
                 * Disable Mageplaza_SocialLogin for this site 'business'
                 * Reindex again
                 **/
            }
        }

        if (version_compare($context->getVersion(), '1.0.3') < 0) {
            $this->createGroupTierAtrribute($setup);
        }
        if (version_compare($context->getVersion(), '1.0.4') < 0) {
            $this->createProductStatusAtrribute($setup);
            $this->createProductGradeAtrribute($setup);
        }
        if (version_compare($context->getVersion(), '1.0.5') < 0) {
            $this->createProductGradeTextSwatchAtrribute($setup);
            $this->createProductColorAtrribute($setup);
            $this->createProductColorTextSwatchAtrribute($setup);
            $this->createProductBrandAtrribute($setup);
            $this->createProductStorageAtrribute($setup);
            $this->createProductStorageTextSwatchAtrribute($setup);
            $this->createProductRamAtrribute($setup);
            $this->createProductRamTextSwatchAtrribute($setup);
            $this->createProductModelAtrribute($setup);
            $this->createProductDimensionAtrribute($setup);
            $this->createProductOPSNumberAtrribute($setup);
            $this->createProductPrimaryCameraAtrribute($setup);
            $this->createProductProcessorAtrribute($setup);
            $this->createProductGradeNoteAtrribute($setup);
            $this->createProductScreenSizeAtrribute($setup);
            $this->createProductSecondaryCameraAtrribute($setup);
            $this->createProductSensorsAtrribute($setup);
            $this->createProductAdditionalInfoAtrribute($setup);
            $this->createProductBatteryAtrribute($setup);
            $this->createProductResolutionAtrribute($setup);
            $this->createProductOperatingSystemAtrribute($setup);
        }
        if (version_compare($context->getVersion(), '1.0.6') < 0) {
            $this->createProductHunPerGuarAtrribute($setup);
            $this->createProductPopularityAtrribute($setup);
        }
        if (version_compare($context->getVersion(), '1.0.7') < 0) {
            $this->createProductStoreQuantityAtrribute($setup);
            $this->createProductManufacturingPartNumberAtrribute($setup);
            $this->createProductShippingEstimationAtrribute($setup);
        }

        $setup->endSetup();
    }

    /**
     * @param ModuleDataSetupInterface $setup
     * @throws \Exception
     * @throws \Magento\Framework\Exception\AlreadyExistsException
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    /**
     * @param ModuleDataSetupInterface $setup
     * @throws \Exception
     * @throws \Magento\Framework\Exception\AlreadyExistsException
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    /**
     * @param ModuleDataSetupInterface $setup
     * @throws \Exception
     * @throws \Magento\Framework\Exception\AlreadyExistsException
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    private function addSmkBusinessWebsite(ModuleDataSetupInterface $setup)
    {
        $createdWebsiteId = '';
        $websitesData = $this->_businessWebsitesData;
        foreach ($websitesData as $code => $data) {
            /** @var \Magento\Store\Model\Website $website */
            $website = $this->websiteFactory->create();
            $website->load($code);
            if (!$website->getId()) {
                $website->setCode($code);
                $website->setName($data['label']);
                $data['is_default'] ? $website->setIsDefault($data['is_default']) : NULL;
                $this->websiteResourceModel->save($website);
            }
            /** @var \Magento\Store\Model\Group $group */
            $group = $this->groupFactory->create();
            $group->load($code, 'code');
            if ($website->getId() && !$group->getId()) {
                $createdWebsiteId = $website->getId();
                $group->setCode($code);
                $group->setWebsiteId($website->getWebsiteId());
                $group->setName($data['group']);
                $group->setRootCategoryId(2);
                $this->groupResourceModel->save($group);
                $website->setDefaultGroupId($group->getId());
                $this->websiteResourceModel->save($website);
            }
            $storesData = $data['store_views'];
            foreach ($storesData as $storeCode => $storeView) {
                /** @var  \Magento\Store\Model\Store $store */
                $store = $this->storeFactory->create();
                $store->load($storeCode);
                if (!$store->getId()) {
                    $group = $this->groupFactory->create();
                    $group->load($data['group'], 'name');
                    $store->setCode($storeCode);
                    $store->setName($storeView);
                    $store->setWebsite($website);
                    $store->setGroupId($group->getId());
                    $store->setData('is_active', '1');
                    $this->storeResourceModel->save($store);
                    $group->setDefaultStoreId($store->getId());
                    $this->groupResourceModel->save($group);
                    // Trigger event to insert some data to the sales_sequence_meta table (fix bug place order in checkout)
                    $this->eventManager->dispatch('store_add', ['store' => $store]);
                }
            }

        }

        /*Add config values for business website scope */
        if ($createdWebsiteId) {
            $this->resourceConfig->saveConfig(
                \Magento\Store\Model\Store::XML_PATH_SECURE_BASE_LINK_URL,
                '{{secure_base_url}}business/',
                ScopeInterface::SCOPE_WEBSITES,
                $createdWebsiteId
            );
            $this->resourceConfig->saveConfig(
                \Magento\Store\Model\Store::XML_PATH_UNSECURE_BASE_LINK_URL,
                '{{unsecure_base_url}}business/',
                ScopeInterface::SCOPE_WEBSITES,
                $createdWebsiteId
            );
            /*Create Customer group and tax class*/
            $this->createTaxClassAndGroup();
            $this->createCustomerAttribute($setup, $this->customerAttributeData);
            $this->createAbnAndBusinessSalesFields($setup);
        }

    }

    private function createTaxClassAndGroup()
    {
        //Create Tax class for business
        $taxClass = $this->taxClass->create();
        $taxClass->setClassName('Business');
        $taxClass->setClassType(ClassModel::TAX_CLASS_TYPE_CUSTOMER);
        $taxClass->save();

        if ($taxClassId = $taxClass->getId()) {
            // Create the new group
            $group = $this->customerGroupFactory->create();
            $group->setCode('Business')
                ->setTaxClassId($taxClassId)
                ->save();
        }
    }

    /**
     * @param $setup
     * @param $customerAttributeData
     * @throws \Exception
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    /**
     * @param $setup
     * @param $customerAttributeData
     * @throws \Exception
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    /**
     * @param $setup
     * @param $customerAttributeData
     * @throws \Exception
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    /**
     * @param $setup
     * @param $customerAttributeData
     * @throws \Exception
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    private function createCustomerAttribute($setup, $customerAttributeData)
    {
        foreach ($customerAttributeData as $key => $value) {
            $eavSetup = $this->eavSetupFactory->create(['setup' => $setup]);
            $eavSetup->removeAttribute(\Magento\Customer\Model\Customer::ENTITY, $key);
            $customerEntity = $this->eavConfig->getEntityType('customer');
            $attributeSetId = $customerEntity->getDefaultAttributeSetId();

            /** @var $attributeSet AttributeSet */
            $attributeSet = $this->attributeSetFactory->create();
            $attributeGroupId = $attributeSet->getDefaultGroupId($attributeSetId);

            $eavSetup->addAttribute(
                \Magento\Customer\Model\Customer::ENTITY,
                $key,
                [
                    'type' => $value['type'],
                    'label' => $value['label'],
                    'input' => $value['input'],
                    'required' => false,
                    'visible' => true,
                    'user_defined' => true,
                    'position' => 100,
                    'system' => 0,
                ]
            );
            $sampleAttribute = $this->eavConfig->getAttribute(\Magento\Customer\Model\Customer::ENTITY, $key);
            $sampleAttribute->addData(
                [
                    'attribute_set_id' => $attributeSetId,
                    'attribute_group_id' => $attributeGroupId,
                    'used_in_forms' => ['adminhtml_customer', 'customer_account_create', 'customer_account_edit']
                ]
            );
            $sampleAttribute->save();
        }

    }

    /**
     * @param $setup
     */
    /**
     * @param $setup
     */
    /**
     * @param $setup
     */
    /**
     * @param $setup
     */
    private function createAbnAndBusinessSalesFields($setup)
    {
        $tables = ['sales_order', 'sales_invoice', 'sales_creditmemo'];
        foreach ($tables as $tableName) {
            $setup->getConnection()
                ->addColumn(
                    $setup->getTable($tableName),
                    'business_name',
                    [
                        'type' => \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                        '',
                        'default' => NULL,
                        'nullable' => true,
                        'comment' => 'Business Name'
                    ]
                );
            $setup->getConnection()
                ->addColumn(
                    $setup->getTable($tableName),
                    'abn',
                    [
                        'type' => \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                        '',
                        'default' => NULL,
                        'nullable' => true,
                        'comment' => 'ABN'
                    ]
                );
        }

    }

    /**
     * @param $setup
     */
    /**
     * @param $setup
     */
    /**
     * @param $setup
     */
    /**
     * @param $setup
     */
    private function createGroupTierAtrribute($setup)
    {
        $eavSetup = $this->eavSetupFactory->create(['setup' => $setup]);

        /**
         * Add attributes to the eav/attribute
         */
        $eavSetup->removeAttribute(\Magento\Catalog\Model\Product::ENTITY, 'group_tier_attributes');
        $eavSetup->addAttribute(
            \Magento\Catalog\Model\Product::ENTITY,
            'group_tier_attributes',/* Custom Attribute Code */
            [
                'group' => 'Product Details',

                'type' => 'text',
                'backend' => 'Magento\Eav\Model\Entity\Attribute\Backend\ArrayBackend',
                'frontend' => '',
                'label' => 'Group Tier Attributes',
                'input' => 'multiselect',
                'class' => '',
                'source' => 'Shopmonk\GroupedProduct\Model\Config\Source\Options',
                /* Source of your select type custom attribute options*/
                'global' => \Magento\Eav\Model\Entity\Attribute\ScopedAttributeInterface::SCOPE_STORE,
                /*Scope of your attribute */
                'visible' => true,
                'required' => false,
                'user_defined' => true,
                'default' => '',
                'searchable' => false,
                'filterable' => false,
                'comparable' => false,
                'visible_on_front' => false,
                'used_in_product_listing' => true,
                'unique' => false
            ]
        );
    }

    /**
     * @param $setup
     */
    /**
     * @param $setup
     */
    /**
     * @param $setup
     */
    /**
     * @param $setup
     */
    private function createProductStatusAtrribute($setup)
    {
        $eavSetup = $this->eavSetupFactory->create(['setup' => $setup]);

        /**
         * Add attributes to the eav/attribute
         */
        $eavSetup->removeAttribute(\Magento\Catalog\Model\Product::ENTITY, 'used_new');
        $eavSetup->addAttribute(
            \Magento\Catalog\Model\Product::ENTITY,
            'used_new',/* Custom Attribute Code */
            [
                'group' => 'Product Details',

                'type' => 'text',
                'backend' => 'Magento\Eav\Model\Entity\Attribute\Backend\ArrayBackend',
                'frontend' => '',
                'label' => 'Product Used New',
                'input' => 'select',
                'class' => '',
                'source' => 'Magento\Eav\Model\Entity\Attribute\Source\Table',
                'option' => ['values' => ['used', 'new']],
                /* Source of your select type custom attribute options*/
                'global' => \Magento\Eav\Model\Entity\Attribute\ScopedAttributeInterface::SCOPE_STORE,
                /*Scope of your attribute */
                'visible' => true,
                'required' => false,
                'user_defined' => true,
                'default' => 'new',
                'searchable' => false,
                'filterable' => false,
                'comparable' => false,
                'visible_on_front' => false,
                'used_in_product_listing' => true,
                'unique' => false
            ]
        );
    }

    /**
     * @param $setup
     */
    /**
     * @param $setup
     */
    /**
     * @param $setup
     */
    /**
     * @param $setup
     */
    private function createProductGradeAtrribute($setup)
    {
        $eavSetup = $this->eavSetupFactory->create(['setup' => $setup]);

        /**
         * Add attributes to the eav/attribute
         */
        $eavSetup->removeAttribute(\Magento\Catalog\Model\Product::ENTITY, 'grade');
        $eavSetup->addAttribute(
            \Magento\Catalog\Model\Product::ENTITY,
            'grade',/* Custom Attribute Code */
            [
                'group' => 'Product Details',
                'type' => 'text',
                'backend' => 'Magento\Eav\Model\Entity\Attribute\Backend\ArrayBackend',
                'frontend' => '',
                'label' => 'Product Grade',
                'input' => 'select',
                'class' => '',
                'source' => 'Magento\Eav\Model\Entity\Attribute\Source\Table',
                'option' => ['values' => ['Very Good','Good','Fair','Bad LCD']],
                /* Source of your select type custom attribute options*/
                'global' => \Magento\Eav\Model\Entity\Attribute\ScopedAttributeInterface::SCOPE_GLOBAL,
                /*Scope of your attribute */
                'visible' => true,
                'required' => false,
                'user_defined' => true,
                'default' => '',
                'searchable' => false,
                'filterable' => true,
                'comparable' => false,
                'visible_on_front' => false,
                'used_in_product_listing' => true,
                'unique' => false
            ]
        );
    }

    private function createProductGradeTextSwatchAtrribute($setup)
    {
        $eavSetup = $this->eavSetupFactory->create(['setup' => $setup]);

        /**
         * Add attributes to the eav/attribute
         */
        $eavSetup->removeAttribute(\Magento\Catalog\Model\Product::ENTITY, 'grade_text_swatch');
        $eavSetup->addAttribute(
            \Magento\Catalog\Model\Product::ENTITY,
            'grade_text_swatch',/* Custom Attribute Code */
            [
                'group' => 'Product Details',
                'type' => 'text',
                'backend' => 'Magento\Eav\Model\Entity\Attribute\Backend\ArrayBackend',
                'frontend' => '',
                'label' => 'Grade Swatch',
                'input' => 'select',
                'class' => '',
                'source' => 'Magento\Eav\Model\Entity\Attribute\Source\Table',
                'option' => ['values' => ['Very Good','Good','Fair','Bad LCD']],
                /* Source of your select type custom attribute options*/
                'global' => \Magento\Eav\Model\Entity\Attribute\ScopedAttributeInterface::SCOPE_GLOBAL,
                /*Scope of your attribute */
                'visible' => true,
                'required' => false,
                'user_defined' => true,
                'default' => '',
                'searchable' => false,
                'filterable' => true,
                'comparable' => false,
                'visible_on_front' => false,
                'used_in_product_listing' => true,
                'unique' => false
            ]
        );
    }

    private function createProductColorAtrribute($setup)
    {
        $eavSetup = $this->eavSetupFactory->create(['setup' => $setup]);

        /**
         * Add attributes to the eav/attribute
         */
        $eavSetup->removeAttribute(\Magento\Catalog\Model\Product::ENTITY, 'color');
        $eavSetup->addAttribute(
            \Magento\Catalog\Model\Product::ENTITY,
            'color',/* Custom Attribute Code */
            [
                'group' => 'SMK Attributes',
                'type' => 'text',
                'backend' => 'Magento\Eav\Model\Entity\Attribute\Backend\ArrayBackend',
                'frontend' => '',
                'label' => 'Color',
                'input' => 'select',
                'class' => '',
                'source' => 'Magento\Eav\Model\Entity\Attribute\Source\Table',
                'option' => ['values' => ['Black','Purple','Red','White','Gold','Midnight Green','Silver','Space Gray','Rose Gold','Jet Black','Blue','Coral','Yellow','Space Grey','Clearly White','Just Black','Not Pink','Purple-ish','Oh So Orange','Moonlit Blue','Venus Pink','Warm Silver','Ash Pink','Deep Green','Liquid Black','Liquid Silver','Bordeaux Red','Forest Green','Silver White']],
                /* Source of your select type custom attribute options*/
                'global' => \Magento\Eav\Model\Entity\Attribute\ScopedAttributeInterface::SCOPE_GLOBAL,
                /*Scope of your attribute */
                'visible' => true,
                'required' => false,
                'user_defined' => true,
                'default' => '',
                'searchable' => false,
                'filterable' => true,
                'comparable' => false,
                'visible_on_front' => false,
                'used_in_product_listing' => true,
                'unique' => false
            ]
        );
    }

    private function createProductColorTextSwatchAtrribute($setup)
    {
        $eavSetup = $this->eavSetupFactory->create(['setup' => $setup]);

        /**
         * Add attributes to the eav/attribute
         */
        $eavSetup->removeAttribute(\Magento\Catalog\Model\Product::ENTITY, 'color_text_swatch');
        $eavSetup->addAttribute(
            \Magento\Catalog\Model\Product::ENTITY,
            'color_text_swatch',/* Custom Attribute Code */
            [
                'group' => 'SMK Attributes',
                'type' => 'text',
                'backend' => 'Magento\Eav\Model\Entity\Attribute\Backend\ArrayBackend',
                'frontend' => '',
                'label' => 'Color Text Swatch',
                'input' => 'select',
                'class' => '',
                'source' => 'Magento\Eav\Model\Entity\Attribute\Source\Table',
                'option' => ['values' => ['Black','Purple','Red','White','Gold','Midnight Green','Silver','Space Gray','Rose Gold','Jet Black','Blue','Coral','Yellow','Space Grey','Clearly White','Just Black','Not Pink','Purple-ish','Oh So Orange','Moonlit Blue','Venus Pink','Warm Silver','Ash Pink','Deep Green','Liquid Black','Liquid Silver','Bordeaux Red','Forest Green','Silver White']],
                /* Source of your select type custom attribute options*/
                'global' => \Magento\Eav\Model\Entity\Attribute\ScopedAttributeInterface::SCOPE_GLOBAL,
                /*Scope of your attribute */
                'visible' => true,
                'required' => false,
                'user_defined' => true,
                'default' => '',
                'searchable' => false,
                'filterable' => true,
                'comparable' => false,
                'visible_on_front' => false,
                'used_in_product_listing' => true,
                'unique' => false
            ]
        );
    }

    private function createProductBrandAtrribute($setup)
    {
        $eavSetup = $this->eavSetupFactory->create(['setup' => $setup]);

        /**
         * Add attributes to the eav/attribute
         */
        $eavSetup->removeAttribute(\Magento\Catalog\Model\Product::ENTITY, 'brand');
        $eavSetup->addAttribute(
            \Magento\Catalog\Model\Product::ENTITY,
            'brand',/* Custom Attribute Code */
            [
                'group' => 'SMK Attributes',
                'type' => 'text',
                'backend' => 'Magento\Eav\Model\Entity\Attribute\Backend\ArrayBackend',
                'frontend' => '',
                'label' => 'Brand',
                'input' => 'select',
                'class' => '',
                'source' => 'Magento\Eav\Model\Entity\Attribute\Source\Table',
                'option' => ['values' => ['Apple','Google','Sony','Samsung','Sharp']],
                /* Source of your select type custom attribute options*/
                'global' => \Magento\Eav\Model\Entity\Attribute\ScopedAttributeInterface::SCOPE_GLOBAL,
                /*Scope of your attribute */
                'visible' => true,
                'required' => false,
                'user_defined' => true,
                'default' => '',
                'searchable' => false,
                'filterable' => true,
                'comparable' => false,
                'visible_on_front' => false,
                'used_in_product_listing' => true,
                'unique' => false
            ]
        );
    }

    private function createProductStorageAtrribute($setup)
    {
        $eavSetup = $this->eavSetupFactory->create(['setup' => $setup]);

        /**
         * Add attributes to the eav/attribute
         */
        $eavSetup->removeAttribute(\Magento\Catalog\Model\Product::ENTITY, 'storage');
        $eavSetup->addAttribute(
            \Magento\Catalog\Model\Product::ENTITY,
            'storage',/* Custom Attribute Code */
            [
                'group' => 'SMK Attributes',
                'type' => 'text',
                'backend' => 'Magento\Eav\Model\Entity\Attribute\Backend\ArrayBackend',
                'frontend' => '',
                'label' => 'Storage',
                'input' => 'select',
                'class' => '',
                'source' => 'Magento\Eav\Model\Entity\Attribute\Source\Table',
                'option' => ['values' => ['64 GB','128 GB','256 GB','16 GB','32 GB','512 GB']],
                /* Source of your select type custom attribute options*/
                'global' => \Magento\Eav\Model\Entity\Attribute\ScopedAttributeInterface::SCOPE_GLOBAL,
                /*Scope of your attribute */
                'visible' => true,
                'required' => false,
                'user_defined' => true,
                'default' => '',
                'searchable' => false,
                'filterable' => true,
                'comparable' => false,
                'visible_on_front' => false,
                'used_in_product_listing' => true,
                'unique' => false
            ]
        );
    }

    private function createProductStorageTextSwatchAtrribute($setup)
    {
        $eavSetup = $this->eavSetupFactory->create(['setup' => $setup]);

        /**
         * Add attributes to the eav/attribute
         */
        $eavSetup->removeAttribute(\Magento\Catalog\Model\Product::ENTITY, 'storage_text_swatch');
        $eavSetup->addAttribute(
            \Magento\Catalog\Model\Product::ENTITY,
            'storage_text_swatch',/* Custom Attribute Code */
            [
                'group' => 'SMK Attributes',
                'type' => 'text',
                'backend' => 'Magento\Eav\Model\Entity\Attribute\Backend\ArrayBackend',
                'frontend' => '',
                'label' => 'Storage Text Swatch',
                'input' => 'select',
                'class' => '',
                'source' => 'Magento\Eav\Model\Entity\Attribute\Source\Table',
                'option' => ['values' => ['64 GB','128 GB','256 GB','16 GB','32 GB','512 GB']],
                /* Source of your select type custom attribute options*/
                'global' => \Magento\Eav\Model\Entity\Attribute\ScopedAttributeInterface::SCOPE_GLOBAL,
                /*Scope of your attribute */
                'visible' => true,
                'required' => false,
                'user_defined' => true,
                'default' => '',
                'searchable' => false,
                'filterable' => true,
                'comparable' => false,
                'visible_on_front' => false,
                'used_in_product_listing' => true,
                'unique' => false
            ]
        );
    }

    private function createProductRamAtrribute($setup)
    {
        $eavSetup = $this->eavSetupFactory->create(['setup' => $setup]);

        /**
         * Add attributes to the eav/attribute
         */
        $eavSetup->removeAttribute(\Magento\Catalog\Model\Product::ENTITY, 'ram');
        $eavSetup->addAttribute(
            \Magento\Catalog\Model\Product::ENTITY,
            'ram',/* Custom Attribute Code */
            [
                'group' => 'SMK Attributes',
                'type' => 'text',
                'backend' => 'Magento\Eav\Model\Entity\Attribute\Backend\ArrayBackend',
                'frontend' => '',
                'label' => 'Ram',
                'input' => 'select',
                'class' => '',
                'source' => 'Magento\Eav\Model\Entity\Attribute\Source\Table',
                'option' => ['values' => ['1 GB','2 GB','3 GB','4 GB','6 GB','8 GB']],
                /* Source of your select type custom attribute options*/
                'global' => \Magento\Eav\Model\Entity\Attribute\ScopedAttributeInterface::SCOPE_GLOBAL,
                /*Scope of your attribute */
                'visible' => true,
                'required' => false,
                'user_defined' => true,
                'default' => '',
                'searchable' => false,
                'filterable' => true,
                'comparable' => false,
                'visible_on_front' => false,
                'used_in_product_listing' => true,
                'unique' => false
            ]
        );
    }

    private function createProductRamTextSwatchAtrribute($setup)
    {
        $eavSetup = $this->eavSetupFactory->create(['setup' => $setup]);

        /**
         * Add attributes to the eav/attribute
         */
        $eavSetup->removeAttribute(\Magento\Catalog\Model\Product::ENTITY, 'ram_text_swatch');
        $eavSetup->addAttribute(
            \Magento\Catalog\Model\Product::ENTITY,
            'ram_text_swatch',/* Custom Attribute Code */
            [
                'group' => 'SMK Attributes',
                'type' => 'text',
                'backend' => 'Magento\Eav\Model\Entity\Attribute\Backend\ArrayBackend',
                'frontend' => '',
                'label' => 'Ram Text Swatch',
                'input' => 'select',
                'class' => '',
                'source' => 'Magento\Eav\Model\Entity\Attribute\Source\Table',
                'option' => ['values' => ['1 GB','2 GB','3 GB','4 GB','6 GB','8 GB']],
                /* Source of your select type custom attribute options*/
                'global' => \Magento\Eav\Model\Entity\Attribute\ScopedAttributeInterface::SCOPE_GLOBAL,
                /*Scope of your attribute */
                'visible' => true,
                'required' => false,
                'user_defined' => true,
                'default' => '',
                'searchable' => false,
                'filterable' => true,
                'comparable' => false,
                'visible_on_front' => false,
                'used_in_product_listing' => true,
                'unique' => false
            ]
        );
    }

    private function createProductModelAtrribute($setup)
    {
        $eavSetup = $this->eavSetupFactory->create(['setup' => $setup]);

        /**
         * Add attributes to the eav/attribute
         */
        $eavSetup->removeAttribute(\Magento\Catalog\Model\Product::ENTITY, 'model');
        $eavSetup->addAttribute(
            \Magento\Catalog\Model\Product::ENTITY,
            'model',/* Custom Attribute Code */
            [
                'group' => 'SMK Attributes',
                'type' => 'text',
                'backend' => '',
                'frontend' => '',
                'label' => 'Model',
                'input' => 'text',
                'class' => '',
                'source' => '',
                'global' => \Magento\Eav\Model\Entity\Attribute\ScopedAttributeInterface::SCOPE_GLOBAL,
                /*Scope of your attribute */
                'visible' => true,
                'required' => false,
                'user_defined' => true,
                'default' => '',
                'searchable' => false,
                'filterable' => true,
                'comparable' => false,
                'visible_on_front' => false,
                'used_in_product_listing' => true,
                'unique' => false,
                'apply_to' => ''
            ]
        );
    }

    private function createProductDimensionAtrribute($setup)
    {
        $eavSetup = $this->eavSetupFactory->create(['setup' => $setup]);

        /**
         * Add attributes to the eav/attribute
         */
        $eavSetup->removeAttribute(\Magento\Catalog\Model\Product::ENTITY, 'dimension');
        $eavSetup->addAttribute(
            \Magento\Catalog\Model\Product::ENTITY,
            'dimension',/* Custom Attribute Code */
            [
                'group' => 'SMK Attributes',
                'type' => 'text',
                'backend' => '',
                'frontend' => '',
                'label' => 'Dimension',
                'input' => 'text',
                'class' => '',
                'source' => '',
                'global' => \Magento\Eav\Model\Entity\Attribute\ScopedAttributeInterface::SCOPE_GLOBAL,
                /*Scope of your attribute */
                'visible' => true,
                'required' => false,
                'user_defined' => true,
                'default' => '',
                'searchable' => false,
                'filterable' => true,
                'comparable' => false,
                'visible_on_front' => false,
                'used_in_product_listing' => true,
                'unique' => false,
                'apply_to' => ''
            ]
        );
    }

    private function createProductOPSNumberAtrribute($setup)
    {
        $eavSetup = $this->eavSetupFactory->create(['setup' => $setup]);

        /**
         * Add attributes to the eav/attribute
         */
        $eavSetup->removeAttribute(\Magento\Catalog\Model\Product::ENTITY, 'ops_part_number');
        $eavSetup->addAttribute(
            \Magento\Catalog\Model\Product::ENTITY,
            'ops_part_number',/* Custom Attribute Code */
            [
                'group' => 'SMK Attributes',
                'type' => 'text',
                'backend' => '',
                'frontend' => '',
                'label' => 'OPS Part Number',
                'input' => 'text',
                'class' => '',
                'source' => '',
                'global' => \Magento\Eav\Model\Entity\Attribute\ScopedAttributeInterface::SCOPE_GLOBAL,
                /*Scope of your attribute */
                'visible' => true,
                'required' => false,
                'user_defined' => true,
                'default' => '',
                'searchable' => false,
                'filterable' => true,
                'comparable' => false,
                'visible_on_front' => false,
                'used_in_product_listing' => true,
                'unique' => false,
                'apply_to' => ''
            ]
        );
    }

    private function createProductPrimaryCameraAtrribute($setup)
    {
        $eavSetup = $this->eavSetupFactory->create(['setup' => $setup]);

        /**
         * Add attributes to the eav/attribute
         */
        $eavSetup->removeAttribute(\Magento\Catalog\Model\Product::ENTITY, 'primary_camera');
        $eavSetup->addAttribute(
            \Magento\Catalog\Model\Product::ENTITY,
            'primary_camera',/* Custom Attribute Code */
            [
                'group' => 'SMK Attributes',
                'type' => 'text',
                'backend' => '',
                'frontend' => '',
                'label' => 'Primary Camera',
                'input' => 'text',
                'class' => '',
                'source' => '',
                'global' => \Magento\Eav\Model\Entity\Attribute\ScopedAttributeInterface::SCOPE_GLOBAL,
                /*Scope of your attribute */
                'visible' => true,
                'required' => false,
                'user_defined' => true,
                'default' => '',
                'searchable' => false,
                'filterable' => true,
                'comparable' => false,
                'visible_on_front' => false,
                'used_in_product_listing' => true,
                'unique' => false,
                'apply_to' => ''
            ]
        );
    }

    private function createProductProcessorAtrribute($setup)
    {
        $eavSetup = $this->eavSetupFactory->create(['setup' => $setup]);

        /**
         * Add attributes to the eav/attribute
         */
        $eavSetup->removeAttribute(\Magento\Catalog\Model\Product::ENTITY, 'processor');
        $eavSetup->addAttribute(
            \Magento\Catalog\Model\Product::ENTITY,
            'processor',/* Custom Attribute Code */
            [
                'group' => 'SMK Attributes',
                'type' => 'text',
                'backend' => '',
                'frontend' => '',
                'label' => 'Processor',
                'input' => 'text',
                'class' => '',
                'source' => '',
                'global' => \Magento\Eav\Model\Entity\Attribute\ScopedAttributeInterface::SCOPE_GLOBAL,
                /*Scope of your attribute */
                'visible' => true,
                'required' => false,
                'user_defined' => true,
                'default' => '',
                'searchable' => false,
                'filterable' => true,
                'comparable' => false,
                'visible_on_front' => false,
                'used_in_product_listing' => true,
                'unique' => false,
                'apply_to' => ''
            ]
        );
    }

    private function createProductGradeNoteAtrribute($setup)
    {
        $eavSetup = $this->eavSetupFactory->create(['setup' => $setup]);

        /**
         * Add attributes to the eav/attribute
         */
        $eavSetup->removeAttribute(\Magento\Catalog\Model\Product::ENTITY, 'product_grade');
        $eavSetup->addAttribute(
            \Magento\Catalog\Model\Product::ENTITY,
            'product_grade',/* Custom Attribute Code */
            [
                'group' => 'SMK Attributes',
                'type' => 'text',
                'backend' => '',
                'frontend' => '',
                'label' => 'Product Grade Note',
                'input' => 'text',
                'class' => '',
                'source' => '',
                'global' => \Magento\Eav\Model\Entity\Attribute\ScopedAttributeInterface::SCOPE_GLOBAL,
                /*Scope of your attribute */
                'visible' => true,
                'required' => false,
                'user_defined' => true,
                'default' => '',
                'searchable' => false,
                'filterable' => true,
                'comparable' => false,
                'visible_on_front' => false,
                'used_in_product_listing' => true,
                'unique' => false,
                'apply_to' => ''
            ]
        );
    }

    private function createProductScreenSizeAtrribute($setup)
    {
        $eavSetup = $this->eavSetupFactory->create(['setup' => $setup]);

        /**
         * Add attributes to the eav/attribute
         */
        $eavSetup->removeAttribute(\Magento\Catalog\Model\Product::ENTITY, 'screen_size');
        $eavSetup->addAttribute(
            \Magento\Catalog\Model\Product::ENTITY,
            'screen_size',/* Custom Attribute Code */
            [
                'group' => 'SMK Attributes',
                'type' => 'text',
                'backend' => '',
                'frontend' => '',
                'label' => 'Screen Size',
                'input' => 'text',
                'class' => '',
                'source' => '',
                'global' => \Magento\Eav\Model\Entity\Attribute\ScopedAttributeInterface::SCOPE_GLOBAL,
                /*Scope of your attribute */
                'visible' => true,
                'required' => false,
                'user_defined' => true,
                'default' => '',
                'searchable' => false,
                'filterable' => true,
                'comparable' => false,
                'visible_on_front' => false,
                'used_in_product_listing' => true,
                'unique' => false,
                'apply_to' => ''
            ]
        );
    }

    private function createProductSecondaryCameraAtrribute($setup)
    {
        $eavSetup = $this->eavSetupFactory->create(['setup' => $setup]);

        /**
         * Add attributes to the eav/attribute
         */
        $eavSetup->removeAttribute(\Magento\Catalog\Model\Product::ENTITY, 'secondary_camera');
        $eavSetup->addAttribute(
            \Magento\Catalog\Model\Product::ENTITY,
            'secondary_camera',/* Custom Attribute Code */
            [
                'group' => 'SMK Attributes',
                'type' => 'text',
                'backend' => '',
                'frontend' => '',
                'label' => 'Secondary Camera',
                'input' => 'text',
                'class' => '',
                'source' => '',
                'global' => \Magento\Eav\Model\Entity\Attribute\ScopedAttributeInterface::SCOPE_GLOBAL,
                /*Scope of your attribute */
                'visible' => true,
                'required' => false,
                'user_defined' => true,
                'default' => '',
                'searchable' => false,
                'filterable' => true,
                'comparable' => false,
                'visible_on_front' => false,
                'used_in_product_listing' => true,
                'unique' => false,
                'apply_to' => ''
            ]
        );
    }

    private function createProductSensorsAtrribute($setup)
    {
        $eavSetup = $this->eavSetupFactory->create(['setup' => $setup]);

        /**
         * Add attributes to the eav/attribute
         */
        $eavSetup->removeAttribute(\Magento\Catalog\Model\Product::ENTITY, 'sensors');
        $eavSetup->addAttribute(
            \Magento\Catalog\Model\Product::ENTITY,
            'sensors',/* Custom Attribute Code */
            [
                'group' => 'SMK Attributes',
                'type' => 'text',
                'backend' => '',
                'frontend' => '',
                'label' => 'Sensors',
                'input' => 'text',
                'class' => '',
                'source' => '',
                'global' => \Magento\Eav\Model\Entity\Attribute\ScopedAttributeInterface::SCOPE_GLOBAL,
                /*Scope of your attribute */
                'visible' => true,
                'required' => false,
                'user_defined' => true,
                'default' => '',
                'searchable' => false,
                'filterable' => true,
                'comparable' => false,
                'visible_on_front' => false,
                'used_in_product_listing' => true,
                'unique' => false,
                'apply_to' => ''
            ]
        );
    }

    private function createProductAdditionalInfoAtrribute($setup)
    {
        $eavSetup = $this->eavSetupFactory->create(['setup' => $setup]);

        /**
         * Add attributes to the eav/attribute
         */
        $eavSetup->removeAttribute(\Magento\Catalog\Model\Product::ENTITY, 'additional_info');
        $eavSetup->addAttribute(
            \Magento\Catalog\Model\Product::ENTITY,
            'additional_info',/* Custom Attribute Code */
            [
                'group' => 'SMK Attributes',
                'type' => 'text',
                'backend' => '',
                'frontend' => '',
                'label' => 'Additional Info',
                'input' => 'text',
                'class' => '',
                'source' => '',
                'global' => \Magento\Eav\Model\Entity\Attribute\ScopedAttributeInterface::SCOPE_GLOBAL,
                /*Scope of your attribute */
                'visible' => true,
                'required' => false,
                'user_defined' => true,
                'default' => '',
                'searchable' => false,
                'filterable' => true,
                'comparable' => false,
                'visible_on_front' => false,
                'used_in_product_listing' => true,
                'unique' => false,
                'apply_to' => ''
            ]
        );
    }

    private function createProductBatteryAtrribute($setup)
    {
        $eavSetup = $this->eavSetupFactory->create(['setup' => $setup]);

        /**
         * Add attributes to the eav/attribute
         */
        $eavSetup->removeAttribute(\Magento\Catalog\Model\Product::ENTITY, 'battery');
        $eavSetup->addAttribute(
            \Magento\Catalog\Model\Product::ENTITY,
            'battery',/* Custom Attribute Code */
            [
                'group' => 'SMK Attributes',
                'type' => 'text',
                'backend' => '',
                'frontend' => '',
                'label' => 'Battery',
                'input' => 'text',
                'class' => '',
                'source' => '',
                'global' => \Magento\Eav\Model\Entity\Attribute\ScopedAttributeInterface::SCOPE_GLOBAL,
                /*Scope of your attribute */
                'visible' => true,
                'required' => false,
                'user_defined' => true,
                'default' => '',
                'searchable' => false,
                'filterable' => true,
                'comparable' => false,
                'visible_on_front' => false,
                'used_in_product_listing' => true,
                'unique' => false,
                'apply_to' => ''
            ]
        );
    }

    private function createProductResolutionAtrribute($setup)
    {
        $eavSetup = $this->eavSetupFactory->create(['setup' => $setup]);

        /**
         * Add attributes to the eav/attribute
         */
        $eavSetup->removeAttribute(\Magento\Catalog\Model\Product::ENTITY, 'resolution');
        $eavSetup->addAttribute(
            \Magento\Catalog\Model\Product::ENTITY,
            'resolution',/* Custom Attribute Code */
            [
                'group' => 'SMK Attributes',
                'type' => 'text',
                'backend' => '',
                'frontend' => '',
                'label' => 'Resolution',
                'input' => 'text',
                'class' => '',
                'source' => '',
                'global' => \Magento\Eav\Model\Entity\Attribute\ScopedAttributeInterface::SCOPE_GLOBAL,
                /*Scope of your attribute */
                'visible' => true,
                'required' => false,
                'user_defined' => true,
                'default' => '',
                'searchable' => false,
                'filterable' => true,
                'comparable' => false,
                'visible_on_front' => false,
                'used_in_product_listing' => true,
                'unique' => false,
                'apply_to' => ''
            ]
        );
    }

    private function createProductOperatingSystemAtrribute($setup)
    {
        $eavSetup = $this->eavSetupFactory->create(['setup' => $setup]);

        /**
         * Add attributes to the eav/attribute
         */
        $eavSetup->removeAttribute(\Magento\Catalog\Model\Product::ENTITY, 'operating_system');
        $eavSetup->addAttribute(
            \Magento\Catalog\Model\Product::ENTITY,
            'operating_system',/* Custom Attribute Code */
            [
                'group' => 'SMK Attributes',
                'type' => 'text',
                'backend' => '',
                'frontend' => '',
                'label' => 'Operating System',
                'input' => 'text',
                'class' => '',
                'source' => '',
                'global' => \Magento\Eav\Model\Entity\Attribute\ScopedAttributeInterface::SCOPE_GLOBAL,
                /*Scope of your attribute */
                'visible' => true,
                'required' => false,
                'user_defined' => true,
                'default' => '',
                'searchable' => false,
                'filterable' => true,
                'comparable' => false,
                'visible_on_front' => false,
                'used_in_product_listing' => true,
                'unique' => false,
                'apply_to' => ''
            ]
        );
    }

    private function createProductStoreQuantityAtrribute($setup)
    {
        $eavSetup = $this->eavSetupFactory->create(['setup' => $setup]);

        /**
         * Add attributes to the eav/attribute
         */
        $eavSetup->removeAttribute(\Magento\Catalog\Model\Product::ENTITY, 'store_quantity');
        $eavSetup->addAttribute(
            \Magento\Catalog\Model\Product::ENTITY,
            'store_quantity',/* Custom Attribute Code */
            [
                'group' => 'SMK Attributes',
                'type' => 'text',
                'backend' => '',
                'frontend' => '',
                'label' => 'Store Quantity',
                'input' => 'text',
                'class' => '',
                'source' => '',
                'global' => \Magento\Eav\Model\Entity\Attribute\ScopedAttributeInterface::SCOPE_GLOBAL,
                /*Scope of your attribute */
                'visible' => true,
                'required' => false,
                'user_defined' => true,
                'default' => '',
                'searchable' => false,
                'filterable' => true,
                'comparable' => false,
                'visible_on_front' => false,
                'used_in_product_listing' => true,
                'unique' => false,
                'apply_to' => ''
            ]
        );
    }

    private function createProductHunPerGuarAtrribute($setup)
    {
        $eavSetup = $this->eavSetupFactory->create(['setup' => $setup]);

        /**
         * Add attributes to the eav/attribute
         */
        $eavSetup->removeAttribute(\Magento\Catalog\Model\Product::ENTITY, 'store_quantity');
        $eavSetup->addAttribute(
            \Magento\Catalog\Model\Product::ENTITY,
            'hun_per_guar',/* Custom Attribute Code */
            [
                'group' => 'SMK Attributes',
                'type' => 'text',
                'backend' => '',
                'frontend' => '',
                'label' => 'Hun Per Guar',
                'input' => 'text',
                'class' => '',
                'source' => '',
                'global' => \Magento\Eav\Model\Entity\Attribute\ScopedAttributeInterface::SCOPE_GLOBAL,
                /*Scope of your attribute */
                'visible' => true,
                'required' => false,
                'user_defined' => true,
                'default' => '',
                'searchable' => false,
                'filterable' => true,
                'comparable' => false,
                'visible_on_front' => false,
                'used_in_product_listing' => true,
                'unique' => false,
                'apply_to' => ''
            ]
        );
    }

    private function createProductPopularityAtrribute($setup)
    {
        $eavSetup = $this->eavSetupFactory->create(['setup' => $setup]);

        /**
         * Add attributes to the eav/attribute
         */
        $eavSetup->removeAttribute(\Magento\Catalog\Model\Product::ENTITY, 'store_quantity');
        $eavSetup->addAttribute(
            \Magento\Catalog\Model\Product::ENTITY,
            'popularity',/* Custom Attribute Code */
            [
                'group' => 'SMK Attributes',
                'type' => 'text',
                'backend' => '',
                'frontend' => '',
                'label' => 'Popularity',
                'input' => 'text',
                'class' => '',
                'source' => '',
                'global' => \Magento\Eav\Model\Entity\Attribute\ScopedAttributeInterface::SCOPE_GLOBAL,
                /*Scope of your attribute */
                'visible' => true,
                'required' => false,
                'user_defined' => true,
                'default' => '',
                'searchable' => false,
                'filterable' => true,
                'comparable' => false,
                'visible_on_front' => false,
                'used_in_product_listing' => true,
                'unique' => false,
                'apply_to' => ''
            ]
        );
    }

    private function createProductManufacturingPartNumberAtrribute($setup)
    {
        $eavSetup = $this->eavSetupFactory->create(['setup' => $setup]);

        /**
         * Add attributes to the eav/attribute
         */
        $eavSetup->removeAttribute(\Magento\Catalog\Model\Product::ENTITY, 'manufacturing_part_number');
        $eavSetup->addAttribute(
            \Magento\Catalog\Model\Product::ENTITY,
            'manufacturing_part_number',/* Custom Attribute Code */
            [
                'group' => 'SMK Attributes',
                'type' => 'text',
                'backend' => '',
                'frontend' => '',
                'label' => 'Manufacturing Part Number',
                'input' => 'text',
                'class' => '',
                'source' => '',
                'global' => \Magento\Eav\Model\Entity\Attribute\ScopedAttributeInterface::SCOPE_GLOBAL,
                /*Scope of your attribute */
                'visible' => true,
                'required' => false,
                'user_defined' => true,
                'default' => '',
                'searchable' => false,
                'filterable' => true,
                'comparable' => false,
                'visible_on_front' => false,
                'used_in_product_listing' => true,
                'unique' => false,
                'apply_to' => ''
            ]
        );
    }

    private function createProductShippingEstimationAtrribute($setup)
    {
        $eavSetup = $this->eavSetupFactory->create(['setup' => $setup]);

        /**
         * Add attributes to the eav/attribute
         */
        $eavSetup->removeAttribute(\Magento\Catalog\Model\Product::ENTITY, 'shipping_estimation');
        $eavSetup->addAttribute(
            \Magento\Catalog\Model\Product::ENTITY,
            'shipping_estimation',/* Custom Attribute Code */
            [
                'group' => 'SMK Attributes',
                'type' => 'text',
                'backend' => '',
                'frontend' => '',
                'label' => 'Shipping to Singapore',
                'input' => 'text',
                'class' => '',
                'source' => '',
                'global' => \Magento\Eav\Model\Entity\Attribute\ScopedAttributeInterface::SCOPE_GLOBAL,
                /*Scope of your attribute */
                'visible' => true,
                'required' => false,
                'user_defined' => true,
                'default' => '',
                'searchable' => false,
                'filterable' => true,
                'comparable' => false,
                'visible_on_front' => false,
                'used_in_product_listing' => true,
                'unique' => false,
                'apply_to' => ''
            ]
        );
    }
}
