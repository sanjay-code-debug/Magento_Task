<?php

namespace Codilar\CountryList\Model;

use Magento\Framework\Model\AbstractModel;
use Codilar\CountryList\Model\ResourceModel\CountryList as ResourceModel;

class CountryList extends AbstractModel
{
    protected function _construct()
    {
        $this->_init(ResourceModel::class);
    }
}
