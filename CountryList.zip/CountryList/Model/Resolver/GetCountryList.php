<?php

namespace Codilar\CountryList\Model\Resolver;

use Codilar\CountryList\Model\ResourceModel\CountryList\Collection;

use Magento\Framework\GraphQl\Config\Element\Field;
use Magento\Framework\GraphQl\Query\ResolverInterface;
use Magento\Framework\GraphQl\Schema\Type\ResolveInfo;

class GetCountryList implements ResolverInterface{

    /**
     * @var Collection
     */
    private $collection;

    public function __construct(Collection $collection)
    {
        $this->collection = $collection;
    }

    public function resolve(Field $field, $context, ResolveInfo $info, array $value = null, array $args = null)
    {
        $details = $this->collection->getData();
        global  $ar;
        $ar = array();

        foreach ($details as $detail)
        {
           $id =  $detail['id'];
           $dial_code = $detail['dial_code'];
           $country_name = $detail['country_name'];
           $country_code = $detail['country_code'];
           $ar[]=['id'=>$id,'dial_code'=>$dial_code,'country_name'=>$country_name,'country_code'=>$country_code];
        }
        return $ar;
    }
}
