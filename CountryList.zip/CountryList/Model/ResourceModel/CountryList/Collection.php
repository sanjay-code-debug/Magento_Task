<?php

namespace Codilar\CountryList\Model\ResourceModel\CountryList;

use Codilar\CountryList\Model\CountryList;
use Codilar\CountryList\Model\ResourceModel\CountryList as CountryResource;
use Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection;

class Collection extends AbstractCollection
{
    protected function _construct()
    {
        $this->_init(CountryList::class, CountryResource::class);
    }
}


