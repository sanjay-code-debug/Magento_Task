<?php

namespace  Codilar\Demo\Block;
use Magento\Backend\Block\Template;
use Magento\Backend\Block\Template\Context;
use Magento\Framework\Registry;
use Codilar\Demo\Controller\Adminhtml\Info\Edit;

class Download extends Template{

    /**
     * @var string
     */
    protected  $_template='download.phtml';

    protected $edit;

    /**
     * Core registry
     *
     * @var Registry
     */
    protected $_coreRegistry = null;

    public function __construct(
        Context $context,
        Registry $registry,
        Edit $edit,
        array $data=[]
    )
    {
        parent::__construct($context, $data);
        $this->_coreRegistry = $registry;
        $this->edit = $edit;
    }
    /** Getting Session Method Value From Edit Class of Controller  */
    public function getImageFromEditClass(){
        return $this->edit->getImageFromSession();
    }
}
