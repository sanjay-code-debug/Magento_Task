var config = {
    "map": {
        "*": {
            'Magento_Checkout/js/model/shipping-save-processor/default': 'Codilar_Demo/js/model/shipping-save-processor/default'
        }
    }
};
