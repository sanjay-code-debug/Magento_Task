<?php

namespace Codilar\Demo\Controller\Adminhtml\Info;

use Magento\Backend\App\Action;
use Magento\Framework\App\ResponseInterface;
use Magento\Framework\Controller\ResultInterface;
use Magento\Framework\View\Result\Page;
use Magento\Framework\View\Result\PageFactory;
use Magento\Framework\Session\SessionManager;

use Codilar\Demo\Model\ResourceModel\BrandsInfo\Collection;

class Edit extends Action
{
    const ADMIN_RESOURCE = "Codilar_Demo::brand_list";
    /**
     * @var PageFactory
     */
    private $pageFactory;
    /**
     * @var Collection
     */
    private $collection;
    /**
     * @var SessionManager
     */
    private $session;

    public function __construct(
        Action\Context $context,
        PageFactory $pageFactory,
        Collection $collection,
        SessionManager $session
    ) {
        parent::__construct($context);
        $this->pageFactory = $pageFactory;
        $this->collection=$collection;
        $this->session=$session;
    }

    /**
     * @return ResponseInterface|ResultInterface|Page
     */
    public function execute()
    {
        $this->setImageToSession();
        $resultPage = $this->pageFactory->create();
        $resultPage->getConfig()->getTitle()->prepend(__('Edit  User'));
        return $resultPage;
    }

    /** Getting Image by id  */
    public function getImage(){
        $id =  $this->getRequest()->getParam('id');
        $img = $this->collection->getItemById($id);
        return $img['image'];
    }

    /** Setting image to Session */
    public function setImageToSession(){
          $imgValue = $this->getImage();
          $this->session->start();
          $this->session->setMessage($imgValue);
    }

    /** Getting The Session Value  */
    public function getImageFromSession(){
        return $this->session->getMessage();
    }
}
