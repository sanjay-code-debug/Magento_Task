<?php

namespace Codilar\Demo\Controller\Adminhtml\Info;

use Codilar\Demo\Api\BrandsRepositoryInterface;
use Codilar\Demo\Model\DataProvider;
use Magento\Backend\App\Action;
use Magento\Backend\App\Action\Context;
use Magento\Framework\App\Request\DataPersistorInterface;
use Magento\Framework\App\ResponseInterface;
use Magento\Framework\Controller\ResultFactory;
use Magento\Framework\Controller\ResultInterface;
use Magento\Framework\Exception\LocalizedException;

use Codilar\Demo\Model\ResourceModel\BrandsInfo\Collection;

class Save extends Action
{
    protected $dataPersistor;
    private $dataProvider;
    private $brandsRepository;
    private $collection;

    public function __construct(
        Context $context,
        DataPersistorInterface $dataPersistor,
        BrandsRepositoryInterface $brandsRepository,
        DataProvider $dataProvider,
        Collection $collection
    ) {
        $this->dataPersistor = $dataPersistor;
        $this->dataProvider = $dataProvider;
        parent::__construct($context);
        $this->brandsRepository = $brandsRepository;
        $this->collection=$collection;
    }

    /** Method To Save The Data To Database  */
    public function saveNewImage($name, $phone, $email, $address, $dob, $image, $brand)
    {
        $imageFullPath = '';
        if (is_array($image)) {
            $image = $image[0];
            $imageName = $image['name'] ?? null;
            $newImgRelativePath = $this->dataProvider->moveFileFromTmp($imageName);
            $imageFullPath = $this->dataProvider->getBasePath() . '/' . $newImgRelativePath;
        }
        $brand->setName($name);
        $brand->setDob($dob);
        $brand->setPhone($phone);
        $brand->setEmail($email);
        $brand->setAddress($address);
        $brand->setImage($imageFullPath);
        $this->brandsRepository->save($brand);
    }

    /**
     * @return ResponseInterface|ResultInterface
     * @throws LocalizedException
     */
    public function execute()
    {
        /** Getting Data From  Form Field through Url */
        $id = $this->getRequest()->getParam('id');
        $name = $this->getRequest()->getParam('name');
        $dob =  $this->getRequest()->getParam('dob');
        $phone = $this->getRequest()->getParam('phone');
        $email = $this->getRequest()->getParam('email');
        $address = $this->getRequest()->getParam('address');
        $image = $this->getRequest()->getParam('image');

        $dbEmail = $this->collection->getColumnValues('email');
        $dbPhone = $this->collection->getColumnValues('phone');

        $resultEmail =$this->checkEmail($dbEmail,$email);
        $resultPhone =$this->checkPhoneNumber($dbPhone,$phone);

        /** Getting Image From Database */
        $dbImage = $this->collection->getItemById($id);

        /** variable for setting the url */
        $resultRedirect = $this->resultFactory->create(ResultFactory::TYPE_REDIRECT);
        $brand = $this->brandsRepository->load($id);

        if($dbImage != NULL)
        {
            /** Here Getting only Database image name */
            $dbLocalImage = explode("/", $dbImage['image']);
            $dbLocalName = end($dbLocalImage);

            /**  Here Getting only Local image name  */
            $fetchImg = explode("/", $image[0]['name']);
            $splitImg = end($fetchImg);

            if ($dbLocalName == $splitImg)
            {
                $brand->setName($name);
                $brand->setDob($dob);
                $brand->setPhone($phone);
                $brand->setEmail($email);
                $brand->setAddress($address);
                $this->brandsRepository->save($brand);
                $this->messageManager->addSuccessMessage('User  successfully save');
                $resultRedirect->setUrl($this->getUrl('brand/info/index'));
                return $resultRedirect;
            }
            else {
                $this->saveNewImage($name,$phone,$email,$address,$dob,$image,$brand);
                $this->messageManager->addSuccessMessage('User  successfully save');
                $resultRedirect->setUrl($this->getUrl('brand/info/index'));
                return $resultRedirect;
            }
        }
        else {
            if ($resultEmail && $resultPhone) {
//                $this->saveNewImage($name, $phone, $email, $address, $dob, $image, $brand);
//                $this->messageManager->addSuccessMessage('User  successfully save');
//                $resultRedirect->setUrl($this->getUrl('brand/info/index'));
//                return $resultRedirect;
                $this->messageManager->addErrorMessage("Email already exist");
                $this->messageManager->addErrorMessage("Phone number already exist");
                $redirect = $this->resultRedirectFactory->create();
                $redirect->setPath('brand/info/add');
                return $redirect;
            }else{
                if ($resultPhone){
                    $this->messageManager->addErrorMessage("Phone number already exist");
                    $redirect = $this->resultRedirectFactory->create();
                    $redirect->setPath('brand/info/add');
                    return $redirect;
                }
                else{
                    if ($resultEmail){
                        $this->messageManager->addErrorMessage("Email already exist");
                        $redirect = $this->resultRedirectFactory->create();
                        $redirect->setPath('brand/info/add');
                        return $redirect;
                    }else{
                        $this->saveNewImage($name, $phone, $email, $address, $dob, $image, $brand);
                        $this->messageManager->addSuccessMessage('User  successfully save');
                        $resultRedirect->setUrl($this->getUrl('brand/info/index'));
                        return $resultRedirect;
                    }
                }
            }
        }
    }

    /** Method To Check the Email  */
    public  function checkEmail($dbEmail,$email){
        foreach ($dbEmail as $em) {
            if ($em===$email){
                return true;
            }
        }
        return false;
    }
    /** Method To Check the Phone
     *
     **  Only we can get this method value if we can pass this method inside the execute method(pre defind method)
     */
    public  function checkPhoneNumber($dbPhone,$phone){
        foreach ($dbPhone as $ph) {
            if ($ph===$phone){
                return true;
            }
        }
        return false;
    }
}

