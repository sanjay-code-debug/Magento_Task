<?php

namespace Codilar\OverrideDelete\Controller\Adminhtml\Index;

use Magento\Customer\Api\AccountManagementInterface;
use Magento\Customer\Api\AddressRepositoryInterface;
use Magento\Customer\Api\CustomerRepositoryInterface;
use Magento\Customer\Api\Data\AddressInterfaceFactory;
use Magento\Customer\Api\Data\CustomerInterfaceFactory;
use Magento\Customer\Model\Address\Mapper;
use Magento\Framework\Api\DataObjectHelper;
use Magento\Framework\App\Action\HttpPostActionInterface as HttpPostActionInterface;
use Magento\Framework\Controller\ResultFactory;

use Codilar\KYC\Model\KYCFactory;
use Magento\Framework\DataObjectFactory as ObjectFactory;

/**
 * Delete customer action.
 */
class Delete extends \Magento\Customer\Controller\Adminhtml\Index implements HttpPostActionInterface
{

    /**
     * @var KYCFactory
     */
    private $kycFactory;

    public function __construct
  (
      \Magento\Backend\App\Action\Context $context,
      \Magento\Framework\Registry $coreRegistry,
      \Magento\Framework\App\Response\Http\FileFactory $fileFactory,
      \Magento\Customer\Model\CustomerFactory $customerFactory,
      \Magento\Customer\Model\AddressFactory $addressFactory,
      \Magento\Customer\Model\Metadata\FormFactory $formFactory,
      \Magento\Newsletter\Model\SubscriberFactory $subscriberFactory,
      \Magento\Customer\Helper\View $viewHelper,
      \Magento\Framework\Math\Random $random,
      CustomerRepositoryInterface $customerRepository,
      \Magento\Framework\Api\ExtensibleDataObjectConverter $extensibleDataObjectConverter,
      Mapper $addressMapper, AccountManagementInterface $customerAccountManagement,
      AddressRepositoryInterface $addressRepository,
      CustomerInterfaceFactory $customerDataFactory,
      AddressInterfaceFactory $addressDataFactory,
      \Magento\Customer\Model\Customer\Mapper $customerMapper,
      \Magento\Framework\Reflection\DataObjectProcessor $dataObjectProcessor,
      DataObjectHelper $dataObjectHelper, ObjectFactory $objectFactory,
      \Magento\Framework\View\LayoutFactory $layoutFactory,
      \Magento\Framework\View\Result\LayoutFactory $resultLayoutFactory,
      \Magento\Framework\View\Result\PageFactory $resultPageFactory,
      \Magento\Backend\Model\View\Result\ForwardFactory $resultForwardFactory,
      \Magento\Framework\Controller\Result\JsonFactory $resultJsonFactory,
      KYCFactory $kycFactory
  )
  {
      parent::__construct($context, $coreRegistry, $fileFactory, $customerFactory, $addressFactory, $formFactory, $subscriberFactory, $viewHelper, $random, $customerRepository, $extensibleDataObjectConverter, $addressMapper, $customerAccountManagement, $addressRepository, $customerDataFactory, $addressDataFactory, $customerMapper, $dataObjectProcessor, $dataObjectHelper, $objectFactory, $layoutFactory, $resultLayoutFactory, $resultPageFactory, $resultForwardFactory, $resultJsonFactory);
      $this->kycFactory = $kycFactory;
  }


    /**
     * Authorization level of a basic admin session
     *
     * @see _isAllowed()
     */
    const ADMIN_RESOURCE = 'Magento_Customer::delete';

    /**
     * Delete customer action
     *
     * @return \Magento\Backend\Model\View\Result\Redirect
     */
    public function execute()
    {
        $resultRedirect = $this->resultRedirectFactory->create();
        $formKeyIsValid = $this->_formKeyValidator->validate($this->getRequest());
        $isPost = $this->getRequest()->isPost();
        if (!$formKeyIsValid || !$isPost) {
            $this->messageManager->addErrorMessage(__('Customer could not be deleted.'));
            return $resultRedirect->setPath('customer/index');
        }

        $customerId = $this->initCurrentCustomer();
        if (!empty($customerId)) {
            try {

                $collection = $this->kycFactory->create()->getCollection()
                    ->addFieldToFilter('customer_id', $customerId)
                    ->getFirstItem();
                $id = $collection->getId();
                $kyc = $this->kycFactory->create()->load($id);
                $kyc->delete();
                $this->_customerRepository->deleteById($customerId);
                $this->messageManager->addSuccessMessage(__('You deleted the customer with Kyc Data Related to This ID.'));
            } catch (\Exception $exception) {
                $this->messageManager->addErrorMessage($exception->getMessage());
            }
        }

        /** @var \Magento\Backend\Model\View\Result\Redirect $resultRedirect */
        $resultRedirect = $this->resultFactory->create(ResultFactory::TYPE_REDIRECT);
        return $resultRedirect->setPath('customer/index');
    }
}
