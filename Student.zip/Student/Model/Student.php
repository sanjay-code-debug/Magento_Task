<?php
namespace Adobe\Student\Model;

use Adobe\Student\Api\Data\StudentInterface;
use Magento\Framework\Model\AbstractModel;
use Adobe\Student\Model\ResourceModel\Student as ResourceModel;

class Student extends AbstractModel implements StudentInterface
{
    /**
     * @return void
     */
    protected function _construct()
    {
        $this->_init(ResourceModel::class);
    }

    /**
     * @inerhitDoc
     */
    public function getId()
    {
        return $this->_getData(self::ID);
    }

    /**
     * @inerhitDoc
     */
    public function setId($id)
    {
        // TODO: Implement setId() method.
    }

    /**
     * @inerhitDoc
     */
    public function getName()
    {
        return $this->_getData(self::NAME);
    }

    /**
     * @inerhitDoc
     */
    public function setName($name)
    {
        $this->setData(self::NAME, $name);
    }
    /**
     * @inerhitDoc
     */
    public function getEmail()
    {
        return $this->_getData(self::EMAIL);
    }

    /**
     * @inerhitDoc
     */
    public function setEmail($email)
    {
        $this->setData(self::EMAIL, $email);
    }

    /**
     * @inerhitDoc
     */
    public function getAddress()
    {
        return $this->_getData(self::ADDRESS);
    }

    /**
     * @inerhitDoc
     */
    public function setAddress($address)
    {
        $this->setData(self::ADDRESS, $address);
    }
}
