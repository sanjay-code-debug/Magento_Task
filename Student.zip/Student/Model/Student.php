<?php
/**
 * Copyright © sanjay, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */

namespace Adobe\Student\Model;

use Adobe\Student\Api\Data\StudentExtensionInterface;
use Adobe\Student\Api\Data\StudentInterface;
use Magento\Framework\Model\AbstractExtensibleModel;
use Magento\Framework\Model\AbstractModel;
use Adobe\Student\Model\ResourceModel\Student as ResourceModel;

class Student extends AbstractExtensibleModel implements StudentInterface
{
    /**
     * @return void
     */
    protected function _construct()
    {
        $this->_init(ResourceModel::class);
    }

    /**
     * @inerhitDoc
     */
    public function getStudentId()
    {
        return $this->_getData(self::STUDENT_ID);
    }

    /**
     * @inerhitDoc
     */
    public function setStudentId($studentId)
    {
        return $this->setData(self::STUDENT_ID, $studentId);
    }

    /**
     * @inerhitDoc
     */
    public function getName()
    {
        return $this->_getData(self::NAME);
    }

    /**
     * @inerhitDoc
     */
    public function setName($name)
    {
        $this->setData(self::NAME, $name);
    }

    /**
     * @inerhitDoc
     */
    public function getEmail()
    {
        return $this->_getData(self::EMAIL);
    }

    /**
     * @inerhitDoc
     */
    public function setEmail($email)
    {
        $this->setData(self::EMAIL, $email);
    }

    /**
     * @inerhitDoc
     */
    public function getAddress()
    {
        return $this->_getData(self::ADDRESS);
    }

    /**
     * @inerhitDoc
     */
    public function setAddress($address)
    {
        $this->setData(self::ADDRESS, $address);
    }

    /**
     * @inerhitDoc
     */
    public function getMark()
    {
        return $this->_getData(self::MARK);
    }

    /**
     * @inerhitDoc
     */
    public function setMark($mark)
    {
        $this->setData(self::MARK, $mark);
    }

    /**
     * @inerhitDoc
     */
    public function getExtensionAttributes()
    {
        return $this->_getExtensionAttributes();
    }

    /**
     * @inerhitDoc
     */
    public function setExtensionAttributes(\Adobe\Student\Api\Data\StudentExtensionInterface $extensionAttributes)
    {
        $this->_setExtensionAttributes($extensionAttributes);
    }
}
