<?php
namespace Adobe\Student\Model;

use Adobe\Student\Api\Data\StudentInterface;
use Adobe\Student\Api\StudentRepositoryInterface;
use Adobe\Student\Model\StudentFactory;
use Adobe\Student\Model\ResourceModel\Student;
use Adobe\Student\Model\ResourceModel\Student\CollectionFactory;
use Braintree\Exception\NotFound;

class StudentRepository implements StudentRepositoryInterface
{

    /**
     * @var \Adobe\Student\Model\StudentFactory
     */
    private \Adobe\Student\Model\StudentFactory $studentFactory;

    /**
     * @var Student
     */
    private Student $studentResource;

    /**
     * @var CollectionFactory
     */
    private CollectionFactory $collectionFactory;

    /**
     * @param \Adobe\Student\Model\StudentFactory $studentFactory
     * @param Student $studentResource
     */
    function __construct(
        StudentFactory $studentFactory,
        Student $studentResource,
        CollectionFactory $collectionFactory
    ) {
        $this->studentFactory = $studentFactory;
        $this->studentResource = $studentResource;
        $this->collectionFactory = $collectionFactory;
    }

    /**
     * @inerhitDoc
     */
    public function getDataById($id)
    {
        $student =$this->studentFactory->create();
        $this->studentResource->load($student, $id);
        return $student;
    }

    /**
     * @inerhitDoc
     */
    public function delete(StudentInterface $student)
    {
        return $this->deleteById($student->getStudentId());
    }

    /**
     * @inerhitDoc
     * @throws NotFound
     */
    public function deleteById($studentId)
    {
        $collection =$this->collectionFactory->create();
        try {
            $student = $collection->getItemById($studentId);
            $collection->getResource()->delete($student);
        } catch (\Exception $e) {
            throw new NotFound('Data not Present');
        }
        return true;
    }

    /**
     * @inerhitDoc
     * @throws \Magento\Framework\Exception\AlreadyExistsException
     */
    public function save(StudentInterface $student)
    {
         $collection = $this->collectionFactory->create();
         $collection->getResource()->save($student);
         return $student;
    }

    /**
     * @inerhitDoc
     */
    public function update()
    {
        // TODO: Implement update() method.
    }
}
