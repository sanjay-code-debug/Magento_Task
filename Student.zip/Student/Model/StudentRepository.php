<?php
/**
 * Copyright © sanjay, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Adobe\Student\Model;

use Adobe\Student\Api\Data\StudentInterface;
use Adobe\Student\Api\StudentRepositoryInterface;
use Adobe\Student\Model\StudentFactory;
use Adobe\Student\Model\ResourceModel\Student;
use Adobe\Student\Model\ResourceModel\Student\CollectionFactory;
use Braintree\Exception\NotFound;
use Magento\Framework\Api\SearchCriteria\CollectionProcessorInterface;
use Adobe\Student\Api\Data\StudentSearchInterfaceFactory;

class StudentRepository implements StudentRepositoryInterface
{

    /**
     * @var \Adobe\Student\Model\StudentFactory
     */
    private \Adobe\Student\Model\StudentFactory $studentFactory;

    /**
     * @var Student
     */
    private Student $studentResource;

    /**
     * @var CollectionFactory
     */
    private CollectionFactory $collectionFactory;
    /**
     * @var StudentSearchInterfaceFactory
     */
    private StudentSearchInterfaceFactory $searchInterfaceFactory;
    private CollectionProcessorInterface $collectionProcessorInterface;

    /**
     * @param \Adobe\Student\Model\StudentFactory $studentFactory
     * @param Student $studentResource
     */
    public function __construct(
        StudentFactory $studentFactory,
        Student $studentResource,
        CollectionFactory $collectionFactory,
        CollectionProcessorInterface $collectionProcessorInterface,
        StudentSearchInterfaceFactory $searchInterfaceFactory
    ) {
        $this->studentFactory = $studentFactory;
        $this->studentResource = $studentResource;
        $this->collectionFactory = $collectionFactory;
        $this->searchInterfaceFactory = $searchInterfaceFactory;
        $this->collectionProcessorInterface = $collectionProcessorInterface;
    }

    /**
     * @inerhitDoc
     */
    public function getDataById($id)
    {
        $student = $this->studentFactory->create();
        $this->studentResource->load($student, $id);
        return $student;
    }

    /**
     * @inerhitDoc
     */
    public function delete(StudentInterface $student)
    {
        return $this->deleteById($student->getStudentId());
    }

    /**
     * @inerhitDoc
     * @throws NotFound
     */
    public function deleteById($studentId)
    {
        $collection = $this->collectionFactory->create();
        try {
            $student = $collection->getItemById($studentId);
            $collection->getResource()->delete($student);
        } catch (\Exception $e) {
            throw new NotFound('Data not Present');
        }
        return true;
    }

    /**
     * @inerhitDoc
     * @throws \Magento\Framework\Exception\AlreadyExistsException
     */
    public function save(StudentInterface $student)
    {
        $collection = $this->collectionFactory->create();
        $collection->getResource()->save($student);
        return $student;
    }

    /**
     * Get Student list
     *
     * @param \Magento\Framework\Api\SearchCriteriaInterface $searchCriteria
     * @return \Adobe\Student\Api\Data\StudentSearchInterface
     */
    public function getList(\Magento\Framework\Api\SearchCriteriaInterface $searchCriteria)
    {
        $collection = $this->collectionFactory->create();
        $this->collectionProcessorInterface->process($searchCriteria, ($collection));
        $searchData = $this->searchInterfaceFactory->create();
        $searchData->setSearchCriteria($searchCriteria);
        $searchData->setItems($collection->getItems());
        $searchData->setTotalCount($collection->getSize());
        $searchData->setSearchCriteria($searchCriteria);
        return $searchData;
    }

    /**
     * @inerhitDoc
     * @throws \Magento\Framework\Exception\AlreadyExistsException
     */
    public function update(StudentInterface $student)
    {
        $this->studentResource->save($student);
        return $student;
    }
}
