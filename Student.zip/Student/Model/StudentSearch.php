<?php
/**
 * Copyright © sanjay, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */

namespace Adobe\Student\Model;

use Magento\Framework\Api\SearchResults;
use Adobe\Student\Api\Data\StudentSearchInterface;

class StudentSearch extends SearchResults implements StudentSearchInterface
{

}
