<?php
/**
 * Copyright © sanjay, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */

namespace Adobe\Student\Model\ResourceModel;

use Magento\Framework\Model\ResourceModel\Db\AbstractDb;

class Student extends AbstractDb
{
    /**
     * @return void
     */
    protected function _construct()
    {
        $this->_init('student_info', 'student_id');
    }
}
