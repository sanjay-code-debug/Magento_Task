<?php
/**
 *
 * Copyright © sanjay, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Adobe\Student\Api\Data;

use Magento\Framework\Api\SearchResultsInterface;

interface StudentSearchInterface extends SearchResultsInterface
{

    /**
     * @return \Adobe\Student\Api\Data\StudentInterface[]
     */
    public function getItems();

    /**
     * @param \Adobe\Student\Api\Data\StudentInterface[] $items
     * @return void
     */
    public function setItems(array $items);
}
