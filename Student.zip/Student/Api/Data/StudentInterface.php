<?php
/**
 *
 * Copyright © sanjay, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */

namespace Adobe\Student\Api\Data;

use Magento\Framework\Api\ExtensibleDataInterface;

interface StudentInterface extends ExtensibleDataInterface
{
    const STUDENT_ID = 'student_id';
    const NAME = 'name';
    const EMAIL = 'email';
    const ADDRESS = 'address';
    const MARK = 'mark';

    /**
     * @return int|null
     */
    public function getStudentId();

    /**
     * @param int $studentId
     * @return void
     */
    public function setStudentId(int $studentId);

    /**
     * @return string|null
     */
    public function getName();

    /**
     * @param string $name
     * @return void
     */
    public function setName($name);

    /**
     * @return string|null
     */
    public function getEmail();

    /**
     * @param string $email
     * @return void
     */
    public function setEmail($email);

    /**
     * @return string|null
     */
    public function getAddress();

    /**
     * @param string $address
     * @return void
     */
    public function setAddress($address);

    /**
     * @return int|null
     */
    public function getMark();

    /**
     * @param int $mark
     * @return void
     */
    public function setMark($mark);

    /**
     * @return \Adobe\Student\Api\Data\StudentExtensionInterface
     */
    public function getExtensionAttributes();

    /**
     * @param \Adobe\Student\Api\Data\StudentExtensionInterface $extensionAttributes
     * @return mixed
     */
    public function setExtensionAttributes(\Adobe\Student\Api\Data\StudentExtensionInterface $extensionAttributes);
}
