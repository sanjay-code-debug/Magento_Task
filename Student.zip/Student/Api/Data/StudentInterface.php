<?php
namespace Adobe\Student\Api\Data;

interface StudentInterface
{
    const ID = 'id';
    const NAME ='name';
    const EMAIL ='email';
    const ADDRESS='address';

    /**
     * @return int|null
     */
    public function getId();

    /**
     * @param int $id
     * @return void
     */
    public function setId($id);

    /**
     * @return string|null
     */
    public function getName();

    /**
     * @param string $name
     * @return void
     */
    public function setName($name);

    /**
     * @return string|null
     */
    public function getEmail();

    /**
     * @param string $email
     * @return void
     */
    public function setEmail($email);

    /**
     * @return string|null
     */
    public function getAddress();

    /**
     * @param string $address
     * @return void
     */
    public function setAddress($address);
}
