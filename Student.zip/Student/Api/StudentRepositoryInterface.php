<?php
namespace Adobe\Student\Api;

use Adobe\Student\Api\Data\StudentInterface;

interface StudentRepositoryInterface
{
    /**
     * @param int $id
     * @return \Adobe\Student\Api\Data\StudentInterface
     */
    public function getDataById($id);

    /**
     * @param \Adobe\Student\Api\Data\StudentInterface $student
     * @return boolean
     */
    public function delete(StudentInterface $student);

    /**
     * @param int $studentId
     * @return boolean
     */
    public function deleteById($studentId);

    /**
     * @param \Adobe\Student\Api\Data\StudentInterface $student
     * @return StudentInterface
     */
    public function save(StudentInterface $student);

    /**
     * @param \Adobe\Student\Api\Data\StudentInterface $student
     * @return StudentInterface
     */
    public function update();

}
