<?php
/**
 *
 * Copyright © sanjay, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */

namespace Adobe\Student\Api;

use Adobe\Student\Api\Data\StudentInterface;

interface StudentRepositoryInterface
{
    /**
     * @param int $studentId
     * @return \Adobe\Student\Api\Data\StudentInterface
     */
    public function getDataById($studentId);

    /**
     * @param \Adobe\Student\Api\Data\StudentInterface $student
     * @return boolean
     */
    public function delete(StudentInterface $student);

    /**
     * @param int $studentId
     * @return boolean
     */
    public function deleteById($studentId);

    /**
     * @param \Adobe\Student\Api\Data\StudentInterface $student
     * @return \Adobe\Student\Api\Data\StudentInterface
     */
    public function save(StudentInterface $student);


    /**
     * @param \Adobe\Student\Api\Data\StudentInterface $student
     * @return \Adobe\Student\Api\Data\StudentInterface
     */
    public function update(StudentInterface $student);

    /**
     * Get Student list
     *
     * @param \Magento\Framework\Api\SearchCriteriaInterface $searchCriteria
     * @return \Adobe\Student\Api\Data\StudentSearchInterface
     */
    public function getList(\Magento\Framework\Api\SearchCriteriaInterface $searchCriteria);
}
