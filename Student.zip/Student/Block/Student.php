<?php
/**
 *
 * Copyright © sanjay, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */

namespace Adobe\Student\Block;

use Magento\Framework\View\Element\Template;
use Adobe\Student\Model\ResourceModel\Student\CollectionFactory;

use Magento\Framework\Api\SearchCriteriaBuilder;
use Adobe\Student\Model\StudentRepository;

class Student extends Template
{
    /**
     * @var CollectionFactory
     */
    private CollectionFactory $collectionFactory;
    /**
     * @var StudentRepository
     */
    private StudentRepository $studentRepository;
    /**
     * @var SearchCriteriaBuilder
     */
    private SearchCriteriaBuilder $searchCriteriaBuilder;

    /**
     * @param Template\Context $context
     * @param CollectionFactory $collectionFactory
     * @param SearchCriteriaBuilder $searchCriteriaBuilder
     * @param StudentRepository $studentRepository
     * @param array $data
     */
    public function __construct(
        Template\Context $context,
        CollectionFactory $collectionFactory,
        SearchCriteriaBuilder $searchCriteriaBuilder,
        StudentRepository $studentRepository,
        array $data = []
    ) {
        parent::__construct($context, $data);
        $this->collectionFactory = $collectionFactory;
        $this->studentRepository = $studentRepository;
        $this->searchCriteriaBuilder = $searchCriteriaBuilder;
    }

    /**
     * here we are getting student data as per condition
     *
     * @return array
     */
    public function studentData()
    {
//        $this->searchCriteriaBuilder->addFilter('address', '%Bangalore%', 'eq');
//        $this->searchCriteriaBuilder->addFilter('roll_number', '123', 'eq');
//        $searchCriteria = $this->searchCriteriaBuilder->create();

        $studentDetail = [];
        $collection = $this->collectionFactory->create();
        $data = $collection->addFieldToFilter('address', ['eq' => 'Bangalore']);

        foreach ($data as $each) {
            $mark = $each->getMark();
            if ($mark > 75) {
                $studentDetail[] = [
                    'id' => $each->getStudentId(),
                    'name' => $each->getName(),
                    'address' => $each->getAddress(),
                    'mark' => $each->getMark()
                ];
            }
        }
        return $studentDetail;
    }
}
