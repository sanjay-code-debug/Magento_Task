<?php

/**
 * Copyright © sanjay, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */

namespace Adobe\Student\Plugin;

use Adobe\Student\Api\Data\StudentInterface;
use Adobe\Student\Api\Data\StudentSearchInterface;
use Adobe\Student\Model\ResourceModel\Student\CollectionFactory;

/**
 * Class StudentRepositoryInterface
 * @package Adobe\Student\Plugin
 */
class StudentRepositoryInterface
{
    /**
     * @var CollectionFactory
     */
    private CollectionFactory $collectionFactory;

    /**
     * StudentRepositoryInterface constructor.
     * @param CollectionFactory $collectionFactory
     */
    public function __construct(CollectionFactory $collectionFactory)
    {
        $this->collectionFactory = $collectionFactory;
    }

    /**
     * Adding extension attribute student_address to getDataById()
     * @param \Adobe\Student\Api\StudentRepositoryInterface $subject
     * @param StudentInterface $student
     * @return StudentInterface
     */
    public function afterGetDataById(
        \Adobe\Student\Api\StudentRepositoryInterface $subject,
        StudentInterface $student
    ) {
        if ($student->getExtensionAttributes() && $student->getExtensionAttributes()->getExStudent()) {
            return $student;
        }
        $studentAddress = $this->getExStudent($student->getStudentId());
        $extensionAttribute = $student->getExtensionAttributes()->setExStudent($studentAddress);
        $student->setExtensionAttributes($extensionAttribute);
        return $student;
    }

    /**
     * @param $id
     * @return array|mixed|null
     */
    public function getExStudent($id)
    {
        return $this->collectionFactory->create()
                ->addFieldToFilter('student_id', ['eq' => $id])
                ->getFirstItem()->getData('ex_student') ?? "";
    }

    /**
     * Adding extension attribute student_address to getList()
     * @param \Adobe\Student\Api\StudentRepositoryInterface $subject
     * @param StudentSearchInterface $searchCriteria
     * @return StudentSearchInterface
     */
    public function afterGetList(
        \Adobe\Student\Api\StudentRepositoryInterface $subject,
        StudentSearchInterface $searchCriteria
    ): StudentSearchInterface {
        $products = [];
        foreach ($searchCriteria->getItems() as $entity) {
            /** Get Current Extension Attributes from Student */
            $extensionAttributes = $entity->getExtensionAttributes();
            $studentAddress = $this->getExStudent($entity->getStudentId());
            $extensionAttributes->setExStudent($studentAddress);
            $entity->setExtensionAttributes($extensionAttributes);
            $products[] = $entity;
        }
        $searchCriteria->setItems($products);
        return $searchCriteria;
    }
}














